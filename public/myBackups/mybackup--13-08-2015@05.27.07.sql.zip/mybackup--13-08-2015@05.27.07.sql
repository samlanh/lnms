--
-- Database : db_loan
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `ln_account_branch`
--
DROP TABLE  IF EXISTS `ln_account_branch`;
CREATE TABLE `ln_account_branch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `balance` float(16,2) DEFAULT NULL,
  `currency_type` tinyint(4) NOT NULL COMMENT '1=kh,2=dollar,3 bath',
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `date` date DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`,`account_id`,`branch_id`,`currency_type`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `ln_account_branch`  VALUES ( "1","1","1","100366.00","2","1","1","2015-05-03","");
INSERT INTO `ln_account_branch`  VALUES ( "2","2","1","-99362.34","2","1","1","2015-05-03","");
INSERT INTO `ln_account_branch`  VALUES ( "3","3","1","1003.66","2","1","1","2015-05-03","");
INSERT INTO `ln_account_branch`  VALUES ( "7","1","1","2000.00","1","1","1","2015-05-29","");
INSERT INTO `ln_account_branch`  VALUES ( "8","2","1","-1980.00","1","1","1","2015-05-29","");
INSERT INTO `ln_account_branch`  VALUES ( "9","3","1","20.00","1","1","1","2015-05-29","");
INSERT INTO `ln_account_branch`  VALUES ( "10","1","7","1000.00","2","1","1","2015-06-02","");
INSERT INTO `ln_account_branch`  VALUES ( "11","2","7","-990.00","2","1","1","2015-06-02","");
INSERT INTO `ln_account_branch`  VALUES ( "12","3","7","10.00","2","1","1","2015-06-02","");


--
-- Tabel structure for table `ln_account_category`
--
DROP TABLE  IF EXISTS `ln_account_category`;
CREATE TABLE `ln_account_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_namekh` varchar(100) DEFAULT NULL,
  `cate_nameen` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `account_type` tinyint(4) DEFAULT NULL,
  `deplay` int(4) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `ln_account_category`  VALUES ( "1","Dell","Dell","1","2","1","2014-12-17","1","");
INSERT INTO `ln_account_category`  VALUES ( "2","Apple","Apple","1","3","1","2014-12-10","2","");
INSERT INTO `ln_account_category`  VALUES ( "3","Acer","Acer","1","2","1","2014-12-02","1","");
INSERT INTO `ln_account_category`  VALUES ( "4","???","kok","6","1","1","2014-12-25","1","");
INSERT INTO `ln_account_category`  VALUES ( "12","rrr","rrrr","1","1","2","2015-01-26","1","");


--
-- Tabel structure for table `ln_account_name`
--
DROP TABLE  IF EXISTS `ln_account_name`;
CREATE TABLE `ln_account_name` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_code` varchar(100) DEFAULT NULL,
  `account_name_kh` varchar(100) DEFAULT NULL,
  `account_name_en` varbinary(100) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL,
  `disc` text,
  `option_acc` tinyint(1) DEFAULT '1' COMMENT '1=operation acc,2=non operation acc',
  `account_type` tinyint(4) DEFAULT NULL COMMENT '1=asset,2=liabilities,3=equities,4=incomes,5=expense,6=cost of goods sold',
  `parent_id` tinyint(11) DEFAULT NULL,
  `category_id` tinyint(11) DEFAULT NULL,
  `balance` float(15,3) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `option_type` tinyint(4) DEFAULT '1' COMMENT '1=acc,2cate,3 parent',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

INSERT INTO `ln_account_name`  VALUES ( "17","10000008","loan","loan","","","1","1","20","21","0.000","2015-01-21","1","1","1");
INSERT INTO `ln_account_name`  VALUES ( "18","","","","","","1","","","","","","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "19","10000007","Petty Cash","Petty Cash","","","2","1","9","2","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "20","11","Current Assets","Current Assets","","","2","1","0","0","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "21","3","Cash/Bank","Cash/Bank","","","2","1","20","0","0.000","2015-01-21","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "22","9","Petty Cash","Petty Cash","","","1","1","20","21","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "23","8","Cash on Hand","Cash on Hand","","","1","1","20","21","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "28","10000009","Regular Checking Account","Regular Checking Account","","","1","1","20","21","0.000","2015-01-21","1","","0");
INSERT INTO `ln_account_name`  VALUES ( "29","10000009","Regular Checking Account","Regular Checking Account","","","1","1","20","21","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "30","10000010","Savings Account","Savings Account","","","1","1","20","21","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "31","01","Accounts Receivable","Accounts Receivable","","","2","1","20","0","0.000","2015-01-21","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "32","10000011","Allowance for Doubtful Account","Allowance for Doubtful Account","","","1","1","20","31","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "33","10000012","Accounts Receivable","Accounts Receivable","","","1","1","20","31","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "34","10000013","Other Receivables","Other Receivables","","","1","1","20","31","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "35","10000034","Pending Account Receivables","Pending Account Receivables","","","1","1","20","31","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "38","02","Inventory","Inventory","","","2","1","20","0","0.000","2015-01-21","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "39","10000014","Inventory","Inventory","","","1","1","20","38","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "40","10000036","Stock","Stock","","","1","1","20","38","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "41","03","Other Current Assets","Other Current Assets","","","2","1","20","0","0.000","2015-01-21","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "42","10000015","Prepaid Expenses","Prepaid Expenses","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "43","10000017","Purchase Tax","Purchase Tax","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "44","10000018","Employee Advances","Employee Advances","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "45","10000019","Notes Receivable-Current (Business Advance)","Notes Receivable-Current (Business Advance)","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "46","10000020","Other Current Assets","Other Current Assets","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "47","10000033","Supplier Deposit","Supplier Deposit","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "48","10000035","Inventory Markup","Inventory Markup","","","1","1","20","41","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "49","04","Fixed Assets","Fixed Assets","","","2","1","0","0","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "50","10000021","Equipment","Equipment","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "51","10000022","Depreciation - Equipment","Depreciation - Equipment","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "52","10000023","Vehicles","Vehicles","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "53","10000024","Depreciation - Vehicles","Depreciation - Vehicles","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "54","10000025","Leasehold Improvements","Leasehold Improvements","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "55","10000026","Depreciation - Leasehold","Depreciation - Leasehold","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "56","10000027","Buildings","Buildings","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "57","10000028","Depreciation - Buildings","Depreciation - Buildings","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "58","10000029","Land","Land","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "59","10000030","Depreciation - Land","Depreciation - Land","","","1","1","49","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "60","05","Other Assets","Other Assets","","","2","1","0","0","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "61","10000031","Notes Receivable- Noncurrent","Notes Receivable- Noncurrent","","","1","1","60","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "62","10000032","Other Noncurrent Assets","Other Noncurrent Assets","","","1","1","60","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "63","06","Current Liabilities","Current Liabilities","","","2","2","0","0","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "64","07","Other Current Liabilities","Other Current Liabilities","","","2","2","63","0","0.000","2015-01-21","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "65","20000006","Accrued Expenses","Accrued Expenses","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "66","20000007","Sales Tax Payable","Sales Tax Payable","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "67","20000008","Wages Payable","Wages Payable","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "68","20000009","Insurance Payable","Insurance Payable","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "69","20000010","Income Taxes Payable 1%","Income Taxes Payable 1%","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "70","20000011","Other Taxes Payable","Other Taxes Payable","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "71","20000012","Current Portion Long-Term Debt","Current Portion Long-Term Debt","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "72","20000013","Other Current Liabilities","Other Current Liabilities","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "73","20000014","Suspense - Clearing Account","Suspense - Clearing Account","","","1","2","63","64","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "75","08","Accounts Payable","Accounts Payable","","","2","2","0","0","0.000","2015-01-21","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "76","20000021","Pending  Purchase Order Receipt","Pending  Purchase Order Receipt","","","1","2","63","75","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "77","20000022","Customer Gift Voucher","Customer Gift Voucher","","","1","2","63","75","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "78","20000020","Pending Sale Commissions","Pending Sale Commissions","","","1","2","63","75","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "79","20000018","Customer Deposit","Customer Deposit","","","1","2","63","75","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "80","20000019","Customer Return","Customer Return","","","1","2","63","75","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "81","20000015","Accounts Payable","Accounts Payable","","","1","2","63","75","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "82","09","Non-Current Liabilities","Non-Current Liabilities","","","2","2","0","0","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "83","010","Long Term Liabilities","Long Term Liabilities","","","2","2","0","0","0.000","2015-01-21","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "84","20001300","Customer Commission","Customer Commission","","","1","2","83","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "85","20000016","Notes Payable-Noncurrent","Notes Payable-Noncurrent","","","1","2","83","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "86","20000017","Other Long-Term Liabilities","Other Long-Term Liabilities","","","1","2","83","0","0.000","2015-01-21","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "88","010","Equity","Equity","","","2","3","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "89","30000004","Beginning Balance Equity","Beginning Balance Equity","","","1","3","88","0","0.000","2015-01-22","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "90","30000005","Common Stock","Common Stock","","","1","3","88","0","0.000","2015-01-22","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "91","30000006","Paid-in Capital","Paid-in Capital","","","1","3","88","0","0.000","2015-01-22","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "92","011","Equity-Retained Earnings","Equity-Retained Earnings","","","2","3","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "93","30000007","Retained Earnings","Retained Earnings","","","1","3","92","0","0.000","2015-01-22","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "95","013","Equity-gets closed","Equity-gets closed","","","2","3","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "96","30000008","Dividends Paid","Dividends Paid","","","1","3","95","0","0.000","2015-01-22","1","","1");
INSERT INTO `ln_account_name`  VALUES ( "97","014","Income","Income","","","2","4","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "98","40000003","Other Income","Other Income","","","2","5","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "99","40000013","Freight Income","Freight Income","","","2","4","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "100","40000015","Income Summary","Income Summary","","","2","4","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "101","40000016","Service Charge","Service Charge","","","2","4","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "102","014","Expenses","Expenses","","","2","5","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "103","015","Administrtive Expesne","Administrtive Expesne","","","2","5","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "104","60000004","Sale Incentive","Sale Incentive","","","2","5","0","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "106","60000011","Penalties and Fines Exp","Penalties and Fines Exp","","","2","5","103","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "107","60000011","Penalties and Fines Exp","Penalties and Fines Exp","","","2","5","103","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "108","60000010","Maintenance Expense","Maintenance Expense","","","2","5","103","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "109","016","Operation Expense","Operation Expense","","","2","5","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "110","60000019","Commissions and Fees Exp","Commissions and Fees Exp","","","2","5","0","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "112","60000021","Dues and Subscriptions Exp","Dues and Subscriptions Exp","","","2","5","109","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "113","60000036","Utilities Expense","Utilities Expense","","","2","5","109","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "114","60000034","Supplies Expense","Supplies Expense","","","2","5","109","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "115","016","Payroll Expense","Payroll Expense","","","2","5","0","0","0.000","2015-01-22","1","","3");
INSERT INTO `ln_account_name`  VALUES ( "116","60000043","Over Time Expense","Over Time Expense","","","2","5","115","0","0.000","2015-01-22","1","","2");
INSERT INTO `ln_account_name`  VALUES ( "117","60000044","Bonus Expense","Bonus Expense","","","2","5","115","0","0.000","2015-01-22","1","","2");


--
-- Tabel structure for table `ln_backupschedule`
--
DROP TABLE  IF EXISTS `ln_backupschedule`;
CREATE TABLE `ln_backupschedule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `note` text,
  `file_name` varchar(40) DEFAULT NULL,
  `action_type` tinyint(4) DEFAULT NULL COMMENT '1=backup,2restore',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_badloan`
--
DROP TABLE  IF EXISTS `ln_badloan`;
CREATE TABLE `ln_badloan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch` varchar(100) DEFAULT NULL,
  `client_code` varchar(100) DEFAULT NULL,
  `client_name` varchar(100) DEFAULT NULL,
  `loan_number` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `loss_date` date DEFAULT NULL,
  `cash_type` int(10) DEFAULT NULL,
  `total_amount` varchar(100) DEFAULT NULL,
  `intrest_amount` varchar(100) DEFAULT NULL,
  `tem` varchar(100) DEFAULT NULL COMMENT '1= writeoff',
  `note` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `create_by` int(11) DEFAULT NULL,
  `is_writoff` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ln_badloan`  VALUES ( "1","1","28","28","","2015-07-03","2015-05-15","2","3600","84","30","PPL000021","1","1","0");


--
-- Tabel structure for table `ln_branch`
--
DROP TABLE  IF EXISTS `ln_branch`;
CREATE TABLE `ln_branch` (
  `br_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_namekh` varchar(200) DEFAULT NULL,
  `branch_nameen` varbinary(100) DEFAULT NULL,
  `br_address` varchar(100) DEFAULT NULL,
  `branch_code` varchar(100) DEFAULT NULL,
  `branch_tel` varchar(100) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `other` varchar(100) DEFAULT NULL,
  `prefix` varchar(10) DEFAULT NULL COMMENT '??????????? ??????????????',
  `status` tinyint(4) DEFAULT '1',
  `displayby` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`br_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `ln_branch`  VALUES ( "1","???????","Phnom Penh","Phnom Penh","C-001","","","","PP","1","2");
INSERT INTO `ln_branch`  VALUES ( "2","???? ????????","Battambang","Battambang","C-001","","","","BB","1","2");
INSERT INTO `ln_branch`  VALUES ( "3","","","","","","","","","1","0");
INSERT INTO `ln_branch`  VALUES ( "4","??????","Takmao","Takmao , Kandal","124566","023 23 23 10","","","TK","1","1");
INSERT INTO `ln_branch`  VALUES ( "5","?????","Chom Choa","#201, St Rusia ,Kakab, Dongkor  Phnom Penh","C-005","070 41 80022","Info@sokha.com","","CC","1","2");
INSERT INTO `ln_branch`  VALUES ( "6","Kandal","Kandal","","C-006","","","","KD","1","1");
INSERT INTO `ln_branch`  VALUES ( "7","??????","Kandal","","C-007","","","","KD","1","1");
INSERT INTO `ln_branch`  VALUES ( "8","??????????","Purchintong","","C-008","","","","PT","1","1");


--
-- Tabel structure for table `ln_branch_capital`
--
DROP TABLE  IF EXISTS `ln_branch_capital`;
CREATE TABLE `ln_branch_capital` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `amount_dollar` float(18,3) DEFAULT NULL,
  `amount_riel` float(18,3) DEFAULT NULL,
  `amount_bath` float(18,3) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_callecteral_type`
--
DROP TABLE  IF EXISTS `ln_callecteral_type`;
CREATE TABLE `ln_callecteral_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title_en` varchar(50) DEFAULT NULL,
  `title_kh` varbinary(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `ln_callecteral_type`  VALUES ( "1","Real Estate Certification Mark","វិញ្ញាបនប័ត្រសម្គាល់អចលនវត្ថុ","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "2","Land Ownership Certificate","លិខិតផ្ទេរកម្មសិទ្ធិដីធ្លី","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "3","National Identity Card","អត្តសញ្ញាណប័ណ្ណសញ្ជាតិខ្មែរ","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "4","Family Book","សៀវភៅគ្រួសារ","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "5","Resident Letter","លិខិតស្នាក់នៅ","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "6","Civil Status","សំបុត្របញ្ជាក់កំណើត","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "7","Driver\'s License","ប័ណ្ណបើកបរ","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "8","Vehicle Credentials","ប័ណ្ណសំគាល់យានយន្ត(កាតគ្រី)","2015-04-09","1","1");
INSERT INTO `ln_callecteral_type`  VALUES ( "9","test","teqw","2015-02-17","1","1");


--
-- Tabel structure for table `ln_callecteralllist`
--
DROP TABLE  IF EXISTS `ln_callecteralllist`;
CREATE TABLE `ln_callecteralllist` (
  `id` int(22) unsigned NOT NULL AUTO_INCREMENT,
  `branch` int(12) DEFAULT NULL,
  `receipt` varchar(30) DEFAULT NULL,
  `code_call` varchar(20) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `type_call` tinyint(4) DEFAULT NULL,
  `owner_call` varchar(50) DEFAULT NULL,
  `callnumber` varchar(20) DEFAULT NULL COMMENT 'numnote??????????',
  `create_date` date DEFAULT NULL,
  `date_debt` date DEFAULT NULL,
  `term` tinyint(4) DEFAULT NULL,
  `amount_term` int(11) DEFAULT NULL,
  `date_line` date DEFAULT NULL,
  `curr_type` tinyint(3) DEFAULT NULL,
  `amount_debt` double(18,2) DEFAULT NULL,
  `note` varchar(43) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `is_verify` tinyint(4) DEFAULT '0',
  `verify_by` int(11) DEFAULT NULL,
  `is_fund` tinyint(4) DEFAULT '0',
  `term_fun` tinyint(4) DEFAULT NULL,
  `charge_term` int(11) DEFAULT NULL,
  `amount_money` float(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_change_collecteral`
--
DROP TABLE  IF EXISTS `ln_change_collecteral`;
CREATE TABLE `ln_change_collecteral` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `from_coll_id` int(11) DEFAULT NULL,
  `to_coll_id` int(11) DEFAULT NULL,
  `coll_number` varchar(20) DEFAULT NULL,
  `owner_name` varchar(50) DEFAULT NULL,
  `with_ownername` varchar(50) DEFAULT NULL,
  `owner_type` tinyint(4) DEFAULT NULL COMMENT '???????????? ????????????',
  `reason` text,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_verify` int(11) DEFAULT NULL,
  `is_closing` tinyint(4) DEFAULT '0',
  `closing_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_changecollteral`
--
DROP TABLE  IF EXISTS `ln_changecollteral`;
CREATE TABLE `ln_changecollteral` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `note` text,
  `status` tinyint(2) DEFAULT NULL COMMENT '1=??????????',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ln_changecollteral`  VALUES ( "3","1","1","","2015-08-12","","1","1");


--
-- Tabel structure for table `ln_changecollteral_detail`
--
DROP TABLE  IF EXISTS `ln_changecollteral_detail`;
CREATE TABLE `ln_changecollteral_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `change_id` int(11) DEFAULT NULL,
  `client_coll_id` int(11) DEFAULT NULL,
  `from_id` int(11) DEFAULT NULL,
  `from_collateral_type` int(11) DEFAULT NULL,
  `from_owner_id` tinyint(4) DEFAULT NULL,
  `from_owner_name` varchar(60) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `from_number_collateral` varchar(60) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `from_note` text COLLATE utf8_hungarian_ci,
  `to_id` int(11) DEFAULT NULL,
  `collateral_type` int(11) DEFAULT NULL,
  `owner_id` tinyint(4) DEFAULT NULL,
  `toowner_name` varchar(60) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `number_collateral` varchar(60) COLLATE utf8_hungarian_ci DEFAULT NULL,
  `note` text COLLATE utf8_hungarian_ci,
  `status` tinyint(4) DEFAULT '1',
  `is_changed` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `ln_changecollteral_detail`  VALUES ( "1","3","6","","1","1","Dara-????","222","","","1","1","Dara-????","2","","1","");
INSERT INTO `ln_changecollteral_detail`  VALUES ( "2","3","7","","8","1","Dara-????","3333","","","1","1","Dara-????","222","","1","");


--
-- Tabel structure for table `ln_client`
--
DROP TABLE  IF EXISTS `ln_client`;
CREATE TABLE `ln_client` (
  `client_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `agreement_id` int(11) DEFAULT NULL,
  `is_group` tinyint(4) DEFAULT NULL,
  `group_code` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL COMMENT 'group id',
  `client_number` varchar(50) DEFAULT NULL COMMENT 'client_code ,first lenght for branch',
  `name_kh` varchar(150) DEFAULT NULL,
  `name_en` varchar(150) DEFAULT NULL,
  `join_with` varchar(150) DEFAULT NULL,
  `join_nation_id` varchar(30) DEFAULT NULL,
  `relate_with` varchar(50) DEFAULT NULL COMMENT 'join acc ?????????????? ???????',
  `join_tel` varchar(50) DEFAULT NULL,
  `guarantor_with` varchar(50) DEFAULT NULL COMMENT '??????????????????????? Client',
  `guarantor_tel` varchar(50) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `position_id` int(1) DEFAULT NULL,
  `sit_status` int(11) DEFAULT NULL,
  `pro_id` int(11) DEFAULT NULL,
  `dis_id` int(11) DEFAULT NULL,
  `com_id` int(11) DEFAULT NULL,
  `village_id` int(11) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `house` varchar(50) DEFAULT NULL,
  `id_type` int(11) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `acc_number` varchar(20) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `job` varchar(40) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pob` varchar(100) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `spouse_name` varchar(50) DEFAULT NULL COMMENT '????????',
  `spouse_nationid` varchar(30) DEFAULT NULL COMMENT '??????????????? ????????',
  `remark` text,
  `create_date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT '1',
  `photo_name` varchar(50) DEFAULT NULL,
  `reference` int(11) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT '1',
  `status_process` tinyint(4) DEFAULT '1' COMMENT '1 padding,2=closed',
  `type` tinyint(4) DEFAULT '1' COMMENT '1 loan, 2=callecterall',
  `is_blacklist` int(11) DEFAULT '0' COMMENT 'is bad client',
  `job_name` varchar(10) DEFAULT NULL,
  `nation_id` varchar(20) DEFAULT NULL,
  `is_verify` tinyint(4) DEFAULT NULL,
  `verify_by` int(11) DEFAULT NULL,
  `reasonblack_list` text,
  `date_blacklist` date DEFAULT NULL,
  `status_blacklist` tinyint(4) DEFAULT NULL,
  `guarantor_address` varchar(100) DEFAULT NULL,
  `guarantor_d_type` tinyint(4) DEFAULT NULL COMMENT 'guarantor document type',
  `join_d_type` tinyint(4) DEFAULT NULL COMMENT 'joint document type',
  `client_d_type` tinyint(4) DEFAULT NULL COMMENT 'client document type',
  `dob_guarantor` varchar(30) DEFAULT NULL,
  `dob_join_acc` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `ln_client`  VALUES ( "0","","0","","0","NL000","?????????","ganeral customer","","","","","","","","","","","","","","","","","","","","","","","","","","","","2015-05-29","1","1","1","","","1","1","1","0","","","","","","","","","","","1","","");
INSERT INTO `ln_client`  VALUES ( "1","","0","","0","PP000001","????","Dara","Nary","","","","","","1","","1","1","1","1","1","","","1","44333","","012 32 23 23","","","","","","","","","2015-05-29","1","1","1","","","1","1","1","0","","33","","","","","","","0","0","1","","");
INSERT INTO `ln_client`  VALUES ( "2","","0","","0","PP000002","?????","Samnang","Navuth","12303020202","???????","0303003030","???????","012 323 222","1","","1","1","1","1","1","320","16A","","","","070 33 43 54","??????????","","","","","?? ??????","1230303003","","2015-05-30","1","1","1","","","1","1","1","0","","1230300303","","","","","","PP","1","1","1","","");
INSERT INTO `ln_client`  VALUES ( "5","","0","","0","KD000001","????","Sok Kha","Nary","422222","Wife","012 32 33 22","","","1","","2","1","1","1","1","120","#30","","","","070 40 50 40","Teacher","","","","","Vuthy","","","2015-06-02","1","1","7","","","1","1","1","0","","123444","","","","","","","1","1","1","","");
INSERT INTO `ln_client`  VALUES ( "6","","0","","0","PP000004","??","A","B","11234213","wife","012456781","father","012678352","1","","1","1","2","18","0","44","55","","","","012234589","sale","","","","","C","11244134","","2015-06-06","1","1","1","","","1","1","1","0","","11234512","","","","","","popopiopi","1","1","1","","");
INSERT INTO `ln_client`  VALUES ( "7","","0","","0","PP000005","AA","BB","","","","","","","2","","2","1","1","1","2","333","","","","","222","222","0000-00-00","","","","","","","2015-06-21","1","1","1","","","1","1","1","0","","322","","","","","","","0","0","72","","");
INSERT INTO `ln_client`  VALUES ( "8","","1","GPP001","0","PP000007","??? ????","Long Dany","Sok dary","Sok Serrey","Lom chandary","03303003","Mother","30302300202","1","","1","1","","","","23","23","","","","0339399393","Teacher","2015-06-13","","","","Morn money","3333","Sok Chandara","2015-06-21","1","1","1","","","1","1","1","0","","233","","","","","","PP","4","1","0","2015-06-18","2015-06-19");
INSERT INTO `ln_client`  VALUES ( "9","","0","","0","000009","sok","sok","","","","","","","1","","1","0","0","0","0","","","","","","","vireak","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","3","","");
INSERT INTO `ln_client`  VALUES ( "10","","0","","0","000010","?????????","Chear Monorom","","","","","","","1","","1","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","2","","");
INSERT INTO `ln_client`  VALUES ( "11","","0","","0","000011","sok choomnor","chear nomnor","","","","","","","1","","2","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","2","","");
INSERT INTO `ln_client`  VALUES ( "12","","0","","0","000012","cheasok","cheasok","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "13","","0","","0","000013","???? ?????","mok channy","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "14","","0","","0","PP000012","testing","sok","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "15","","0","","0","PP000013","mean","okasdf","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "16","","0","","0","PP000014","sok chanrernq","sock chamrerng","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "17","","0","","0","PP000015","long","long","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "18","","0","","0","PP000016","chea","CHEA","","","","","","","1","","1","0","4","5","3","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","2","","");
INSERT INTO `ln_client`  VALUES ( "19","","0","","0","PP000017","??????????","long dany","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "20","","0","","0","PP000018","sokqdo","fasdfs","","","","","","","1","","-1","5","1","2","4","","","","","","","","0000-00-00","","","","","","","2015-06-25","1","1","1","","","1","1","1","0","","","","","","","","","","","1","","");
INSERT INTO `ln_client`  VALUES ( "21","","0","","0","PP000019","mean chanda","mead","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-26","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "22","","0","","0","BB000001","means","sokd","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-26","1","1","1","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "23","","0","","0","BB000001","sok","sok","","","","","","","0","","0","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-26","1","1","2","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "24","","0","","0","BB000002","sov","sov","","","","","","","1","","3","0","2","6","7","","","","","","","","0000-00-00","","","","","","","2015-06-26","1","1","2","","","1","1","1","0","","","","","","","","","","","2","","");
INSERT INTO `ln_client`  VALUES ( "25","","0","","0","KD000002","???","meas","","","","","","","1","","1","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-06-26","1","1","7","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "26","","0","","8","PP000021","Siniths","sokd","","","","","","","1","","1","1","1","1","1","","","","","","","","0000-00-00","","","","","","","2015-07-27","1","1","1","","","1","1","1","0","","","","","","","","","0","0","0","","");
INSERT INTO `ln_client`  VALUES ( "27","","0","","0","CC000001","Sok ","Sov","","","","","","","1","","1","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-08-01","1","","5","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "28","","0","","0","TK000001","sok ","wsov","","","","","","","1","","1","0","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-08-01","1","","4","","","1","1","1","0","","","","","","","","","","","0","","");
INSERT INTO `ln_client`  VALUES ( "29","","0","","8","PP000022","sov","sa erk","","","","","","","1","","1","1","0","0","0","","","","","","","","0000-00-00","","","","","","","2015-08-01","1","","1","","","1","1","1","0","","","","","","","","","0","0","0","","");
INSERT INTO `ln_client`  VALUES ( "30","","1","GPP002","0","PP000023","???","monor","","","","","","","1","","1","3","0","0","0","","","","","","","Teacher","0000-00-00","","","","","","","2015-08-03","1","1","1","","","1","1","1","0","","1233","","","","","","","0","0","68","","");
INSERT INTO `ln_client`  VALUES ( "31","","0","","30","PP000024","Narith","Narith","","","","","","","1","","1","1","0","0","0","","","","","","","Teacher","0000-00-00","","","","","","","2015-08-03","1","1","1","","","1","1","1","0","","123","","","","","","","0","0","68","","");
INSERT INTO `ln_client`  VALUES ( "32","","0","","0","PP000025","????","Dara","","","","","","","1","","1","1","0","0","0","","","","","","","Teacher","0000-00-00","","","","","","","2015-08-05","1","1","1","","","1","1","1","0","","1234","","","","","","","0","0","68","","");
INSERT INTO `ln_client`  VALUES ( "33","","0","","0","PP000026","??? ????","Long Dara","channy","33333","","","","","1","","1","1","1","1","2","21","10","","","","020202020","Teacher","2015-08-06","","","","","","","2015-08-10","1","1","1","","","1","1","1","0","","","","","","","","","","1","1","","");
INSERT INTO `ln_client`  VALUES ( "34","","1","GPT001","0","PT000001","????","Virak","","","","","","","1","","1","1","2","0","0","","","1","","","02020202","Teacher","1990-04-22","","","","","","","2015-08-10","1","1","8","","","1","1","1","0","","123444","","","","","","","0","0","68","","");


--
-- Tabel structure for table `ln_client_blacklist`
--
DROP TABLE  IF EXISTS `ln_client_blacklist`;
CREATE TABLE `ln_client_blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL COMMENT 'reason black list',
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ln_client_blacklist`  VALUES ( "1","1","34","2015-08-13","","this client is not fund","1");


--
-- Tabel structure for table `ln_client_callecteral`
--
DROP TABLE  IF EXISTS `ln_client_callecteral`;
CREATE TABLE `ln_client_callecteral` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `join_with` varchar(50) DEFAULT NULL,
  `relative` varchar(50) DEFAULT NULL COMMENT '?????????????????????????????????????',
  `guarantor` varchar(50) DEFAULT NULL,
  `guarantor_relative` varchar(50) DEFAULT NULL COMMENT '?????????????????????????????',
  `collecteral_code` varchar(50) DEFAULT NULL COMMENT '????????? ????????????????',
  `co_id` int(11) DEFAULT NULL,
  `note` varchar(60) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` tinyint(3) DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `is_return` int(11) DEFAULT NULL COMMENT 'if return all ready',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `ln_client_callecteral`  VALUES ( "1","1","2","Navuth","???????","?? ??????","???????","CL000001","1","","2015-07-30","1","","");
INSERT INTO `ln_client_callecteral`  VALUES ( "2","1","8","Sok dary","Lom chandary","Morn money","Mother","CL000002","2","","2015-07-30","1","","");
INSERT INTO `ln_client_callecteral`  VALUES ( "3","1","0","","","","","CL000003","14","","2015-07-30","1","","");
INSERT INTO `ln_client_callecteral`  VALUES ( "4","1","1","Nary","","","","CL000004","2","","2015-08-12","1","","");


--
-- Tabel structure for table `ln_client_callecteral_detail`
--
DROP TABLE  IF EXISTS `ln_client_callecteral_detail`;
CREATE TABLE `ln_client_callecteral_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_coll_id` int(11) DEFAULT NULL COMMENT 'from client collecteral',
  `collecteral_type` int(11) DEFAULT NULL,
  `owner_type` tinyint(4) DEFAULT NULL COMMENT '???????????????',
  `owner_name` varchar(150) DEFAULT NULL,
  `number_collecteral` varchar(50) DEFAULT NULL COMMENT '???????????????????',
  `note` text,
  `status` tinyint(4) DEFAULT '1',
  `is_changed` tinyint(4) DEFAULT '0',
  `changecollteral_id` int(11) DEFAULT '0' COMMENT 'id from change collecteral id',
  `is_return` tinyint(4) DEFAULT '0' COMMENT '?????????????????????',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `ln_client_callecteral_detail`  VALUES ( "1","1","1","1","Samnang-?????","333333","","1","0","0","0");
INSERT INTO `ln_client_callecteral_detail`  VALUES ( "2","1","6","1","Samnang-?????","3333555","","1","0","0","0");
INSERT INTO `ln_client_callecteral_detail`  VALUES ( "3","2","3","2","Meas Channy","233222","","1","0","0","0");
INSERT INTO `ln_client_callecteral_detail`  VALUES ( "4","2","8","1","Long Dany-??? ????","2222","","1","0","0","0");
INSERT INTO `ln_client_callecteral_detail`  VALUES ( "5","3","1","1","ganeral customer-?????????","322","return by change collateral","1","0","0","1");
INSERT INTO `ln_client_callecteral_detail`  VALUES ( "6","4","1","1","Dara-????","222","return by change collateral","1","0","0","0");
INSERT INTO `ln_client_callecteral_detail`  VALUES ( "7","4","8","1","Dara-????","3333","return by change collateral","1","0","0","0");


--
-- Tabel structure for table `ln_client_receipt_money`
--
DROP TABLE  IF EXISTS `ln_client_receipt_money`;
CREATE TABLE `ln_client_receipt_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `co_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL COMMENT 'client id or group id',
  `receiver_id` int(10) unsigned DEFAULT NULL,
  `receipt_no` varchar(50) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `loan_number` varchar(50) DEFAULT NULL,
  `date_pay` date DEFAULT NULL,
  `date_input` date DEFAULT NULL,
  `principal_amount` float(18,3) DEFAULT NULL,
  `total_principal_permonth` float(18,3) DEFAULT NULL,
  `total_payment` float(18,3) DEFAULT NULL COMMENT '????????',
  `amount_payment` float(18,3) DEFAULT NULL COMMENT '????????????????',
  `total_interest` float(18,3) DEFAULT NULL,
  `recieve_amount` float(18,3) DEFAULT NULL COMMENT '?????????????????',
  `penalize_amount` float(18,3) DEFAULT NULL,
  `return_amount` float(18,3) DEFAULT NULL,
  `service_charge` float(18,3) DEFAULT NULL,
  `total_discount` float(18,3) DEFAULT NULL,
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  `is_group` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `payment_option` int(11) DEFAULT NULL,
  `currency_type` int(11) DEFAULT NULL,
  `is_payoff` tinyint(4) DEFAULT '0' COMMENT '1 if loan pay of',
  `is_completed` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ln_client_receipt_money`  VALUES ( "1","6","1","6","PM-00001","1","","2015-08-05","2015-08-05","1833.330","166.670","218.340","226.340","51.670","226.340","3.000","0.000","5.000","","","1","0","1","1","2","0","1");


--
-- Tabel structure for table `ln_client_receipt_money_detail`
--
DROP TABLE  IF EXISTS `ln_client_receipt_money_detail`;
CREATE TABLE `ln_client_receipt_money_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crm_id` int(11) DEFAULT NULL COMMENT 'id of client reciept money',
  `lfd_id` int(11) DEFAULT NULL COMMENT 'loan fund detail',
  `loan_number` varchar(50) DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `date_payment` date DEFAULT NULL,
  `capital` float(15,2) DEFAULT NULL COMMENT 'capital before fund',
  `remain_capital` float(15,2) DEFAULT NULL,
  `principal_permonth` float(15,2) DEFAULT NULL COMMENT 'principal pay for month',
  `total_interest` float(15,2) DEFAULT NULL,
  `total_payment` float(15,2) DEFAULT NULL COMMENT '????????????????',
  `pay_after` varchar(50) DEFAULT NULL,
  `pay_before` varchar(50) DEFAULT NULL,
  `is_completed` tinyint(4) DEFAULT '0' COMMENT '0=not paid complet ,1=complete,2=over paid',
  `is_verify` tinyint(4) DEFAULT '0',
  `verify_by` tinyint(4) DEFAULT '0',
  `is_closingentry` tinyint(4) DEFAULT '0',
  `currency_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '1=normal,2=pay before,3=??????????????,4=payof',
  `total_recieve` float(15,2) DEFAULT NULL,
  `service_charge` float(15,2) DEFAULT NULL,
  `penelize_amount` float(15,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='??????????????????????????????????';

INSERT INTO `ln_client_receipt_money_detail`  VALUES ( "1","1","25","PPL00003","1","2015-09-05","2000.00","1833.33","166.67","51.67","218.34","2","","1","0","0","0","2","1","226.34","0.00","0.00");


--
-- Tabel structure for table `ln_client_reciept`
--
DROP TABLE  IF EXISTS `ln_client_reciept`;
CREATE TABLE `ln_client_reciept` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `date_pay` date DEFAULT NULL COMMENT 'date client must pay',
  `date` date DEFAULT NULL COMMENT 'date input to system',
  `remain_principal` int(11) DEFAULT NULL COMMENT 'remain before fund',
  `principal_permonth` float(12,2) DEFAULT NULL,
  `interest_rate` float(12,2) DEFAULT NULL,
  `total_payment` float(12,2) DEFAULT NULL COMMENT '????????? ????????',
  `punish_fee` float(12,2) DEFAULT NULL,
  `total_fund` float(12,2) DEFAULT NULL COMMENT '????????? ??????',
  `loan_fundid` int(11) DEFAULT NULL COMMENT '????id ???????????',
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '1=active,0delete',
  `is_complete` tinyint(4) DEFAULT '1' COMMENT '1=paid,2 not complete',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_co`
--
DROP TABLE  IF EXISTS `ln_co`;
CREATE TABLE `ln_co` (
  `co_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT '1',
  `position_id` int(11) DEFAULT NULL,
  `co_code` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `co_khname` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `co_firstname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `co_lastname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL COMMENT '1=m,2=f',
  `national_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pob` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'date of birth',
  `address` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'current addresss',
  `degree` tinyint(4) DEFAULT NULL COMMENT '1=ba,2=phd',
  `tel` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `create_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT '1' COMMENT '1=kh,2=eng',
  `basic_salary` float(12,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `postion_id` int(11) DEFAULT NULL,
  `contract_no` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shift` tinyint(4) DEFAULT '1' COMMENT '1=???????,2=????????',
  `workingtime` tinyint(4) DEFAULT '1' COMMENT '1=????????,2=????????,3=???????? ??? ?????????',
  `photo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `figer_print_id` varbinary(30) DEFAULT NULL,
  `annual_lives` int(11) DEFAULT NULL,
  PRIMARY KEY (`co_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ln_co`  VALUES ( "1","1","1","C001","??? ?????","sarons","","1","33333","phnom penhs","Phnom Penhs","2","0121010101s","mok_channy@yahoo.com","1","0000-00-00","1","1","100.00","2015-01-01","2015-06-17","","44","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "2","1","1","C002","?? ????","dara","chea","2","3444","","Phnom Penh","1","0191919919","darachea@gmail.com","1","0000-00-00","1","1","","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "5","1","1","C003","SSSS","dd","","1","22222","","","2","","","1","0000-00-00","1","1","","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "6","1","1","C004","?????","Narith","","1","12345","12345dd","wq2qww","2","0102200202","abc@gmail.com","1","0000-00-00","1","2","","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "7","1","1","C005","?????","Chear sok","","1","12345","ph,234","phnom penh","2","02020200202","abc@gmail.com","1","0000-00-00","1","2","","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "8","1","1","C006","??????","abc","","1","555555","PP","PP","2","998552","kh@yahoo.com","1","0000-00-00","1","1","100.00","2014-12-26","2014-12-17","","144","Repay","2","2","","","","");
INSERT INTO `ln_co`  VALUES ( "9","1","1","C007","?? ????SS","sok chitra","meas","2","22322","","PP","2","0020200202","narith@gmail.com","1","0000-00-00","1","1","","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "10","1","2","","","dara","","1","","","pp","","020202002","abc@adfas","1","0000-00-00","1","","","","","","","","","","","","","");
INSERT INTO `ln_co`  VALUES ( "11","1","2","","dokv","sok","dokv","1","","","","","pp","","1","0000-00-00","1","1","0.00","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "12","1","2","","asdfsa","asdf","asdfsa","1","","","","","","","1","0000-00-00","1","1","0.00","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "13","1","2","","vikt","sok","vikt","1","","","","","","","1","0000-00-00","1","1","0.00","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "14","1","2","","chea","sok chandara","chea","1","","","","","","","1","0000-00-00","1","1","0.00","","","","","","1","1","","","","");
INSERT INTO `ln_co`  VALUES ( "15","1","1","","Long Dara","?? ?????","Long Dara","1","","","","","03939393","","1","0000-00-00","1","1","0.00","","","","","","1","1","","","","");


--
-- Tabel structure for table `ln_commune`
--
DROP TABLE  IF EXISTS `ln_commune`;
CREATE TABLE `ln_commune` (
  `com_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `district_id` tinyint(10) NOT NULL,
  `commune_name` varchar(60) NOT NULL,
  `commune_namekh` varchar(60) DEFAULT NULL,
  `modify_date` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL COMMENT '1=kh,2=eng',
  `branch_id` int(11) DEFAULT '1',
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `ln_commune`  VALUES ( "1","1","Tonle Bassak","???????????","Apr 7, 2015 3:33:31 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "2","1","Boeng Keng Kang I","???????? I","Apr 7, 2015 3:33:46 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "3","1","Boeng Keng Kang II","???????? II","Apr 7, 2015 3:34:26 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "4","1","Boeng Keng Kang III","???????? III","Apr 7, 2015 3:39:14 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "5","1","Boeng Trabek","?????????","Apr 7, 2015 3:38:57 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "6","1","Tumnup Tuk","????????","Apr 7, 2015 3:39:40 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "7","1","Phsa Doeum Thkow","????????????","Apr 7, 2015 3:39:56 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "8","1","Toul Svay Prey I","???????????? I","Apr 7, 2015 3:40:08 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "9","1","Toul Svay Prey II","???????????? II","Apr 7, 2015 3:40:24 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "10","1","Toul Tum Poung I","???????? I","Apr 7, 2015 3:40:38 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "11","1","Toul Tum Poung II","???????? II","Apr 7, 2015 3:40:51 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "12","1","Olympik","????????","Apr 7, 2015 3:41:03 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "13","2","Srah Chak","??????","Apr 7, 2015 3:41:46 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "14","2","Wat Phnom","????????","Apr 7, 2015 3:42:01 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "15","2","Phsah Chas","?????????","Apr 7, 2015 3:42:17 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "16","2","Phsah Kandal I","??????????? I","Apr 7, 2015 3:42:30 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "17","2","Phsah Kandal II","??????????? II","Apr 7, 2015 3:42:45 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "18","2","Chey Chomneas","???????","Apr 7, 2015 3:43:18 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "19","2","Chaktomuk","??????","Apr 7, 2015 3:43:30 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "20","2","Phsah Thmey I","????????? I","Apr 7, 2015 3:43:44 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "21","2","Phsah Thmey II","???????? II","Apr 7, 2015 3:43:56 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "22","2","Phsah Thmey III","???????? III","Apr 7, 2015 3:44:16 PM","1","1","1","1");
INSERT INTO `ln_commune`  VALUES ( "23","2","Boeng Raing","???????","Apr 7, 2015 3:44:34 PM","1","1","1","1");


--
-- Tabel structure for table `ln_currency`
--
DROP TABLE  IF EXISTS `ln_currency`;
CREATE TABLE `ln_currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `curr_namekh` varchar(255) DEFAULT NULL,
  `curr_nameen` varchar(120) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL COMMENT '1kh,2=en',
  `country_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL COMMENT '1=active,0deactive',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ln_currency`  VALUES ( "2","??????","Dollar","$","","1","1");
INSERT INTO `ln_currency`  VALUES ( "1","???","Riel","R","","2","1");
INSERT INTO `ln_currency`  VALUES ( "3","???","Bath","B","","3","1");


--
-- Tabel structure for table `ln_current_capital`
--
DROP TABLE  IF EXISTS `ln_current_capital`;
CREATE TABLE `ln_current_capital` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `currency_type` tinyint(4) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_department`
--
DROP TABLE  IF EXISTS `ln_department`;
CREATE TABLE `ln_department` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department_kh` varchar(100) DEFAULT NULL,
  `department_en` varchar(100) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `displayby` tinyint(15) DEFAULT '1' COMMENT '1 khmer ,2 english',
  `status` tinyint(4) DEFAULT '1' COMMENT '1=??????????, 0=?????????????',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `ln_department`  VALUES ( "1","???????","Accountant","2015-02-06","1","0","1");
INSERT INTO `ln_department`  VALUES ( "2","?????????????","IT","2015-02-06","1","1","1");


--
-- Tabel structure for table `ln_displayby`
--
DROP TABLE  IF EXISTS `ln_displayby`;
CREATE TABLE `ln_displayby` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `displayby_en` varchar(40) DEFAULT NULL,
  `displayby_kh` varchar(40) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `displayby` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `ln_displayby`  VALUES ( "1","Khmer Title","","1","1");
INSERT INTO `ln_displayby`  VALUES ( "2","English Title","","1","1");


--
-- Tabel structure for table `ln_district`
--
DROP TABLE  IF EXISTS `ln_district`;
CREATE TABLE `ln_district` (
  `dis_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pro_id` tinyint(10) DEFAULT NULL,
  `district_name` varchar(60) DEFAULT NULL,
  `district_namekh` varchar(60) DEFAULT NULL,
  `modify_date` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL COMMENT '1=kh,2=en',
  `branch_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`dis_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `ln_district`  VALUES ( "1","1","Chamkarmon","???????","Apr 7, 2015 3:30:10 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "2","1","Daun Penh","??????","Apr 7, 2015 3:30:34 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "3","1","7 Makara","7 ????","Apr 7, 2015 3:30:51 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "4","1","Toul Kork","??????","Apr 7, 2015 3:31:05 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "5","1","Dangkor","?????","Apr 7, 2015 3:31:15 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "6","1","Meanchey","??????","Apr 7, 2015 3:31:26 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "7","1","Russey Keo","????????","Apr 7, 2015 3:31:35 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "8","1","Sen Sok","??????","Apr 7, 2015 3:31:46 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "9","1","Por Sen Chey","???????????","Apr 7, 2015 3:31:54 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "10","1","Chbar Ampov","?????????","Apr 7, 2015 3:32:04 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "11","1","Chroy Changvar","??????????","Apr 7, 2015 3:32:14 PM","1","1","1","");
INSERT INTO `ln_district`  VALUES ( "12","1","Praek Phnov","?????????","Apr 7, 2015 3:32:24 PM","1","1","1","");


--
-- Tabel structure for table `ln_exchange`
--
DROP TABLE  IF EXISTS `ln_exchange`;
CREATE TABLE `ln_exchange` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` tinyint(4) DEFAULT NULL,
  `exchange_type` tinyint(4) DEFAULT NULL,
  `is_single` tinyint(4) DEFAULT '1' COMMENT '1 = single,0 multi exchange',
  `receive_dollar` float(15,2) DEFAULT NULL,
  `receive_riel` float(15,2) DEFAULT NULL,
  `receive_bath` float(15,2) DEFAULT NULL,
  `return_dollar` float(10,2) DEFAULT NULL,
  `return_riel` float(10,2) DEFAULT NULL,
  `return_bath` float(10,2) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `invoice_code` varchar(30) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `date` date DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `sign` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_exchange_detail`
--
DROP TABLE  IF EXISTS `ln_exchange_detail`;
CREATE TABLE `ln_exchange_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exchange_id` int(11) DEFAULT NULL,
  `from_currency_type` varchar(1) DEFAULT NULL,
  `to_currency_type` varchar(1) DEFAULT NULL,
  `from_amount` double DEFAULT NULL,
  `to_amount` double DEFAULT NULL,
  `exchange_rate` double DEFAULT NULL,
  `date` date DEFAULT NULL,
  `from_to` varchar(20) DEFAULT NULL COMMENT 'simbal only',
  `specail_customer` tinyint(1) DEFAULT '0' COMMENT '0: normal, 1 : specail customer set new rate',
  `status` tinyint(5) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_exchangerate`
--
DROP TABLE  IF EXISTS `ln_exchangerate`;
CREATE TABLE `ln_exchangerate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `in_cur_id` int(11) DEFAULT NULL COMMENT 'The Currency that we take from customer',
  `out_cur_id` int(11) DEFAULT NULL COMMENT 'The Currency that we give to customer',
  `rate_in` double DEFAULT NULL,
  `spread` double DEFAULT NULL,
  `rate_out` double DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1' COMMENT '1:active; 0:Disactive',
  `is_using` tinyint(4) DEFAULT '1',
  `user_id` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ln_exchangerate`  VALUES ( "1","2","3","32.9","32.95","33","2015-06-23 18:26:34","1","","");
INSERT INTO `ln_exchangerate`  VALUES ( "2","1","2","3990","4000","4100","2014-02-03 12:07:58","1","","");
INSERT INTO `ln_exchangerate`  VALUES ( "3","3","1","120.6","120.05","121","2015-06-23 18:26:34","1","","");


--
-- Tabel structure for table `ln_fixed_asset`
--
DROP TABLE  IF EXISTS `ln_fixed_asset`;
CREATE TABLE `ln_fixed_asset` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `depre_code` varchar(30) DEFAULT NULL,
  `fixed_assetname` varchar(120) DEFAULT NULL,
  `fixed_asset_type` tinyint(4) DEFAULT NULL COMMENT '1=shortterm,2=longterm',
  `asset_code` varchar(30) DEFAULT NULL,
  `asset_cost` float(15,2) DEFAULT NULL,
  `term_type` tinyint(4) DEFAULT NULL COMMENT 'month or year',
  `usefull_life` float(10,1) DEFAULT NULL,
  `currency_type` tinyint(4) DEFAULT NULL,
  `salvagevalue` float(10,2) DEFAULT NULL,
  `payment_method` float DEFAULT NULL COMMENT '1 Straight line,2 Double-declining banlance,3 Sum of the year',
  `depreciation_start` float DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL COMMENT 'create date',
  `user_id` int(11) DEFAULT NULL COMMENT 'create by',
  `total_amount` float(15,2) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '1=use,0unuse',
  `pay_type` tinyint(4) DEFAULT NULL COMMENT '1=cash,2=credit,3=other',
  `some_payamount` float(13,3) DEFAULT NULL COMMENT 'input if choose pay_type = 3',
  `note` varchar(100) DEFAULT NULL,
  `is_sold` tinyint(4) DEFAULT '0' COMMENT '1=has sold',
  `is_depreciate` tinyint(4) DEFAULT '0' COMMENT '??????????',
  `auto_post` tinyint(4) DEFAULT '0' COMMENT '1 = auto post every month',
  `is_verify` tinyint(4) DEFAULT NULL,
  `verify_by` int(11) DEFAULT NULL COMMENT 'by user id ?',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO `ln_fixed_asset`  VALUES ( "1","1","","car","2","1","22.00","","23.0","","24.00","3","2014","0","2014-01-01","","","1","2","34.000","neymar","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "21","1","","land","1","2","56.00","","67.0","","68.00","1","2014","0","2014-01-01","","","1","2","0.000","scra","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "22","1","","moto","2","8","78.00","","98.0","","67.00","2","2014","0","2014-01-01","","","1","2","0.000","dara","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "23","2","","toyota","1","78","34.00","","23.0","","12.00","1","2014","0","2014-01-01","","","1","1","0.000","serymon","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "24","1","","bratho","1","12","34.00","","55.0","","56.00","1","2014","0","2014-01-01","","","1","1","0.000","ronadol","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "25","1","","money","1","12","455.00","","566.0","","123.00","1","2014","0","2014-01-01","","","1","1","0.000","ravy","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "26","1","","dojo","2","666","2344.00","","1234545.0","","345656.00","2","2014","0","2014-01-01","","","1","2","222.000","bale","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "27","1","","land","2","325436","12345.00","","3455.0","","345456.00","1","2014","0","2014-01-01","","","1","1","1234.000","isco","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "28","1","","house","1","655","7889.00","","2334.0","","3455.00","1","2014","0","2014-01-01","","","1","1","0.000","marcello","0","0","0","","");
INSERT INTO `ln_fixed_asset`  VALUES ( "29","1","","departemnet","1","234","2234.00","","12344.0","","5667.00","3","2014","0","2014-01-01","","","1","1","1233.000","hongda","0","0","0","","");


--
-- Tabel structure for table `ln_fixed_asset_preposal`
--
DROP TABLE  IF EXISTS `ln_fixed_asset_preposal`;
CREATE TABLE `ln_fixed_asset_preposal` (
  `id` int(11) DEFAULT NULL,
  `fixed_asset_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `date_sold` date DEFAULT NULL,
  `status` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `receipt_type` tinyint(4) DEFAULT '1' COMMENT '1=cash,2=credit,3=other',
  `amount` float(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_fixed_assetdetail`
--
DROP TABLE  IF EXISTS `ln_fixed_assetdetail`;
CREATE TABLE `ln_fixed_assetdetail` (
  `int` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) DEFAULT NULL,
  `total_depre` float(13,2) DEFAULT NULL,
  `times_depre` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `note` text,
  `for_month` int(11) DEFAULT NULL,
  `post_date` date DEFAULT NULL,
  `is_verify` tinyint(4) DEFAULT '0',
  `verify_by` int(11) DEFAULT NULL,
  `is_closing` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`int`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='????? ?????';



--
-- Tabel structure for table `ln_holiday`
--
DROP TABLE  IF EXISTS `ln_holiday`;
CREATE TABLE `ln_holiday` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `holiday_name` varchar(150) DEFAULT NULL,
  `amount_day` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `modify_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `ln_holiday`  VALUES ( "4","Happy New Year 2015","1","2015-03-01","2015-03-03","1","2014-12-31","1","","Stop for khmer New Year");
INSERT INTO `ln_holiday`  VALUES ( "5","Happy New Year 2015","1","2015-01-01","2015-01-15","","","","","");
INSERT INTO `ln_holiday`  VALUES ( "6","Happy New Year 2015","1","2015-01-01","","","","","","");
INSERT INTO `ln_holiday`  VALUES ( "7","","","2015-01-01","","","","","","");
INSERT INTO `ln_holiday`  VALUES ( "8","Khmer New Year ","3","2015-04-14","2015-04-17","1","2015-04-07","1","","1");


--
-- Tabel structure for table `ln_income_expense`
--
DROP TABLE  IF EXISTS `ln_income_expense`;
CREATE TABLE `ln_income_expense` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `total_amount` float(12,2) DEFAULT NULL,
  `fordate` int(11) DEFAULT NULL COMMENT '1to 12',
  `disc` text,
  `date` date DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1' COMMENT '1use,1unuse',
  `user_id` int(11) DEFAULT NULL,
  `tran_type` tinyint(4) DEFAULT NULL COMMENT '1 expense,2 income',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_journal`
--
DROP TABLE  IF EXISTS `ln_journal`;
CREATE TABLE `ln_journal` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `receipt_number` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `create_date` date DEFAULT NULL,
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `from_location` int(11) DEFAULT '1' COMMENT '1=disburse,2=recieve,3xchange,4 collecteral,5payment collecteral,6 add capital,7=transfer capital',
  `is_adjust` tinyint(4) DEFAULT '0',
  `client_id` int(11) DEFAULT NULL,
  `is_direct` int(11) DEFAULT '0' COMMENT '1 = input ,0 auto',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;

INSERT INTO `ln_journal`  VALUES ( "13","2","00001","2015-04-04","2015-04-15","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "14","2","00002","2015-04-18","2015-04-15","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "15","2","00003","2015-04-15","2015-04-15","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "18","1","00001","2015-04-15","2015-04-15","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "26","2","00004","2015-04-15","2015-04-15","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "27","2","00001","2015-04-15","2015-04-15","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "28","2","00002","2015-04-15","2015-04-15","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "29","1","00001","2015-04-16","2015-04-16","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "30","1","00001","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "31","1","00002","2015-01-06","2015-04-17","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "32","1","00003","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","4","0");
INSERT INTO `ln_journal`  VALUES ( "33","1","00004","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","5","0");
INSERT INTO `ln_journal`  VALUES ( "34","1","00006","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","8","0");
INSERT INTO `ln_journal`  VALUES ( "35","1","00007","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","7","0");
INSERT INTO `ln_journal`  VALUES ( "36","1","00008","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","6","0");
INSERT INTO `ln_journal`  VALUES ( "37","1","00009","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","7","0");
INSERT INTO `ln_journal`  VALUES ( "38","1","00010","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","4","0");
INSERT INTO `ln_journal`  VALUES ( "39","2","00011","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "40","1","00012","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","7","0");
INSERT INTO `ln_journal`  VALUES ( "41","2","00013","2015-04-17","2015-04-17","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "42","1","00001","2015-04-20","2015-04-20","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "43","1","00001","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "44","1","00001","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "45","1","00002","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "46","1","00003","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","4","0");
INSERT INTO `ln_journal`  VALUES ( "47","1","00004","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","9","0");
INSERT INTO `ln_journal`  VALUES ( "48","1","00005","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","8","0");
INSERT INTO `ln_journal`  VALUES ( "49","1","00006","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","6","0");
INSERT INTO `ln_journal`  VALUES ( "50","1","00007","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","7","0");
INSERT INTO `ln_journal`  VALUES ( "51","1","00008","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "52","2","00009","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "53","1","00010","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","5","0");
INSERT INTO `ln_journal`  VALUES ( "54","1","00011","2015-04-22","2015-04-22","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "55","1","00012","2015-04-28","2015-04-28","from loan disburse","1","1","1","0","5","0");
INSERT INTO `ln_journal`  VALUES ( "56","1","00013","2015-04-29","2015-04-29","from loan disburse","1","1","1","0","11","0");
INSERT INTO `ln_journal`  VALUES ( "58","1","00013","2015-04-29","2015-04-29","from loan disburse","1","1","1","0","11","0");
INSERT INTO `ln_journal`  VALUES ( "59","1","00017","2015-04-30","2015-04-30","from loan disburse","1","1","1","0","11","0");
INSERT INTO `ln_journal`  VALUES ( "60","1","00018","2015-05-03","2015-05-03","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "61","1","00019","2015-05-03","2015-05-03","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "62","1","PPL00001","2015-05-07","2015-05-07","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "63","1","PPL00002","2015-05-07","2015-05-07","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "64","1","PPL00003","2015-05-09","2015-05-09","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "65","1","PPL00004","2015-05-09","2015-05-09","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "66","1","PPL00005","2015-05-09","2015-05-09","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "67","1","PPL00006","2015-05-09","2015-05-09","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "70","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "71","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "72","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "73","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "74","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "75","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "76","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "77","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "78","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "79","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "80","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "81","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "82","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "83","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "84","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "85","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "86","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "87","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "88","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "89","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "90","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "91","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "92","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "93","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "94","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "95","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "96","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "97","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "98","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "99","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "100","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "101","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "102","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "103","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "104","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "105","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "106","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "107","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "108","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "109","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "110","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "111","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "112","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "113","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "114","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "115","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "116","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "117","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "118","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "119","1","PPL00007","2015-05-14","2015-05-14","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "120","1","PPL00007","2015-05-15","2015-05-15","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "121","1","PPL00007","2015-05-15","2015-05-15","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "122","1","PPL00001","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "123","1","PPL00002","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "124","1","PPL00003","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "125","1","PPL00004","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "126","1","PPL00005","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "127","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "128","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "129","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "130","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "131","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "132","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "133","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "134","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "135","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "136","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "137","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","3","0");
INSERT INTO `ln_journal`  VALUES ( "138","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "139","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "140","1","PPL00006","2015-05-21","2015-05-21","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "141","1","PPL00007","2015-05-25","2015-05-25","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "142","1","PPL00008","2015-05-26","2015-05-26","from loan disburse","","1","1","0","4","0");
INSERT INTO `ln_journal`  VALUES ( "143","1","PPL00001","2015-05-29","2015-05-29","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "145","1","PPL00002","2015-05-29","2015-05-29","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "146","1","PPL00003","2015-05-29","2015-05-29","from loan disburse","1","1","1","0","2","0");
INSERT INTO `ln_journal`  VALUES ( "147","1","PPL00001","2015-05-30","2015-05-30","from loan disburse","1","1","1","0","1","0");
INSERT INTO `ln_journal`  VALUES ( "148","7","KDL00001","2015-06-02","2015-06-02","from loan disburse","1","1","1","0","5","0");
INSERT INTO `ln_journal`  VALUES ( "149","1","PPL00001","2015-06-04","2015-06-04","from loan disburse","1","1","1","0","1","0");


--
-- Tabel structure for table `ln_journal_detail`
--
DROP TABLE  IF EXISTS `ln_journal_detail`;
CREATE TABLE `ln_journal_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jur_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `account_type` tinyint(4) DEFAULT '1' COMMENT '1=debit ,2 credit',
  `is_increase` tinyint(4) DEFAULT '0',
  `currency_type` tinyint(4) DEFAULT NULL,
  `balance` float(13,3) DEFAULT '0.000',
  `is_adjust` tinyint(4) DEFAULT '0' COMMENT '0=not adjust,1=adjust',
  `status` tinyint(4) DEFAULT '1',
  `tran_type` tinyint(4) DEFAULT '1' COMMENT '1=disburse,2=recieve,3xchange,4 collecteral,5payment collecteral',
  `note` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=585 DEFAULT CHARSET=utf8;

INSERT INTO `ln_journal_detail`  VALUES ( "49","13","2","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "50","13","2","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "51","13","2","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "52","13","2","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "53","14","2","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "54","14","2","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "55","14","2","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "56","14","2","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "57","15","2","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "58","15","2","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "59","15","2","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "60","15","2","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "69","18","1","1","1","1","1","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "70","18","1","2","2","0","1","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "71","18","1","2","2","1","1","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "72","18","1","3","2","1","1","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "101","26","2","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "102","26","2","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "103","26","2","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "104","26","2","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "105","27","2","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "106","27","2","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "107","27","2","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "108","27","2","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "109","28","2","1","1","1","1","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "110","28","2","2","2","0","1","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "111","28","2","2","2","1","1","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "112","28","2","3","2","1","1","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "113","29","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "114","29","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "115","29","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "116","29","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "117","30","1","1","1","1","2","1500.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "118","30","1","2","2","0","2","1500.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "119","30","1","2","2","1","2","1500.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "120","30","1","3","2","1","2","1500.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "121","31","1","1","1","1","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "122","31","1","2","2","0","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "123","31","1","2","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "124","31","1","3","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "125","32","1","1","1","1","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "126","32","1","2","2","0","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "127","32","1","2","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "128","32","1","3","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "129","33","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "130","33","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "131","33","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "132","33","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "133","34","1","1","1","1","2","3000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "134","34","1","2","2","0","2","3000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "135","34","1","2","2","1","2","3000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "136","34","1","3","2","1","2","3000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "137","35","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "138","35","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "139","35","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "140","35","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "141","36","1","1","1","1","2","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "142","36","1","2","2","0","2","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "143","36","1","2","2","1","2","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "144","36","1","3","2","1","2","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "145","37","1","1","1","1","2","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "146","37","1","2","2","0","2","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "147","37","1","2","2","1","2","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "148","37","1","3","2","1","2","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "149","38","1","1","1","1","2","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "150","38","1","2","2","0","2","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "151","38","1","2","2","1","2","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "152","38","1","3","2","1","2","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "153","39","2","1","1","1","1","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "154","39","2","2","2","0","1","1000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "155","39","2","2","2","1","1","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "156","39","2","3","2","1","1","1000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "157","40","1","1","1","1","2","3000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "158","40","1","2","2","0","2","3000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "159","40","1","2","2","1","2","3000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "160","40","1","3","2","1","2","3000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "161","41","2","1","1","1","1","3000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "162","41","2","2","2","0","1","3000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "163","41","2","2","2","1","1","3000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "164","41","2","3","2","1","1","3000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "165","42","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "166","42","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "167","42","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "168","42","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "169","43","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "170","43","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "171","43","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "172","43","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "173","44","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "174","44","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "175","44","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "176","44","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "177","45","1","1","1","1","1","2000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "178","45","1","2","2","0","1","2000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "179","45","1","2","2","1","1","2000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "180","45","1","3","2","1","1","2000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "181","46","1","1","1","1","3","30000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "182","46","1","2","2","0","3","30000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "183","46","1","2","2","1","3","30000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "184","46","1","3","2","1","3","30000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "185","47","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "186","47","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "187","47","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "188","47","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "189","48","1","1","1","1","2","2000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "190","48","1","2","2","0","2","2000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "191","48","1","2","2","1","2","2000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "192","48","1","3","2","1","2","2000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "193","49","1","1","1","1","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "194","49","1","2","2","0","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "195","49","1","2","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "196","49","1","3","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "197","50","1","1","1","1","1","20000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "198","50","1","2","2","0","1","20000000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "199","50","1","2","2","1","1","20000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "200","50","1","3","2","1","1","20000000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "201","51","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "202","51","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "203","51","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "204","51","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "205","52","2","1","1","1","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "206","52","2","2","2","0","2","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "207","52","2","2","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "208","52","2","3","2","1","2","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "209","53","1","1","1","1","2","3000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "210","53","1","2","2","0","2","3000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "211","53","1","2","2","1","2","3000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "212","53","1","3","2","1","2","3000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "213","54","1","1","1","1","3","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "214","54","1","2","2","0","3","4000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "215","54","1","2","2","1","3","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "216","54","1","3","2","1","3","4000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "217","55","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "218","55","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "219","55","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "220","55","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "221","56","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "222","56","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "223","56","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "224","56","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "227","58","1","1","1","1","2","916.670","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "228","58","1","2","2","0","2","916.670","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "229","59","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "230","59","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "231","59","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "232","59","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "233","60","1","1","1","1","2","2000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "234","60","1","2","2","0","2","2000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "235","60","1","2","2","1","2","2000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "236","60","1","3","2","1","2","2000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "237","61","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "238","61","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "239","61","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "240","61","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "241","62","1","1","1","1","2","100.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "242","62","1","2","2","0","2","100.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "243","62","1","2","2","1","2","100.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "244","62","1","3","2","1","2","100.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "245","63","1","1","1","1","2","3000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "246","63","1","2","2","0","2","3000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "247","63","1","2","2","1","2","3000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "248","63","1","3","2","1","2","3000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "249","64","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "250","64","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "251","64","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "252","64","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "253","65","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "254","65","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "255","65","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "256","65","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "257","66","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "258","66","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "259","66","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "260","66","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "261","67","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "262","67","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "263","67","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "264","67","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "265","70","1","1","1","1","2","22.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "266","70","1","2","2","0","2","22.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "267","70","1","2","2","1","2","22.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "268","70","1","3","2","1","2","22.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "269","71","1","1","1","1","2","22.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "270","71","1","2","2","0","2","22.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "271","71","1","2","2","1","2","22.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "272","71","1","3","2","1","2","22.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "273","72","1","1","1","1","2","22.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "274","72","1","2","2","0","2","22.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "275","72","1","2","2","1","2","22.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "276","72","1","3","2","1","2","22.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "277","73","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "278","73","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "279","73","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "280","73","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "281","74","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "282","74","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "283","74","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "284","74","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "285","75","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "286","75","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "287","75","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "288","75","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "289","76","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "290","76","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "291","76","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "292","76","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "293","77","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "294","77","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "295","77","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "296","77","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "297","78","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "298","78","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "299","78","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "300","78","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "301","79","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "302","79","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "303","79","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "304","79","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "305","80","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "306","80","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "307","80","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "308","80","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "309","81","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "310","81","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "311","81","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "312","81","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "313","82","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "314","82","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "315","82","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "316","82","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "317","83","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "318","83","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "319","83","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "320","83","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "321","84","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "322","84","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "323","84","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "324","84","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "325","85","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "326","85","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "327","85","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "328","85","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "329","86","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "330","86","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "331","86","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "332","86","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "333","87","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "334","87","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "335","87","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "336","87","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "337","88","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "338","88","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "339","88","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "340","88","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "341","89","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "342","89","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "343","89","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "344","89","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "345","90","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "346","90","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "347","90","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "348","90","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "349","91","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "350","91","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "351","91","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "352","91","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "353","92","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "354","92","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "355","92","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "356","92","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "357","93","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "358","93","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "359","93","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "360","93","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "361","94","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "362","94","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "363","94","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "364","94","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "365","95","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "366","95","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "367","95","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "368","95","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "369","96","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "370","96","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "371","96","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "372","96","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "373","97","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "374","97","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "375","97","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "376","97","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "377","98","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "378","98","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "379","98","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "380","98","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "381","99","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "382","99","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "383","99","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "384","99","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "385","100","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "386","100","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "387","100","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "388","100","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "389","101","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "390","101","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "391","101","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "392","101","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "393","102","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "394","102","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "395","102","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "396","102","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "397","103","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "398","103","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "399","103","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "400","103","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "401","104","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "402","104","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "403","104","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "404","104","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "405","105","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "406","105","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "407","105","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "408","105","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "409","106","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "410","106","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "411","106","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "412","106","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "413","107","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "414","107","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "415","107","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "416","107","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "417","108","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "418","108","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "419","108","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "420","108","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "421","109","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "422","109","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "423","109","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "424","109","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "425","110","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "426","110","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "427","110","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "428","110","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "429","111","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "430","111","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "431","111","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "432","111","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "433","112","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "434","112","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "435","112","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "436","112","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "437","113","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "438","113","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "439","113","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "440","113","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "441","114","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "442","114","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "443","114","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "444","114","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "445","115","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "446","115","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "447","115","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "448","115","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "449","116","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "450","116","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "451","116","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "452","116","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "453","117","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "454","117","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "455","117","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "456","117","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "457","118","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "458","118","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "459","118","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "460","118","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "461","119","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "462","119","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "463","119","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "464","119","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "465","120","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "466","120","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "467","120","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "468","120","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "469","121","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "470","121","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "471","121","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "472","121","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "473","122","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "474","122","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "475","122","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "476","122","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "477","123","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "478","123","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "479","123","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "480","123","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "481","124","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "482","124","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "483","124","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "484","124","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "485","125","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "486","125","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "487","125","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "488","125","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "489","126","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "490","126","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "491","126","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "492","126","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "493","127","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "494","127","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "495","127","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "496","127","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "497","128","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "498","128","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "499","128","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "500","128","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "501","129","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "502","129","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "503","129","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "504","129","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "505","130","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "506","130","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "507","130","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "508","130","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "509","131","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "510","131","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "511","131","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "512","131","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "513","132","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "514","132","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "515","132","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "516","132","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "517","133","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "518","133","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "519","133","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "520","133","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "521","134","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "522","134","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "523","134","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "524","134","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "525","135","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "526","135","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "527","135","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "528","135","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "529","136","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "530","136","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "531","136","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "532","136","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "533","137","1","1","1","1","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "534","137","1","2","2","0","2","1200.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "535","137","1","2","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "536","137","1","3","2","1","2","1200.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "537","138","1","1","1","1","2","2400.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "538","138","1","2","2","0","2","2400.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "539","138","1","2","2","1","2","2400.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "540","138","1","3","2","1","2","2400.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "541","139","1","1","1","1","2","2400.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "542","139","1","2","2","0","2","2400.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "543","139","1","2","2","1","2","2400.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "544","139","1","3","2","1","2","2400.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "545","140","1","1","1","1","2","2400.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "546","140","1","2","2","0","2","2400.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "547","140","1","2","2","1","2","2400.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "548","140","1","3","2","1","2","2400.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "549","141","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "550","141","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "551","141","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "552","141","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "553","142","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "554","142","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "555","142","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "556","142","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "557","143","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "558","143","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "559","143","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "560","143","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "565","145","1","1","1","1","1","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "566","145","1","2","2","0","1","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "567","145","1","2","2","1","1","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "568","145","1","3","2","1","1","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "569","146","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "570","146","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "571","146","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "572","146","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "573","147","1","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "574","147","1","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "575","147","1","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "576","147","1","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "577","148","7","1","1","1","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "578","148","7","2","2","0","2","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "579","148","7","2","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "580","148","7","3","2","1","2","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "581","149","1","1","1","1","1","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "582","149","1","2","2","0","1","1000.000","0","1","1","");
INSERT INTO `ln_journal_detail`  VALUES ( "583","149","1","2","2","1","1","1000.000","0","1","1","Admin fee from disburse loan ");
INSERT INTO `ln_journal_detail`  VALUES ( "584","149","1","3","2","1","1","1000.000","0","1","1","Admin fee from disburse loan ");


--
-- Tabel structure for table `ln_loan_group`
--
DROP TABLE  IF EXISTS `ln_loan_group`;
CREATE TABLE `ln_loan_group` (
  `g_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` int(20) DEFAULT '1' COMMENT '?????? ???????????????',
  `group_id` int(11) DEFAULT NULL COMMENT '?????????? =client id of group',
  `co_id` int(11) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `date_release` date DEFAULT NULL,
  `date_line` date DEFAULT NULL COMMENT 'life of loan',
  `create_date` date DEFAULT NULL,
  `total_duration` int(11) DEFAULT NULL COMMENT '??????????',
  `first_payment` date DEFAULT NULL,
  `time_collect` varchar(30) DEFAULT NULL,
  `collect_typeterm` tinyint(4) DEFAULT NULL COMMENT '???? month ,week, day',
  `pay_term` tinyint(4) DEFAULT NULL COMMENT '?????? ??? week ,day',
  `payment_method` int(11) DEFAULT NULL,
  `holiday` tinyint(4) DEFAULT NULL,
  `is_renew` tinyint(4) DEFAULT '0' COMMENT '0=old list,1=new list',
  `branch_id` int(11) DEFAULT '1',
  `loan_type` tinyint(4) DEFAULT '1' COMMENT '1=individule,2=group',
  `status` tinyint(4) DEFAULT '1' COMMENT '0 deactive ,1 active ,2 complated',
  `is_verify` tinyint(4) DEFAULT '0',
  `is_badloan` tinyint(4) DEFAULT '0',
  `teller_id` int(11) DEFAULT NULL,
  `is_reschedule` tinyint(4) DEFAULT '0' COMMENT '?????? reschedule ???? befor reschedul 1,2=after',
  `user_id` int(11) DEFAULT NULL,
  `for_loantype` int(11) DEFAULT NULL,
  `reschedule_opt` tinyint(4) DEFAULT '0' COMMENT '?????????reschedule ????1= new schedule , 2 overide old schedule',
  PRIMARY KEY (`g_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `ln_loan_group`  VALUES ( "1","1","30","2","1","2015-08-04","2016-08-04","2015-08-04","12","2015-09-04","10:00-11:00 AM","3","3","1","2","0","1","2","1","0","0","","0","","1","0");
INSERT INTO `ln_loan_group`  VALUES ( "2","1","1","6","1","2015-08-05","2016-09-05","2015-08-05","12","2015-09-05","10:00-11:00 AM","3","3","1","2","0","1","1","1","0","0","","0","","1","0");
INSERT INTO `ln_loan_group`  VALUES ( "3","1","33","15","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","1","1","0","0","","0","","1","0");
INSERT INTO `ln_loan_group`  VALUES ( "4","1","2","1","21","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","1","1","0","0","","0","","103","0");
INSERT INTO `ln_loan_group`  VALUES ( "5","1","8","2","1","2015-08-10","2016-08-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","2","1","0","0","","0","","1","0");
INSERT INTO `ln_loan_group`  VALUES ( "6","1","8","2","1","2015-08-10","2016-08-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","2","1","0","0","","0","","1","0");
INSERT INTO `ln_loan_group`  VALUES ( "7","1","34","1","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","3","2","0","8","1","1","0","0","","1","","3","0");
INSERT INTO `ln_loan_group`  VALUES ( "8","1","8","2","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","2","3","0","1","1","1","0","0","","0","","1","0");
INSERT INTO `ln_loan_group`  VALUES ( "12","1","34","1","1","2015-08-11","2016-06-11","2015-08-11","10","2015-09-11","10:00-11:00 AM","3","3","3","2","1","8","1","1","0","0","","2","1","1","1");


--
-- Tabel structure for table `ln_loan_member`
--
DROP TABLE  IF EXISTS `ln_loan_member`;
CREATE TABLE `ln_loan_member` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) DEFAULT NULL COMMENT 'from chart account 1',
  `group_id` int(11) DEFAULT NULL,
  `loan_number` varchar(20) DEFAULT NULL COMMENT 'first is branch then 5',
  `client_id` int(11) DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `currency_type` tinyint(4) DEFAULT NULL COMMENT '1=khmer ,2=dollar',
  `total_capital` float(15,2) DEFAULT NULL,
  `admin_fee` float(15,2) DEFAULT NULL,
  `other_fee` float(15,2) DEFAULT NULL,
  `collect_typeterm` tinyint(4) DEFAULT NULL,
  `interest_rate` float(10,2) NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `branch_id` int(11) unsigned DEFAULT '1',
  `loan_cycle` tinyint(4) DEFAULT '0' COMMENT '1= is loan cycle,0 not loan cycle',
  `loan_purpose` text,
  `pay_before` varchar(30) DEFAULT '0' COMMENT '??????????????',
  `pay_after` varchar(30) DEFAULT '0' COMMENT '??????????????',
  `graice_period` int(11) DEFAULT '0',
  `amount_collect_principal` float(15,2) DEFAULT NULL,
  `show_barcode` tinyint(4) DEFAULT '0' COMMENT '1 show,0 not show',
  `is_completed` tinyint(4) DEFAULT '0' COMMENT '0 yet,1 complete,2=some fund',
  `semi` int(11) DEFAULT '1' COMMENT '?????????????????????? ?? ????????????????????????',
  `is_reschedule` tinyint(4) DEFAULT '0' COMMENT '?????? reschedule ???? befor reschedul 1,2=after',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `ln_loan_member`  VALUES ( "1","","1","PPL00001","30","1","2","1200.00","12.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "2","","1","PPL00002","31","1","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "3","","2","PPL00003","1","1","2","2000.00","20.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "4","","3","PPL00004","33","1","2","1200.00","12.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "5","","4","PPL00005","2","1","2","1500.00","15.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "6","","5","PPL00006","8","1","2","2000.00","20.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "7","","5","PPL00007","26","1","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "8","","5","PPL00008","29","1","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "9","","6","PPL00009","8","1","2","2000.00","20.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "10","","6","PPL00010","26","1","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "11","","6","PPL00011","29","1","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "12","","7","PTL00001","34","3","1","40000.00","400.00","0.00","3","2.50","1","8","0","","0","2","0","1.00","0","0","0","1");
INSERT INTO `ln_loan_member`  VALUES ( "13","","8","PPL00012","8","2","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_loan_member`  VALUES ( "14","","12","PTL00001R","34","3","1","40000.00","0.00","0.00","3","2.50","1","8","0","","0","2","0","1.00","0","0","0","2");


--
-- Tabel structure for table `ln_loanmember_funddetail`
--
DROP TABLE  IF EXISTS `ln_loanmember_funddetail`;
CREATE TABLE `ln_loanmember_funddetail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `total_principal` float(15,2) DEFAULT NULL,
  `principal_permonth` float(15,2) DEFAULT NULL,
  `principle_after` float(15,2) DEFAULT NULL COMMENT '??????????????????????????',
  `total_interest` float(15,2) DEFAULT NULL COMMENT '??????????????????????',
  `total_interest_after` float(15,2) DEFAULT NULL,
  `total_payment` float(15,2) DEFAULT NULL,
  `total_payment_after` float(15,2) DEFAULT NULL,
  `amount_day` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `is_completed` tinyint(4) DEFAULT '0' COMMENT '0=not complete,1=complete,2=in progress',
  `is_approved` tinyint(4) DEFAULT '0' COMMENT '1=approved paycomplete,not yet',
  `date_payment` date DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `collect_by` int(11) DEFAULT '1' COMMENT '?????????????',
  `payment_option` tinyint(4) DEFAULT NULL COMMENT '1=normal,2=before,3=after',
  `penelize` float(15,2) DEFAULT '0.00',
  `service_charge` float(15,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8;

INSERT INTO `ln_loanmember_funddetail`  VALUES ( "1","1","1200.00","100.00","100.00","31.00","31.00","131.00","131.00","31","1","0","0","2015-09-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "2","1","1100.00","100.00","100.00","28.42","28.42","128.42","128.42","31","1","0","0","2015-10-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "3","1","1000.00","100.00","100.00","25.00","25.00","125.00","125.00","30","1","0","0","2015-11-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "4","1","900.00","100.00","100.00","22.50","22.50","122.50","122.50","30","1","0","0","2015-12-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "5","1","800.00","100.00","100.00","20.67","20.67","120.67","120.67","31","1","0","0","2016-01-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "6","1","700.00","100.00","100.00","18.08","18.08","118.08","118.08","31","1","0","0","2016-02-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "7","1","600.00","100.00","100.00","14.50","14.50","114.50","114.50","29","1","0","0","2016-03-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "8","1","500.00","100.00","100.00","12.92","12.92","112.92","112.92","31","1","0","0","2016-04-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "9","1","400.00","100.00","100.00","10.00","10.00","110.00","110.00","30","1","0","0","2016-05-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "10","1","300.00","100.00","100.00","8.25","8.25","108.25","108.25","33","1","0","0","2016-06-06","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "11","1","200.00","100.00","100.00","4.67","4.67","104.67","104.67","28","1","0","0","2016-07-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "12","1","100.00","100.00","100.00","2.58","2.58","102.58","102.58","31","1","0","0","2016-08-04","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "13","2","1000.00","83.33","83.33","25.83","25.83","109.17","109.17","31","1","0","0","2015-09-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "14","2","916.67","83.33","83.33","23.68","23.68","107.01","107.01","31","1","0","0","2015-10-05","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "15","2","833.33","83.33","83.33","20.83","20.83","104.17","104.17","30","1","0","0","2015-11-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "16","2","750.00","83.33","83.33","18.75","18.75","102.08","102.08","30","1","0","0","2015-12-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "17","2","666.67","83.33","83.33","17.22","17.22","100.56","100.56","31","1","0","0","2016-01-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "18","2","583.33","83.33","83.33","15.07","15.07","98.40","98.40","31","1","0","0","2016-02-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "19","2","500.00","83.33","83.33","12.08","12.08","95.42","95.42","29","1","0","0","2016-03-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "20","2","416.67","83.33","83.33","10.76","10.76","94.10","94.10","31","1","0","0","2016-04-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "21","2","333.33","83.33","83.33","8.33","8.33","91.67","91.67","30","1","0","0","2016-05-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "22","2","250.00","83.33","83.33","6.88","6.88","90.21","90.21","33","1","0","0","2016-06-06","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "23","2","166.67","83.33","83.33","3.89","3.89","87.22","87.22","28","1","0","0","2016-07-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "24","2","83.33","83.33","83.33","2.15","2.15","85.49","85.49","31","1","0","0","2016-08-04","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "25","3","2000.00","166.67","166.67","51.67","51.67","218.34","218.34","31","1","1","0","2015-09-05","1","6","1","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "26","3","1833.33","166.67","166.67","45.83","45.83","212.50","212.50","30","1","0","0","2015-10-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "27","3","1666.66","166.67","166.67","43.06","43.06","209.73","209.73","31","1","0","0","2015-11-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "28","3","1499.99","166.67","166.67","40.00","40.00","206.67","206.67","32","1","0","0","2015-12-07","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "29","3","1333.32","166.67","166.67","32.22","32.22","198.89","198.89","29","1","0","0","2016-01-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "30","3","1166.65","166.67","166.67","30.14","30.14","196.81","196.81","31","1","0","0","2016-02-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "31","3","999.98","166.67","166.67","25.83","25.83","192.50","192.50","31","1","0","0","2016-03-07","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "32","3","833.31","166.67","166.67","20.14","20.14","186.81","186.81","29","1","0","0","2016-04-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "33","3","666.64","166.67","166.67","16.67","16.67","183.34","183.34","30","1","0","0","2016-05-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "34","3","499.97","166.67","166.67","13.33","13.33","180.00","180.00","32","1","0","0","2016-06-06","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "35","3","333.30","166.67","166.67","8.05","8.05","174.72","174.72","29","1","0","0","2016-07-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "36","3","166.63","166.63","166.63","4.30","4.30","170.93","170.93","31","1","0","0","2016-08-05","1","7","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "37","4","1200.00","100.00","100.00","31.00","31.00","131.00","131.00","31","1","0","0","2015-09-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "38","4","1100.00","100.00","100.00","29.33","29.33","129.33","129.33","32","1","0","0","2015-10-12","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "39","4","1000.00","100.00","100.00","24.17","24.17","124.17","124.17","29","1","0","0","2015-11-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "40","4","900.00","100.00","100.00","22.50","22.50","122.50","122.50","30","1","0","0","2015-12-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "41","4","800.00","100.00","100.00","21.33","21.33","121.33","121.33","32","1","0","0","2016-01-11","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "42","4","700.00","100.00","100.00","17.50","17.50","117.50","117.50","30","1","0","0","2016-02-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "43","4","600.00","100.00","100.00","14.50","14.50","114.50","114.50","29","1","0","0","2016-03-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "44","4","500.00","100.00","100.00","13.33","13.33","113.33","113.33","32","1","0","0","2016-04-11","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "45","4","400.00","100.00","100.00","9.67","9.67","109.67","109.67","29","1","0","0","2016-05-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "46","4","300.00","100.00","100.00","7.75","7.75","107.75","107.75","31","1","0","0","2016-06-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "47","4","200.00","100.00","100.00","5.17","5.17","105.17","105.17","31","1","0","0","2016-07-11","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "48","4","100.00","100.00","100.00","2.50","2.50","102.50","102.50","30","1","0","0","2016-08-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "49","5","1500.00","125.00","125.00","38.75","38.75","163.75","163.75","31","0","0","0","2015-09-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "50","5","1375.00","125.00","125.00","36.67","36.67","161.67","161.67","32","0","0","0","2015-10-12","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "51","5","1250.00","125.00","125.00","30.21","30.21","155.21","155.21","29","0","0","0","2015-11-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "52","5","1125.00","125.00","125.00","28.13","28.13","153.13","153.13","30","0","0","0","2015-12-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "53","5","1000.00","125.00","125.00","26.67","26.67","151.67","151.67","32","0","0","0","2016-01-11","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "54","5","875.00","125.00","125.00","21.88","21.88","146.88","146.88","30","0","0","0","2016-02-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "55","5","750.00","125.00","125.00","18.13","18.13","143.13","143.13","29","0","0","0","2016-03-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "56","5","625.00","125.00","125.00","16.67","16.67","141.67","141.67","32","0","0","0","2016-04-11","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "57","5","500.00","125.00","125.00","12.08","12.08","137.08","137.08","29","0","0","0","2016-05-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "58","5","375.00","125.00","125.00","9.69","9.69","134.69","134.69","31","0","0","0","2016-06-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "59","5","250.00","125.00","125.00","6.46","6.46","131.46","131.46","31","0","0","0","2016-07-11","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "60","5","125.00","125.00","125.00","3.13","3.13","128.13","128.13","30","0","0","0","2016-08-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "61","6","2000.00","166.67","166.67","51.67","51.67","218.33","218.33","31","1","0","0","2015-09-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "62","6","1833.33","166.67","166.67","48.89","48.89","215.56","215.56","32","1","0","0","2015-10-12","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "63","6","1666.67","166.67","166.67","40.28","40.28","206.94","206.94","29","1","0","0","2015-11-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "64","6","1500.00","166.67","166.67","37.50","37.50","204.17","204.17","30","1","0","0","2015-12-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "65","6","1333.33","166.67","166.67","35.56","35.56","202.22","202.22","32","1","0","0","2016-01-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "66","6","1166.67","166.67","166.67","29.17","29.17","195.83","195.83","30","1","0","0","2016-02-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "67","6","1000.00","166.67","166.67","24.17","24.17","190.83","190.83","29","1","0","0","2016-03-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "68","6","833.33","166.67","166.67","22.22","22.22","188.89","188.89","32","1","0","0","2016-04-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "69","6","666.67","166.67","166.67","16.11","16.11","182.78","182.78","29","1","0","0","2016-05-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "70","6","500.00","166.67","166.67","12.92","12.92","179.58","179.58","31","1","0","0","2016-06-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "71","6","333.33","166.67","166.67","8.61","8.61","175.28","175.28","31","1","0","0","2016-07-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "72","6","166.67","166.67","166.67","4.17","4.17","170.83","170.83","30","1","0","0","2016-08-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "73","7","1000.00","83.33","83.33","25.83","25.83","109.17","109.17","31","1","0","0","2015-09-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "74","7","916.67","83.33","83.33","24.44","24.44","107.78","107.78","32","1","0","0","2015-10-12","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "75","7","833.33","83.33","83.33","20.14","20.14","103.47","103.47","29","1","0","0","2015-11-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "76","7","750.00","83.33","83.33","18.75","18.75","102.08","102.08","30","1","0","0","2015-12-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "77","7","666.67","83.33","83.33","17.78","17.78","101.11","101.11","32","1","0","0","2016-01-11","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "78","7","583.33","83.33","83.33","14.58","14.58","97.92","97.92","30","1","0","0","2016-02-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "79","7","500.00","83.33","83.33","12.08","12.08","95.42","95.42","29","1","0","0","2016-03-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "80","7","416.67","83.33","83.33","11.11","11.11","94.44","94.44","32","1","0","0","2016-04-11","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "81","7","333.33","83.33","83.33","8.06","8.06","91.39","91.39","29","1","0","0","2016-05-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "82","7","250.00","83.33","83.33","6.46","6.46","89.79","89.79","31","1","0","0","2016-06-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "83","7","166.67","83.33","83.33","4.31","4.31","87.64","87.64","31","1","0","0","2016-07-11","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "84","7","83.33","83.33","83.33","2.08","2.08","85.42","85.42","30","1","0","0","2016-08-10","1","15","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "85","8","1000.00","83.33","83.33","25.83","25.83","109.17","109.17","31","1","0","0","2015-09-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "86","8","916.67","83.33","83.33","24.44","24.44","107.78","107.78","32","1","0","0","2015-10-12","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "87","8","833.33","83.33","83.33","20.14","20.14","103.47","103.47","29","1","0","0","2015-11-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "88","8","750.00","83.33","83.33","18.75","18.75","102.08","102.08","30","1","0","0","2015-12-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "89","8","666.67","83.33","83.33","17.78","17.78","101.11","101.11","32","1","0","0","2016-01-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "90","8","583.33","83.33","83.33","14.58","14.58","97.92","97.92","30","1","0","0","2016-02-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "91","8","500.00","83.33","83.33","12.08","12.08","95.42","95.42","29","1","0","0","2016-03-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "92","8","416.67","83.33","83.33","11.11","11.11","94.44","94.44","32","1","0","0","2016-04-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "93","8","333.33","83.33","83.33","8.06","8.06","91.39","91.39","29","1","0","0","2016-05-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "94","8","250.00","83.33","83.33","6.46","6.46","89.79","89.79","31","1","0","0","2016-06-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "95","8","166.67","83.33","83.33","4.31","4.31","87.64","87.64","31","1","0","0","2016-07-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "96","8","83.33","83.33","83.33","2.08","2.08","85.42","85.42","30","1","0","0","2016-08-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "97","9","2000.00","166.67","166.67","51.67","51.67","218.33","218.33","31","1","0","0","2015-09-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "98","9","1833.33","166.67","166.67","48.89","48.89","215.56","215.56","32","1","0","0","2015-10-12","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "99","9","1666.67","166.67","166.67","40.28","40.28","206.94","206.94","29","1","0","0","2015-11-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "100","9","1500.00","166.67","166.67","37.50","37.50","204.17","204.17","30","1","0","0","2015-12-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "101","9","1333.33","166.67","166.67","35.56","35.56","202.22","202.22","32","1","0","0","2016-01-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "102","9","1166.67","166.67","166.67","29.17","29.17","195.83","195.83","30","1","0","0","2016-02-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "103","9","1000.00","166.67","166.67","24.17","24.17","190.83","190.83","29","1","0","0","2016-03-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "104","9","833.33","166.67","166.67","22.22","22.22","188.89","188.89","32","1","0","0","2016-04-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "105","9","666.67","166.67","166.67","16.11","16.11","182.78","182.78","29","1","0","0","2016-05-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "106","9","500.00","166.67","166.67","12.92","12.92","179.58","179.58","31","1","0","0","2016-06-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "107","9","333.33","166.67","166.67","8.61","8.61","175.28","175.28","31","1","0","0","2016-07-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "108","9","166.67","166.67","166.67","4.17","4.17","170.83","170.83","30","1","0","0","2016-08-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "109","10","1000.00","83.33","83.33","25.83","25.83","109.17","109.17","31","1","0","0","2015-09-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "110","10","916.67","83.33","83.33","24.44","24.44","107.78","107.78","32","1","0","0","2015-10-12","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "111","10","833.33","83.33","83.33","20.14","20.14","103.47","103.47","29","1","0","0","2015-11-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "112","10","750.00","83.33","83.33","18.75","18.75","102.08","102.08","30","1","0","0","2015-12-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "113","10","666.67","83.33","83.33","17.78","17.78","101.11","101.11","32","1","0","0","2016-01-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "114","10","583.33","83.33","83.33","14.58","14.58","97.92","97.92","30","1","0","0","2016-02-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "115","10","500.00","83.33","83.33","12.08","12.08","95.42","95.42","29","1","0","0","2016-03-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "116","10","416.67","83.33","83.33","11.11","11.11","94.44","94.44","32","1","0","0","2016-04-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "117","10","333.33","83.33","83.33","8.06","8.06","91.39","91.39","29","1","0","0","2016-05-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "118","10","250.00","83.33","83.33","6.46","6.46","89.79","89.79","31","1","0","0","2016-06-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "119","10","166.67","83.33","83.33","4.31","4.31","87.64","87.64","31","1","0","0","2016-07-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "120","10","83.33","83.33","83.33","2.08","2.08","85.42","85.42","30","1","0","0","2016-08-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "121","11","1000.00","83.33","83.33","25.83","25.83","109.17","109.17","31","1","0","0","2015-09-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "122","11","916.67","83.33","83.33","24.44","24.44","107.78","107.78","32","1","0","0","2015-10-12","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "123","11","833.33","83.33","83.33","20.14","20.14","103.47","103.47","29","1","0","0","2015-11-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "124","11","750.00","83.33","83.33","18.75","18.75","102.08","102.08","30","1","0","0","2015-12-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "125","11","666.67","83.33","83.33","17.78","17.78","101.11","101.11","32","1","0","0","2016-01-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "126","11","583.33","83.33","83.33","14.58","14.58","97.92","97.92","30","1","0","0","2016-02-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "127","11","500.00","83.33","83.33","12.08","12.08","95.42","95.42","29","1","0","0","2016-03-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "128","11","416.67","83.33","83.33","11.11","11.11","94.44","94.44","32","1","0","0","2016-04-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "129","11","333.33","83.33","83.33","8.06","8.06","91.39","91.39","29","1","0","0","2016-05-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "130","11","250.00","83.33","83.33","6.46","6.46","89.79","89.79","31","1","0","0","2016-06-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "131","11","166.67","83.33","83.33","4.31","4.31","87.64","87.64","31","1","0","0","2016-07-11","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "132","11","83.33","83.33","83.33","2.08","2.08","85.42","85.42","30","1","0","0","2016-08-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "133","4","1500.00","125.00","125.00","38.75","38.75","163.75","163.75","31","1","0","0","2015-09-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "134","4","1375.00","125.00","125.00","36.67","36.67","161.67","161.67","32","1","0","0","2015-10-12","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "135","4","1250.00","125.00","125.00","30.21","30.21","155.21","155.21","29","1","0","0","2015-11-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "136","4","1125.00","125.00","125.00","28.13","28.13","153.13","153.13","30","1","0","0","2015-12-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "137","4","1000.00","125.00","125.00","26.67","26.67","151.67","151.67","32","1","0","0","2016-01-11","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "138","4","875.00","125.00","125.00","21.88","21.88","146.88","146.88","30","1","0","0","2016-02-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "139","4","750.00","125.00","125.00","18.13","18.13","143.13","143.13","29","1","0","0","2016-03-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "140","4","625.00","125.00","125.00","16.67","16.67","141.67","141.67","32","1","0","0","2016-04-11","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "141","4","500.00","125.00","125.00","12.08","12.08","137.08","137.08","29","1","0","0","2016-05-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "142","4","375.00","125.00","125.00","9.69","9.69","134.69","134.69","31","1","0","0","2016-06-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "143","4","250.00","125.00","125.00","6.46","6.46","131.46","131.46","31","1","0","0","2016-07-11","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "144","4","125.00","125.00","125.00","3.13","3.13","128.13","128.13","30","1","0","0","2016-08-10","1","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "145","12","40000.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","31","1","0","0","2015-09-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "146","12","36600.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","32","1","0","0","2015-10-12","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "147","12","33200.00","3400.00","3400.00","1000.00","1000.00","4400.00","4400.00","29","1","0","0","2015-11-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "148","12","29800.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","30","1","0","0","2015-12-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "149","12","26400.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","32","1","0","0","2016-01-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "150","12","23000.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","30","1","0","0","2016-02-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "151","12","19600.00","3400.00","3400.00","1000.00","1000.00","4400.00","4400.00","29","1","0","0","2016-03-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "152","12","16200.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","32","1","0","0","2016-04-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "153","12","12800.00","3400.00","3400.00","1000.00","1000.00","4400.00","4400.00","29","1","0","0","2016-05-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "154","12","9400.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","31","1","0","0","2016-06-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "155","12","6000.00","3400.00","3400.00","1100.00","1100.00","4500.00","4500.00","31","1","0","0","2016-07-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "156","12","2600.00","2600.00","2600.00","1100.00","1100.00","3700.00","3700.00","30","1","0","0","2016-08-10","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "157","13","1000.00","0.00","0.00","25.83","25.83","25.83","25.83","31","1","0","0","2015-09-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "158","13","1000.00","0.00","0.00","25.00","25.00","25.00","25.00","30","1","0","0","2015-10-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "159","13","1000.00","0.00","0.00","25.83","25.83","25.83","25.83","31","1","0","0","2015-11-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "160","13","1000.00","0.00","0.00","25.00","25.00","25.00","25.00","30","1","0","0","2015-12-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "161","13","1000.00","0.00","0.00","25.83","25.83","25.83","25.83","31","1","0","0","2016-01-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "162","13","1000.00","0.00","0.00","25.83","25.83","25.83","25.83","31","1","0","0","2016-02-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "163","13","1000.00","0.00","0.00","24.17","24.17","24.17","24.17","29","1","0","0","2016-03-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "164","13","1000.00","0.00","0.00","25.83","25.83","25.83","25.83","31","1","0","0","2016-04-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "165","13","1000.00","0.00","0.00","25.00","25.00","25.00","25.00","30","1","0","0","2016-05-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "166","13","1000.00","0.00","0.00","25.83","25.83","25.83","25.83","31","1","0","0","2016-06-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "167","13","1000.00","0.00","0.00","25.00","25.00","25.00","25.00","30","1","0","0","2016-07-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "168","13","1000.00","1000.00","1000.00","25.83","25.83","1025.83","1025.83","31","1","0","0","2016-08-10","1","2","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "169","14","40000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","31","1","0","0","2015-09-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "170","14","36000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","30","1","0","0","2015-10-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "171","14","32000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","31","1","0","0","2015-11-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "172","14","28000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","30","1","0","0","2015-12-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "173","14","24000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","31","1","0","0","2016-01-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "174","14","20000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","31","1","0","0","2016-02-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "175","14","16000.00","4000.00","4000.00","1000.00","1000.00","5000.00","5000.00","29","1","0","0","2016-03-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "176","14","12000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","31","1","0","0","2016-04-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "177","14","8000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","30","1","0","0","2016-05-11","8","1","","0.00","0.00");
INSERT INTO `ln_loanmember_funddetail`  VALUES ( "178","14","4000.00","4000.00","4000.00","1100.00","1100.00","5100.00","5100.00","31","1","0","0","2016-06-11","8","1","","0.00","0.00");


--
-- Tabel structure for table `ln_payment_method`
--
DROP TABLE  IF EXISTS `ln_payment_method`;
CREATE TABLE `ln_payment_method` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_nameen` varchar(50) DEFAULT NULL,
  `payment_namekh` varchar(50) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `ln_payment_method`  VALUES ( "1","Decline","???????????","","1");
INSERT INTO `ln_payment_method`  VALUES ( "2","Baloon","????????","","1");
INSERT INTO `ln_payment_method`  VALUES ( "3","Flat Rate","??????","","1");
INSERT INTO `ln_payment_method`  VALUES ( "4","Fixed Pyment(Full Last Period)","?????????????????","","1");
INSERT INTO `ln_payment_method`  VALUES ( "5","Semi Baloon","","","1");
INSERT INTO `ln_payment_method`  VALUES ( "6","Fixed Payment IRR","","","1");


--
-- Tabel structure for table `ln_permission`
--
DROP TABLE  IF EXISTS `ln_permission`;
CREATE TABLE `ln_permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `approve_by` int(11) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `permission_type` varchar(100) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `all_day` varchar(20) DEFAULT NULL,
  `paid_leave` varchar(20) DEFAULT NULL,
  `every_day` varchar(20) DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `ln_permission`  VALUES ( "1","7","1","1","2014-12-10","1","2014-12-23","2014-12-23","00:00:00","1","0","0","??","0","2014-12-24","1");
INSERT INTO `ln_permission`  VALUES ( "2","4","2","1","2014-12-12","4","2014-12-23","2014-12-23","09:51:08","1","1","0","????????????","0","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "3","3","1","6","2014-12-04","3","2014-12-23","2014-12-23","00:00:00","0","0","1","?????????","0","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "4","10","2","6","2014-12-04","2","2014-12-23","2014-12-23","00:00:00","0","1","0","????????????","1","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "5","6","1","4","2014-12-05","1","2014-12-24","2014-12-24","00:00:00","1","0","0","?????????","1","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "6","5","1","6","2014-12-19","1","2014-12-24","2014-12-24","00:00:00","1","1","0","????","1","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "9","8","1","1","2014-12-10","1","2014-12-23","2014-12-23","00:00:00","1","1","0","???????","1","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "10","1","2","8","2014-12-19","1","2014-12-24","2014-12-24","00:00:00","0","1","1","????","1","2014-12-24","1");
INSERT INTO `ln_permission`  VALUES ( "11","4","1","2","2014-12-01","1","2014-12-17","2014-12-26","05:55:00","1","0","0","???????","1","2015-01-17","1");
INSERT INTO `ln_permission`  VALUES ( "12","1","1","2","2014-12-12","3","2014-12-24","2014-12-24","00:00:00","0","1","0","????????????????","1","2014-12-24","1");
INSERT INTO `ln_permission`  VALUES ( "13","6","1","8","2014-12-17","1","2014-12-11","2014-12-24","00:00:00","0","0","1","?????????","1","2014-12-24","1");


--
-- Tabel structure for table `ln_position`
--
DROP TABLE  IF EXISTS `ln_position`;
CREATE TABLE `ln_position` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) DEFAULT NULL,
  `position_en` varchar(100) NOT NULL,
  `position_kh` varchar(100) NOT NULL,
  `date` varchar(30) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1 active ,0 deactive',
  `user_id` int(11) NOT NULL COMMENT 'user modify and create',
  `displayby` tinyint(4) DEFAULT '1' COMMENT '1 khmer ,2 english',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `ln_position`  VALUES ( "1","","Creditor Officer","????????????","Feb 23, 2014 6:04:30 AM","1","1","1");
INSERT INTO `ln_position`  VALUES ( "2","","Teller","??????????????","Feb 23, 2014 6:06:30 AM","1","1","1");
INSERT INTO `ln_position`  VALUES ( "4","","Accountant","?????????","Feb 23, 2014 6:12:47 AM","1","1","1");
INSERT INTO `ln_position`  VALUES ( "5","","Administrator Officer","???????","Feb 23, 2014 6:17:44 AM","1","1","1");
INSERT INTO `ln_position`  VALUES ( "6","","Branch Manager","????????????????????","Jun 1, 2014 4:05:12 PM","1","1","1");
INSERT INTO `ln_position`  VALUES ( "7","","Marketing ","??????","Jun 1, 2014 1:28:44 PM","1","1","1");
INSERT INTO `ln_position`  VALUES ( "8","","Operation","?????????????????","Jun 1, 2014 1:34:10 PM","1","1","1");


--
-- Tabel structure for table `ln_province`
--
DROP TABLE  IF EXISTS `ln_province`;
CREATE TABLE `ln_province` (
  `province_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `province_en_name` varchar(50) DEFAULT NULL,
  `province_kh_name` varchar(60) DEFAULT NULL,
  `modify_date` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `user_id` int(10) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT '1' COMMENT '1=kh,2=eng',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `ln_province`  VALUES ( "1","Phnom Penh","???????","Apr 6, 2015 7:17:50 PM","1","1","1","1");
INSERT INTO `ln_province`  VALUES ( "2","Battambang","????????","Apr 6, 2015 7:18:30 PM","1","1","1","1");
INSERT INTO `ln_province`  VALUES ( "3","Banteay Meanchey","????????????","Apr 6, 2015 7:18:14 PM","1","1","1","1");
INSERT INTO `ln_province`  VALUES ( "4","Kampong Cham","????????","Apr 6, 2015 7:18:45 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "5","Kampong Chhnang","???????????","Apr 6, 2015 7:19:10 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "6","Kampong Speu","?????????","Apr 6, 2015 7:19:25 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "7","Kampong Thom","???????","Apr 6, 2015 7:19:40 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "8","Kampot","????","Apr 6, 2015 7:19:52 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "9","Kandal","??????","Apr 6, 2015 7:20:07 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "10","Koh Kong","??????","Apr 6, 2015 7:20:22 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "11","Kratie","??????","Apr 6, 2015 7:21:06 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "12","Mondulkiri","?????????","Apr 6, 2015 7:21:20 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "13","Oddar Meancheay","Oddar Meancheay","Apr 6, 2015 7:14:26 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "14","Preah Vihear","?????????","Apr 6, 2015 7:22:11 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "15","Pursat","?????????","Apr 6, 2015 7:22:32 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "16","Prey Veng","???????","Apr 6, 2015 7:22:52 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "17","Ratanakiri","???????","Apr 6, 2015 7:23:08 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "18","Siem Reap","??????","Apr 6, 2015 7:23:23 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "19","Stung Treng","??????????","Apr 6, 2015 7:23:38 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "20","Svay Rieng","????????","Apr 6, 2015 7:23:56 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "21","Takeo","?????","Apr 6, 2015 7:24:25 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "22","Kep","???","Apr 6, 2015 7:20:35 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "23","Pailin","?????","Apr 6, 2015 7:21:55 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "24","Preah Sihanouk","?????????","Apr 6, 2015 7:17:28 PM","1","1","1","");
INSERT INTO `ln_province`  VALUES ( "25","Tbong Khmum","??????????","Apr 6, 2015 7:24:39 PM","1","1","1","");


--
-- Tabel structure for table `ln_referenct`
--
DROP TABLE  IF EXISTS `ln_referenct`;
CREATE TABLE `ln_referenct` (
  `ref_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_reschedule`
--
DROP TABLE  IF EXISTS `ln_reschedule`;
CREATE TABLE `ln_reschedule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `loan_number` varchar(30) DEFAULT NULL COMMENT '???ID ?? loan group table',
  `reschedule_date` date DEFAULT NULL,
  `re_amount` double(18,2) DEFAULT NULL,
  `re_interest_rate` float DEFAULT NULL,
  `maturity` date DEFAULT NULL,
  `re_payment_method` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `user_id` int(11) DEFAULT NULL,
  `re_loan_number` varchar(30) DEFAULT NULL COMMENT 'loan number after reschedule',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `ln_reschedule`  VALUES ( "1","PPL00002","2015-07-28","1200.00","2.5","2016-08-28","1","1","1","PPL00002R","");
INSERT INTO `ln_reschedule`  VALUES ( "2","PTL00001","2015-08-11","40000.00","2.5","2016-06-11","3","1","1","PTL00001R","");


--
-- Tabel structure for table `ln_return_collteral`
--
DROP TABLE  IF EXISTS `ln_return_collteral`;
CREATE TABLE `ln_return_collteral` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `giver_name` varchar(50) DEFAULT NULL,
  `receiver_name` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  `status` tinyint(2) DEFAULT '1' COMMENT '1=??????????',
  `user_id` int(11) DEFAULT NULL,
  `change_id` int(11) DEFAULT NULL COMMENT 'id from change id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='return client callateral';

INSERT INTO `ln_return_collteral`  VALUES ( "3","1","0","channy","ganeral customer-?????????","2015-08-13","return back to client","1","1","");


--
-- Tabel structure for table `ln_return_collteral_detail`
--
DROP TABLE  IF EXISTS `ln_return_collteral_detail`;
CREATE TABLE `ln_return_collteral_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `return_id` int(11) DEFAULT NULL COMMENT 'primary from return table',
  `collect_type` int(11) DEFAULT NULL,
  `owner_type` tinyint(4) DEFAULT NULL,
  `owner_name` varchar(50) DEFAULT NULL,
  `number_collteral` varchar(50) DEFAULT NULL,
  `note` varchar(200) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ln_return_collteral_detail`  VALUES ( "3","3","1","1","ganeral customer-?????????","322","return already","1");


--
-- Tabel structure for table `ln_salary`
--
DROP TABLE  IF EXISTS `ln_salary`;
CREATE TABLE `ln_salary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `staff_id` varchar(50) DEFAULT NULL,
  `basic_salary` float(12,2) DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_get_salary` date DEFAULT NULL,
  `for_month` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `detail` varchar(10) DEFAULT 'Click',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_salary_detail`
--
DROP TABLE  IF EXISTS `ln_salary_detail`;
CREATE TABLE `ln_salary_detail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bonus_id` int(11) DEFAULT NULL,
  `bonus_type` int(11) DEFAULT NULL,
  `amount` float(10,2) DEFAULT NULL,
  `note` text,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `ln_system_setting`
--
DROP TABLE  IF EXISTS `ln_system_setting`;
CREATE TABLE `ln_system_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keycode` varchar(150) DEFAULT NULL,
  `value` varchar(11) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `ln_system_setting`  VALUES ( "1","work_saturday","1","1=work on saturday 0 not work");
INSERT INTO `ln_system_setting`  VALUES ( "2","work_sunday","1","1=work on sunday 0 not work");
INSERT INTO `ln_system_setting`  VALUES ( "3","servername","localhost","");
INSERT INTO `ln_system_setting`  VALUES ( "4","dbuser","root","");
INSERT INTO `ln_system_setting`  VALUES ( "5","dbpassword","","");
INSERT INTO `ln_system_setting`  VALUES ( "6","dbname","db_loan","");
INSERT INTO `ln_system_setting`  VALUES ( "7","adminfee","1","10% of loan amount");
INSERT INTO `ln_system_setting`  VALUES ( "8","interest_late","2","????????????????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "9","graice_pariod_late","2","???????????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "10","reschedule_postfix","R","?????????????????????????????????????????????");
INSERT INTO `ln_system_setting`  VALUES ( "11","claro","Claro","");
INSERT INTO `ln_system_setting`  VALUES ( "12","nihilo","Nihilo","");
INSERT INTO `ln_system_setting`  VALUES ( "13","soria","Soria","");
INSERT INTO `ln_system_setting`  VALUES ( "14","tundra","tundra","");
INSERT INTO `ln_system_setting`  VALUES ( "15","theme_setting","4","");
INSERT INTO `ln_system_setting`  VALUES ( "17","send_teller","1","??????????????????");


--
-- Tabel structure for table `ln_test_loan_group`
--
DROP TABLE  IF EXISTS `ln_test_loan_group`;
CREATE TABLE `ln_test_loan_group` (
  `g_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` int(20) DEFAULT '1' COMMENT '?????? ???????????????',
  `group_id` int(11) DEFAULT NULL COMMENT '?????????? =client id of group',
  `co_id` int(11) DEFAULT NULL,
  `zone_id` int(11) DEFAULT NULL,
  `date_release` date DEFAULT NULL,
  `date_line` date DEFAULT NULL COMMENT 'life of loan',
  `create_date` date DEFAULT NULL,
  `total_duration` int(11) DEFAULT NULL COMMENT '??????????',
  `first_payment` date DEFAULT NULL,
  `time_collect` varchar(30) DEFAULT NULL,
  `collect_typeterm` tinyint(4) DEFAULT NULL COMMENT '???? month ,week, day',
  `pay_term` tinyint(4) DEFAULT NULL COMMENT '?????? ??? week ,day',
  `payment_method` int(11) DEFAULT NULL,
  `holiday` tinyint(4) DEFAULT NULL,
  `is_renew` tinyint(4) DEFAULT '0' COMMENT '0=old list,1=new list',
  `branch_id` int(11) DEFAULT '1',
  `loan_type` tinyint(4) DEFAULT '1' COMMENT '1=individule,2=group',
  `status` tinyint(4) DEFAULT '1' COMMENT '0 deactive ,1 active ,2 complated',
  `is_verify` tinyint(4) DEFAULT '0',
  `is_badloan` tinyint(4) DEFAULT '0',
  `teller_id` int(11) DEFAULT NULL,
  `is_reschedule` tinyint(4) DEFAULT '0' COMMENT '?????? reschedule ???? befor reschedul 1,2=after',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`g_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `ln_test_loan_group`  VALUES ( "1","1","33","15","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "2","1","2","1","21","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "3","1","2","1","21","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","1","2","0","1","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "4","1","34","1","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","3","2","0","8","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "5","1","34","1","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","3","2","0","8","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "6","1","1","1","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","3","2","0","1","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "7","1","1","1","1","2015-08-10","2016-09-10","2015-08-10","12","2015-09-10","10:00-11:00 AM","3","3","3","3","0","1","1","1","0","0","","0","");
INSERT INTO `ln_test_loan_group`  VALUES ( "8","1","2","1","1","2015-08-10","2016-07-10","2015-08-10","10","2015-09-10","10:00-11:00 AM","3","3","6","2","0","1","1","1","0","0","","0","");


--
-- Tabel structure for table `ln_test_loan_member`
--
DROP TABLE  IF EXISTS `ln_test_loan_member`;
CREATE TABLE `ln_test_loan_member` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) DEFAULT NULL COMMENT 'from chart account 1',
  `group_id` int(11) DEFAULT NULL,
  `loan_number` varchar(20) DEFAULT NULL COMMENT 'first is branch then 5',
  `client_id` int(11) DEFAULT NULL,
  `payment_method` int(11) DEFAULT NULL,
  `currency_type` tinyint(4) DEFAULT NULL COMMENT '1=khmer ,2=dollar',
  `total_capital` float(15,2) DEFAULT NULL,
  `admin_fee` float(15,2) DEFAULT NULL,
  `other_fee` float(15,2) DEFAULT NULL,
  `collect_typeterm` tinyint(4) DEFAULT NULL,
  `interest_rate` float(10,2) NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `branch_id` int(11) unsigned DEFAULT '1',
  `loan_cycle` tinyint(4) DEFAULT '0' COMMENT '1= is loan cycle,0 not loan cycle',
  `loan_purpose` text,
  `pay_before` varchar(30) DEFAULT '0' COMMENT '??????????????',
  `pay_after` varchar(30) DEFAULT '0' COMMENT '??????????????',
  `graice_period` int(11) DEFAULT '0',
  `amount_collect_principal` float(15,2) DEFAULT NULL,
  `show_barcode` tinyint(4) DEFAULT '0' COMMENT '1 show,0 not show',
  `is_completed` tinyint(4) DEFAULT '0' COMMENT '0 yet,1 complete,2=some fund',
  `semi` int(11) DEFAULT '1' COMMENT '?????????????????????? ?? ????????????????????????',
  `is_reschedule` tinyint(4) DEFAULT '0' COMMENT '?????? reschedule ???? befor reschedul 1,2=after',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `ln_test_loan_member`  VALUES ( "1","","1","PPL00004","33","1","2","1200.00","12.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "2","","2","PPL00005","2","1","2","1500.00","15.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "3","","3","PPL00005","2","1","2","1500.00","15.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "4","","4","PTL00001","34","3","2","1000.00","10.00","0.00","3","2.50","1","8","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "5","","5","PTL00001","34","3","1","40000.00","400.00","0.00","3","2.50","1","8","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "6","","6","PPL00013","1","3","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "7","","7","PPL00013","1","3","2","1000.00","10.00","0.00","3","2.50","1","1","0","","0","2","0","1.00","0","0","0","0");
INSERT INTO `ln_test_loan_member`  VALUES ( "8","","8","PPL00013","2","6","2","1000.00","10.00","0.00","3","2.00","1","1","0","","0","2","0","1.00","0","0","0","0");


--
-- Tabel structure for table `ln_test_loanmember_funddetail`
--
DROP TABLE  IF EXISTS `ln_test_loanmember_funddetail`;
CREATE TABLE `ln_test_loanmember_funddetail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `total_principal` float(15,2) DEFAULT NULL,
  `principal_permonth` float(15,2) DEFAULT NULL,
  `total_interest` float(15,2) DEFAULT NULL,
  `total_payment` float(15,2) DEFAULT NULL,
  `amount_day` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `is_completed` tinyint(4) DEFAULT '0' COMMENT '0=not complete,1=complete,2=in progress',
  `is_approved` tinyint(4) DEFAULT '0' COMMENT '1=approved paycomplete,not yet',
  `date_payment` date DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `collect_by` int(11) DEFAULT '1' COMMENT '?????????????',
  `payment_option` tinyint(4) DEFAULT NULL COMMENT '1=normal,2=before,3=after',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;

INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "1","1","1200.00","100.00","31.00","131.00","31","1","0","0","2015-09-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "2","1","1100.00","100.00","29.33","129.33","32","1","0","0","2015-10-12","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "3","1","1000.00","100.00","24.17","124.17","29","1","0","0","2015-11-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "4","1","900.00","100.00","22.50","122.50","30","1","0","0","2015-12-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "5","1","800.00","100.00","21.33","121.33","32","1","0","0","2016-01-11","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "6","1","700.00","100.00","17.50","117.50","30","1","0","0","2016-02-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "7","1","600.00","100.00","14.50","114.50","29","1","0","0","2016-03-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "8","1","500.00","100.00","13.33","113.33","32","1","0","0","2016-04-11","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "9","1","400.00","100.00","9.67","109.67","29","1","0","0","2016-05-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "10","1","300.00","100.00","7.75","107.75","31","1","0","0","2016-06-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "11","1","200.00","100.00","5.17","105.17","31","1","0","0","2016-07-11","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "12","1","100.00","100.00","2.50","102.50","30","1","0","0","2016-08-10","1","15","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "13","2","1500.00","125.00","38.75","163.75","31","1","0","0","2015-09-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "14","2","1375.00","125.00","36.67","161.67","32","1","0","0","2015-10-12","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "15","2","1250.00","125.00","30.21","155.21","29","1","0","0","2015-11-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "16","2","1125.00","125.00","28.13","153.13","30","1","0","0","2015-12-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "17","2","1000.00","125.00","26.67","151.67","32","1","0","0","2016-01-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "18","2","875.00","125.00","21.88","146.88","30","1","0","0","2016-02-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "19","2","750.00","125.00","18.13","143.13","29","1","0","0","2016-03-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "20","2","625.00","125.00","16.67","141.67","32","1","0","0","2016-04-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "21","2","500.00","125.00","12.08","137.08","29","1","0","0","2016-05-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "22","2","375.00","125.00","9.69","134.69","31","1","0","0","2016-06-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "23","2","250.00","125.00","6.46","131.46","31","1","0","0","2016-07-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "24","2","125.00","125.00","3.13","128.13","30","1","0","0","2016-08-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "25","3","1500.00","125.00","38.75","163.75","31","1","0","0","2015-09-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "26","3","1375.00","125.00","36.67","161.67","32","1","0","0","2015-10-12","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "27","3","1250.00","125.00","30.21","155.21","29","1","0","0","2015-11-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "28","3","1125.00","125.00","28.13","153.13","30","1","0","0","2015-12-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "29","3","1000.00","125.00","26.67","151.67","32","1","0","0","2016-01-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "30","3","875.00","125.00","21.88","146.88","30","1","0","0","2016-02-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "31","3","750.00","125.00","18.13","143.13","29","1","0","0","2016-03-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "32","3","625.00","125.00","16.67","141.67","32","1","0","0","2016-04-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "33","3","500.00","125.00","12.08","137.08","29","1","0","0","2016-05-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "34","3","375.00","125.00","9.69","134.69","31","1","0","0","2016-06-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "35","3","250.00","125.00","6.46","131.46","31","1","0","0","2016-07-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "36","3","125.00","125.00","3.13","128.13","30","1","0","0","2016-08-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "37","4","1000.00","83.33","25.83","109.16","31","1","0","0","2015-09-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "38","4","916.67","83.33","26.67","110.00","32","1","0","0","2015-10-12","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "39","4","833.34","83.33","24.17","107.50","29","1","0","0","2015-11-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "40","4","750.01","83.33","25.00","108.33","30","1","0","0","2015-12-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "41","4","666.68","83.33","26.67","110.00","32","1","0","0","2016-01-11","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "42","4","583.35","83.33","25.00","108.33","30","1","0","0","2016-02-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "43","4","500.02","83.33","24.17","107.50","29","1","0","0","2016-03-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "44","4","416.69","83.33","26.67","110.00","32","1","0","0","2016-04-11","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "45","4","333.36","83.33","24.17","107.50","29","1","0","0","2016-05-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "46","4","250.03","83.33","25.83","109.16","31","1","0","0","2016-06-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "47","4","166.70","83.33","25.83","109.16","31","1","0","0","2016-07-11","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "48","4","83.37","83.37","25.00","108.37","30","1","0","0","2016-08-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "49","5","40000.00","3400.00","1100.00","4500.00","31","1","0","0","2015-09-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "50","5","36600.00","3400.00","1100.00","4500.00","32","1","0","0","2015-10-12","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "51","5","33200.00","3400.00","1000.00","4400.00","29","1","0","0","2015-11-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "52","5","29800.00","3400.00","1100.00","4500.00","30","1","0","0","2015-12-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "53","5","26400.00","3400.00","1100.00","4500.00","32","1","0","0","2016-01-11","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "54","5","23000.00","3400.00","1100.00","4500.00","30","1","0","0","2016-02-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "55","5","19600.00","3400.00","1000.00","4400.00","29","1","0","0","2016-03-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "56","5","16200.00","3400.00","1100.00","4500.00","32","1","0","0","2016-04-11","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "57","5","12800.00","3400.00","1000.00","4400.00","29","1","0","0","2016-05-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "58","5","9400.00","3400.00","1100.00","4500.00","31","1","0","0","2016-06-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "59","5","6000.00","3400.00","1100.00","4500.00","31","1","0","0","2016-07-11","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "60","5","2600.00","2600.00","1100.00","3700.00","30","1","0","0","2016-08-10","8","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "61","6","1000.00","83.33","25.83","109.16","31","1","0","0","2015-09-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "62","6","916.67","83.33","26.67","110.00","32","1","0","0","2015-10-12","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "63","6","833.34","83.33","24.17","107.50","29","1","0","0","2015-11-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "64","6","750.01","83.33","25.00","108.33","30","1","0","0","2015-12-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "65","6","666.68","83.33","26.67","110.00","32","1","0","0","2016-01-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "66","6","583.35","83.33","25.00","108.33","30","1","0","0","2016-02-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "67","6","500.02","83.33","24.17","107.50","29","1","0","0","2016-03-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "68","6","416.69","83.33","26.67","110.00","32","1","0","0","2016-04-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "69","6","333.36","83.33","24.17","107.50","29","1","0","0","2016-05-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "70","6","250.03","83.33","25.83","109.16","31","1","0","0","2016-06-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "71","6","166.70","83.33","25.83","109.16","31","1","0","0","2016-07-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "72","6","83.37","83.37","25.00","108.37","30","1","0","0","2016-08-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "73","7","1000.00","83.33","25.83","109.16","31","1","0","0","2015-09-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "74","7","916.67","83.33","25.00","108.33","30","1","0","0","2015-10-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "75","7","833.34","83.33","25.83","109.16","31","1","0","0","2015-11-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "76","7","750.01","83.33","25.00","108.33","30","1","0","0","2015-12-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "77","7","666.68","83.33","25.83","109.16","31","1","0","0","2016-01-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "78","7","583.35","83.33","25.83","109.16","31","1","0","0","2016-02-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "79","7","500.02","83.33","24.17","107.50","29","1","0","0","2016-03-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "80","7","416.69","83.33","25.83","109.16","31","1","0","0","2016-04-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "81","7","333.36","83.33","25.00","108.33","30","1","0","0","2016-05-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "82","7","250.03","83.33","25.83","109.16","31","1","0","0","2016-06-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "83","7","166.70","83.33","25.00","108.33","30","1","0","0","2016-07-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "84","7","83.37","83.37","25.83","109.20","31","1","0","0","2016-08-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "85","8","1000.00","85.40","34.60","120.00","31","1","0","0","2015-09-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "86","8","914.60","88.35","31.65","120.00","32","1","0","0","2015-10-12","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "87","8","826.25","91.41","28.59","120.00","29","1","0","0","2015-11-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "88","8","734.84","94.57","25.43","120.00","30","1","0","0","2015-12-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "89","8","640.27","97.85","22.15","120.00","32","1","0","0","2016-01-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "90","8","542.42","101.23","18.77","120.00","30","1","0","0","2016-02-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "91","8","441.19","104.73","15.27","120.00","29","1","0","0","2016-03-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "92","8","336.46","108.36","11.64","120.00","32","1","0","0","2016-04-11","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "93","8","228.10","112.11","7.89","120.00","29","1","0","0","2016-05-10","1","1","");
INSERT INTO `ln_test_loanmember_funddetail`  VALUES ( "94","8","115.99","115.99","4.01","120.00","31","1","0","0","2016-06-10","1","1","");


--
-- Tabel structure for table `ln_theme_user`
--
DROP TABLE  IF EXISTS `ln_theme_user`;
CREATE TABLE `ln_theme_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `theme_name` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `ln_theme_user`  VALUES ( "1","1","1");


--
-- Tabel structure for table `ln_tranfser_co`
--
DROP TABLE  IF EXISTS `ln_tranfser_co`;
CREATE TABLE `ln_tranfser_co` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) DEFAULT NULL,
  `code_from` int(11) DEFAULT NULL COMMENT 'from co id',
  `code_to` int(11) DEFAULT NULL COMMENT 'to co id',
  `from` int(11) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '3 = transfer loan number',
  `date` date DEFAULT NULL,
  `note` text,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `ln_tranfser_co`  VALUES ( "1","2","","","1","2","","","1","1","2015-08-07","co to co , saron to dara","1");
INSERT INTO `ln_tranfser_co`  VALUES ( "2","1","","","","9","2","","1","2","2015-08-07","client to co","1");
INSERT INTO `ln_tranfser_co`  VALUES ( "3","8","","15","2","15","26","7","1","3","2015-08-10","transfer loan  PPL00007 to chomroen","1");


--
-- Tabel structure for table `ln_view`
--
DROP TABLE  IF EXISTS `ln_view`;
CREATE TABLE `ln_view` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(50) DEFAULT NULL,
  `name_kh` varchar(50) DEFAULT NULL,
  `key_code` varchar(20) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT '1' COMMENT '1khmer',
  `type` int(11) DEFAULT NULL COMMENT '1=term',
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

INSERT INTO `ln_view`  VALUES ( "1","Daily","??????????","1","1","1","1");
INSERT INTO `ln_view`  VALUES ( "2","Weekly","?????????????","2","1","1","1");
INSERT INTO `ln_view`  VALUES ( "3","Monthly","????????","3","1","1","1");
INSERT INTO `ln_view`  VALUES ( "4","Yearly","???????????","4","1","1","1");
INSERT INTO `ln_view`  VALUES ( "5","Before","???","1","1","2","1");
INSERT INTO `ln_view`  VALUES ( "6","Normal","??????","3","1","2","1");
INSERT INTO `ln_view`  VALUES ( "7","After","?????????","2","1","2","1");
INSERT INTO `ln_view`  VALUES ( "8","Active","??????????","1","1","3","1");
INSERT INTO `ln_view`  VALUES ( "10","Khmer","?????","1","1","4","1");
INSERT INTO `ln_view`  VALUES ( "11","English","English","2","1","4","1");
INSERT INTO `ln_view`  VALUES ( "12","Single","?????","1","1","5","1");
INSERT INTO `ln_view`  VALUES ( "13","Married","?????????","2","1","5","1");
INSERT INTO `ln_view`  VALUES ( "14","Windowed","??????","3","1","5","1");
INSERT INTO `ln_view`  VALUES ( "15","Mindowed","???????","4","1","5","1");
INSERT INTO `ln_view`  VALUES ( "16","National ID","National ID","3","1","6","1");
INSERT INTO `ln_view`  VALUES ( "17","National ID","National ID","2","1","6","1");
INSERT INTO `ln_view`  VALUES ( "18","dsfkasf","wdfs","3","1","6","1");
INSERT INTO `ln_view`  VALUES ( "19","Other","asdfsa","4","1","6","");
INSERT INTO `ln_view`  VALUES ( "23","Deactive","?????????????","0","1","3","1");
INSERT INTO `ln_view`  VALUES ( "24","festival","?????????","1","1","7","1");
INSERT INTO `ln_view`  VALUES ( "25","sickness","??","2","1","7","1");
INSERT INTO `ln_view`  VALUES ( "26","Married","????????????","3","1","7","1");
INSERT INTO `ln_view`  VALUES ( "27","Asset","Asset","1","1","8","1");
INSERT INTO `ln_view`  VALUES ( "28","Liabilities","Liabilities","2","1","8","1");
INSERT INTO `ln_view`  VALUES ( "29","Equities","Equities","3","1","8","1");
INSERT INTO `ln_view`  VALUES ( "30","Incomes","Incomes","4","1","8","1");
INSERT INTO `ln_view`  VALUES ( "32","Operation Account","Operation Account","1","2","10","1");
INSERT INTO `ln_view`  VALUES ( "33","None Operation Account","None Operation Account","2","1","10","1");
INSERT INTO `ln_view`  VALUES ( "34","???","???","1","1","12","1");
INSERT INTO `ln_view`  VALUES ( "35","?????","?????","0","1","12","1");
INSERT INTO `ln_view`  VALUES ( "36","go to province","????????","4","1","7","1");
INSERT INTO `ln_view`  VALUES ( "37","Expense","Expense","5","1","8","1");
INSERT INTO `ln_view`  VALUES ( "38","Moto Rental","????????????","1","1","9","1");
INSERT INTO `ln_view`  VALUES ( "39","Petrol","Petrol","2","1","9","1");
INSERT INTO `ln_view`  VALUES ( "40","Good cash Collection","Good cash Collection","3","1","9","1");
INSERT INTO `ln_view`  VALUES ( "41","M","?????","1","1","11","1");
INSERT INTO `ln_view`  VALUES ( "42","F","????","2","1","11","1");
INSERT INTO `ln_view`  VALUES ( "43","motor","motor","1","1","13","1");
INSERT INTO `ln_view`  VALUES ( "44","national ID","national ID","2","1","13","1");
INSERT INTO `ln_view`  VALUES ( "45","Day","??????????","1","1","14","1");
INSERT INTO `ln_view`  VALUES ( "46","Week","?????????????","2","1","14","1");
INSERT INTO `ln_view`  VALUES ( "47","Month","????????","3","1","14","1");
INSERT INTO `ln_view`  VALUES ( "48","KHR","???","1","1","15","1");
INSERT INTO `ln_view`  VALUES ( "49","USD","??????","2","1","15","1");
INSERT INTO `ln_view`  VALUES ( "50","THB","???","3","1","15","1");
INSERT INTO `ln_view`  VALUES ( "51","Diploma","Diploma","1","1","20","1");
INSERT INTO `ln_view`  VALUES ( "52","Associate","Associate","2","1","20","1");
INSERT INTO `ln_view`  VALUES ( "53","Bechelor","Bechelor","3","1","20","1");
INSERT INTO `ln_view`  VALUES ( "54","Master","Master","4","1","20","1");
INSERT INTO `ln_view`  VALUES ( "55","PhD","PhD","5","1","20","1");
INSERT INTO `ln_view`  VALUES ( "56","Personal","???????????","1","1","21","1");
INSERT INTO `ln_view`  VALUES ( "57","Representer","?????????????","2","1","21","1");
INSERT INTO `ln_view`  VALUES ( "58","Straight line","Straight line","1","1","16","1");
INSERT INTO `ln_view`  VALUES ( "59","Double-declining banlance","Double-declining banlance","2","1","16","1");
INSERT INTO `ln_view`  VALUES ( "60","Sum of the year","Sum of the year","3","1","16","1");
INSERT INTO `ln_view`  VALUES ( "61","Long Term","Long Term","1","1","17","1");
INSERT INTO `ln_view`  VALUES ( "62","Short Term","Short Term","2","1","17","1");
INSERT INTO `ln_view`  VALUES ( "63","Cash","Cash","1","1","19","1");
INSERT INTO `ln_view`  VALUES ( "64","Cradit","Cradit","2","1","19","1");
INSERT INTO `ln_view`  VALUES ( "65","Other","Other","3","1","19","1");
INSERT INTO `ln_view`  VALUES ( "66","Black List","Black List","1","1","22","1");
INSERT INTO `ln_view`  VALUES ( "67","Other","Other","5","1","5","1");
INSERT INTO `ln_view`  VALUES ( "68","National Identity","?????????????","1","1","23","1");
INSERT INTO `ln_view`  VALUES ( "69","Family Book","????????????","2","1","23","1");
INSERT INTO `ln_view`  VALUES ( "70","Certificate Of Birth","????????????","3","1","23","1");
INSERT INTO `ln_view`  VALUES ( "71","Certificate Of ...","??????????????????","4","1","23","1");
INSERT INTO `ln_view`  VALUES ( "72","Passport","????????????","5","1","23","1");
INSERT INTO `ln_view`  VALUES ( "73","Other Loan","???????????","1","1","24","1");
INSERT INTO `ln_view`  VALUES ( "74","Vehicle Loan","??????????????","2","1","24","1");
INSERT INTO `ln_view`  VALUES ( "75","Personal Loan","????????????????","3","1","24","1");
INSERT INTO `ln_view`  VALUES ( "76","Commercial Loan","??????????????????????","4","1","24","1");
INSERT INTO `ln_view`  VALUES ( "77","Student Loan","?????????????????","5","1","24","1");
INSERT INTO `ln_view`  VALUES ( "78","Housing Loan","????????????","5","1","24","1");
INSERT INTO `ln_view`  VALUES ( "79","Marreid Loan","?????????????????","6","1","24","1");
INSERT INTO `ln_view`  VALUES ( "80","Loan Testing","Loan Testing","7","1","24","1");
INSERT INTO `ln_view`  VALUES ( "81","New Schedule","???????????????","1","1","25","1");
INSERT INTO `ln_view`  VALUES ( "82","Overide Schedule","????????????????????","2","1","25","1");
INSERT INTO `ln_view`  VALUES ( "83","sok","sok","8","1","24","1");
INSERT INTO `ln_view`  VALUES ( "84","other","other1","6","1","23","1");
INSERT INTO `ln_view`  VALUES ( "85","sok","sok1","7","1","23","1");
INSERT INTO `ln_view`  VALUES ( "86","Other","??????","3","1","11","1");
INSERT INTO `ln_view`  VALUES ( "87","testing","testing","8","1","23","1");
INSERT INTO `ln_view`  VALUES ( "88","testing","testing","9","1","23","1");
INSERT INTO `ln_view`  VALUES ( "89","ff","ff","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "90","aa","aaa","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "91","bb","bb","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "92","kk","kk","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "93","vv","vv","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "94","awdf","asdf","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "95","rr","rr","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "96","gg","gg","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "97","sok","sok","10","1","23","1");
INSERT INTO `ln_view`  VALUES ( "98","Standard","Standard","1","1","26","1");
INSERT INTO `ln_view`  VALUES ( "99","Special Mention","Special Mention","2","1","26","1");
INSERT INTO `ln_view`  VALUES ( "100","Substandard","Substandard","3","1","26","1");
INSERT INTO `ln_view`  VALUES ( "101","Doubtful","Doubtful","4","1","26","1");
INSERT INTO `ln_view`  VALUES ( "102","Loan Loss","Loan Loss","5","1","26","1");
INSERT INTO `ln_view`  VALUES ( "103","Business Loan","Business Loan","9","1","24","1");


--
-- Tabel structure for table `ln_view_type`
--
DROP TABLE  IF EXISTS `ln_view_type`;
CREATE TABLE `ln_view_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `ln_view_type`  VALUES ( "1","Depreciation Term","1");
INSERT INTO `ln_view_type`  VALUES ( "2","Holiday Status","1");
INSERT INTO `ln_view_type`  VALUES ( "3","Using Status","1");
INSERT INTO `ln_view_type`  VALUES ( "4","Languege","1");
INSERT INTO `ln_view_type`  VALUES ( "5","Situation Status","1");
INSERT INTO `ln_view_type`  VALUES ( "6","Oher","1");
INSERT INTO `ln_view_type`  VALUES ( "7","Permission Type","1");
INSERT INTO `ln_view_type`  VALUES ( "8","Parents Account","1");
INSERT INTO `ln_view_type`  VALUES ( "9","Salary Type","1");
INSERT INTO `ln_view_type`  VALUES ( "10","Account Type","1");
INSERT INTO `ln_view_type`  VALUES ( "11","Gender","1");
INSERT INTO `ln_view_type`  VALUES ( "12","Loan Type","1");
INSERT INTO `ln_view_type`  VALUES ( "13","unknow","1");
INSERT INTO `ln_view_type`  VALUES ( "14","Term Install","1");
INSERT INTO `ln_view_type`  VALUES ( "15","Currency Type","1");
INSERT INTO `ln_view_type`  VALUES ( "16","Depreciation Method","1");
INSERT INTO `ln_view_type`  VALUES ( "17","Depreciation Type","1");
INSERT INTO `ln_view_type`  VALUES ( "18","Unknow","1");
INSERT INTO `ln_view_type`  VALUES ( "19","Payment Type","1");
INSERT INTO `ln_view_type`  VALUES ( "20","Degree Type","1");
INSERT INTO `ln_view_type`  VALUES ( "21","Owner Type","1");
INSERT INTO `ln_view_type`  VALUES ( "22","Black List","1");
INSERT INTO `ln_view_type`  VALUES ( "23","Document Type","1");
INSERT INTO `ln_view_type`  VALUES ( "24","Loan Type","1");


--
-- Tabel structure for table `ln_village`
--
DROP TABLE  IF EXISTS `ln_village`;
CREATE TABLE `ln_village` (
  `vill_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `commune_id` tinyint(10) DEFAULT NULL,
  `village_name` varchar(60) DEFAULT NULL,
  `village_namekh` varbinary(60) DEFAULT NULL,
  `displayby` tinyint(4) DEFAULT NULL,
  `modify_date` varchar(50) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`vill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `ln_village`  VALUES ( "1","1","Krang Trolat","ក្រាំងត្រឡាត់","1","Nov 2, 2014 12:00:31 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "2","1","Dom nak om pel","ក្រាំងត្រឡាត់","1","Jun 5, 2014 6:37:02 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "3","1","Lvea Chek","ក្រាំងត្រឡាត់","2","Jun 5, 2014 6:38:14 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "4","1","Tro sok pherm","ក្រាំងត្រឡាត់","1","Jun 5, 2014 6:37:43 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "5","1","ssss222","ក្រាំងត្រឡាត់","1","Nov 1, 2014 1:26:52 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "6","1","www","ក្រាំងត្រឡាត់","2","Nov 1, 2014 1:26:59 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "7","1","Prey kabas","ក្រាំងត្រឡាត់","2","Nov 1, 2014 11:58:14 PM","1","1");
INSERT INTO `ln_village`  VALUES ( "8","1","Prey New","ក្រាំងត្រឡាត់","2","Nov 2, 2014 12:00:01 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "9","3","Prey Port","ក្រាំងត្រឡាត់","","Nov 13, 2014 1:48:28 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "10","2","Krang trolat","ក្រាំងត្រឡាត់","2","Nov 15, 2014 11:30:56 PM","1","1");
INSERT INTO `ln_village`  VALUES ( "11","4","Tes eng","TESting","1","Apr 7, 2015 11:23:14 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "12","1","so c","sok","1","May 30, 2015 9:59:06 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "13","1","so c","sok","1","May 30, 2015 9:59:09 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "14","1","sadlkfasdf","sok","1","May 30, 2015 10:00:33 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "15","1","sov","sok","1","May 30, 2015 10:13:02 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "16","1","sss","testing","1","May 30, 2015 10:13:50 AM","1","1");
INSERT INTO `ln_village`  VALUES ( "17","1","asdfas","ddf","1","May 30, 2015 10:37:02 AM","1","1");


--
-- Tabel structure for table `ln_xchange`
--
DROP TABLE  IF EXISTS `ln_xchange`;
CREATE TABLE `ln_xchange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changedAmount` double DEFAULT NULL,
  `fromAmount` double DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `recieptNo` varchar(20) DEFAULT NULL,
  `recievedAmount` double DEFAULT NULL,
  `status_in` varchar(5) DEFAULT NULL,
  `statusDate` datetime DEFAULT NULL,
  `toAmount` double DEFAULT NULL,
  `toAmountType` varchar(1) DEFAULT NULL,
  `fromAmountType` varchar(1) DEFAULT NULL,
  `from_to` varchar(20) DEFAULT NULL,
  `recievedType` varchar(1) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `specail_customer` tinyint(1) DEFAULT '0' COMMENT '0: normal, 1 : specail customer set new rate',
  `status` tinyint(4) DEFAULT '1',
  `branch_id` int(11) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `ln_xchange`  VALUES ( "1","0","200","32.9","W15-05-22/301a843","200","in","2015-07-12 22:40:05","6580","B","$","Dollar - Bath","$","1","0","1","","");
INSERT INTO `ln_xchange`  VALUES ( "2","0","10","3990","W15-05-29/44e00c8","10","in","2015-05-29 20:48:34","39900","R","$","Dollar - Riel","$","1","0","1","","");
INSERT INTO `ln_xchange`  VALUES ( "3","100","100","3990","W15-05-29/1644556","200","in","2015-05-29 22:25:33","399000","R","$","Dollar - Riel","$","1","0","1","","");
INSERT INTO `ln_xchange`  VALUES ( "4","5","10","3990","W15-05-29/5685f43","15","in","2015-05-29 22:30:10","39900","R","$","Dollar - Riel","$","1","0","1","","");
INSERT INTO `ln_xchange`  VALUES ( "5","0","100","3990","W15-06-23/2233558","100","in","2015-06-23 18:25:00","399000","R","$","Dollar - Riel","$","1","0","1","","");
INSERT INTO `ln_xchange`  VALUES ( "6","0","1000","32.9","W15-07-10/34559f7","1000","in","2015-07-10 17:04:25","32900","B","$","Dollar - Bath","$","1","0","1","","");
INSERT INTO `ln_xchange`  VALUES ( "7","0","1000","3990","W15-08-10/003d155","1000","in","2015-08-10 17:35:38","3990000","R","$","Dollar - Riel","$","1","0","1","","");


--
-- Tabel structure for table `ln_zone`
--
DROP TABLE  IF EXISTS `ln_zone`;
CREATE TABLE `ln_zone` (
  `zone_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(40) NOT NULL,
  `zone_num` varchar(60) NOT NULL,
  `modify_date` date NOT NULL,
  `status` tinyint(4) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `ln_zone`  VALUES ( "1","zone 11211","001","2014-10-26","1","1");
INSERT INTO `ln_zone`  VALUES ( "2","zone 2","002","2014-11-22","1","1");
INSERT INTO `ln_zone`  VALUES ( "3","zone 5","003","0000-00-00","1","1");
INSERT INTO `ln_zone`  VALUES ( "4","zone 5","004","0000-00-00","1","1");
INSERT INTO `ln_zone`  VALUES ( "5","zone 22","222","2014-10-31","1","1");
INSERT INTO `ln_zone`  VALUES ( "6","zone 13","13","2014-10-31","1","1");
INSERT INTO `ln_zone`  VALUES ( "7","sdfsadf","222","2014-10-31","1","1");
INSERT INTO `ln_zone`  VALUES ( "8","dakc","222","2014-10-31","1","1");
INSERT INTO `ln_zone`  VALUES ( "9","WDFSADF","","2014-10-31","1","1");
INSERT INTO `ln_zone`  VALUES ( "10","addd","","2014-11-01","1","1");
INSERT INTO `ln_zone`  VALUES ( "11","vvvvv","vvvvv","2015-01-07","1","1");
INSERT INTO `ln_zone`  VALUES ( "12","soksss","B0012","2015-05-01","0","0");
INSERT INTO `ln_zone`  VALUES ( "13","kljl;","lkjklj","2015-06-25","1","1");
INSERT INTO `ln_zone`  VALUES ( "14","sok","sok","2015-06-25","1","1");
INSERT INTO `ln_zone`  VALUES ( "15","samnang","somnang","2015-06-25","1","1");
INSERT INTO `ln_zone`  VALUES ( "16","jea","jeas","2015-06-25","1","1");
INSERT INTO `ln_zone`  VALUES ( "17","","","2015-06-26","1","1");
INSERT INTO `ln_zone`  VALUES ( "18","","","2015-06-26","1","1");
INSERT INTO `ln_zone`  VALUES ( "19","","","2015-06-26","1","1");
INSERT INTO `ln_zone`  VALUES ( "20","Prey Kombas","Prey KOmbas","2015-06-26","1","1");
INSERT INTO `ln_zone`  VALUES ( "21","????? 1","Z001","2015-08-10","1","1");


--
-- Tabel structure for table `rms_acl_acl`
--
DROP TABLE  IF EXISTS `rms_acl_acl`;
CREATE TABLE `rms_acl_acl` (
  `acl_id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '1: display in menu; 0: disable from menu',
  `rank` int(11) DEFAULT NULL COMMENT 'rank to show in submenu',
  `label` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`acl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

INSERT INTO `rms_acl_acl`  VALUES ( "1","rsvAcl","index","index","1","","view list");
INSERT INTO `rms_acl_acl`  VALUES ( "2","rsvAcl","index","add","1","","add url");
INSERT INTO `rms_acl_acl`  VALUES ( "3","rsvAcl","index","edit","1","","edit url");
INSERT INTO `rms_acl_acl`  VALUES ( "4","rsvAcl","user","index","1","","view user");
INSERT INTO `rms_acl_acl`  VALUES ( "5","rsvAcl","user","add","1","","add user");
INSERT INTO `rms_acl_acl`  VALUES ( "6","rsvAcl","user","add","1","","add user");
INSERT INTO `rms_acl_acl`  VALUES ( "7","rsvAcl","userAccess","index","1","","view user access");
INSERT INTO `rms_acl_acl`  VALUES ( "8","rsvAcl","userAccess","add","1","","add user access");
INSERT INTO `rms_acl_acl`  VALUES ( "9","rsvAcl","userType","index","1","","view user type");
INSERT INTO `rms_acl_acl`  VALUES ( "10","rsvAcl","userType","add","1","","add user type");
INSERT INTO `rms_acl_acl`  VALUES ( "11","rsvAcl","userType","edit","1","","edit user type");
INSERT INTO `rms_acl_acl`  VALUES ( "12","other","Branch","index","1","","view branch");
INSERT INTO `rms_acl_acl`  VALUES ( "13","other","Branch","add","1","","add branch");
INSERT INTO `rms_acl_acl`  VALUES ( "14","other","Branch","edit","1","","edit branch");
INSERT INTO `rms_acl_acl`  VALUES ( "15","other","Province","index","1","","view province");
INSERT INTO `rms_acl_acl`  VALUES ( "16","other","Province","add","1","","add province");
INSERT INTO `rms_acl_acl`  VALUES ( "17","other","Province","edit","1","","edit province");
INSERT INTO `rms_acl_acl`  VALUES ( "18","other","District","index","1","","view district");
INSERT INTO `rms_acl_acl`  VALUES ( "19","other","District","add","1","","add district");
INSERT INTO `rms_acl_acl`  VALUES ( "20","other","District","edit","1","","edit district");
INSERT INTO `rms_acl_acl`  VALUES ( "21","other","Commune","index","1","","view commune");
INSERT INTO `rms_acl_acl`  VALUES ( "22","other","Commune","add","1","","add commune");
INSERT INTO `rms_acl_acl`  VALUES ( "23","other","Commune","edit commune","1","","edit commune");
INSERT INTO `rms_acl_acl`  VALUES ( "24","other","Village","index","1","","view village");
INSERT INTO `rms_acl_acl`  VALUES ( "25","other","Village","add","1","","add village");
INSERT INTO `rms_acl_acl`  VALUES ( "26","other","Village","edit","1","","edit village");
INSERT INTO `rms_acl_acl`  VALUES ( "27","other","Zone","index","1","","view zoon");
INSERT INTO `rms_acl_acl`  VALUES ( "28","other","Zone","add","1","","add zone");
INSERT INTO `rms_acl_acl`  VALUES ( "29","other","Zone","add","1","","edit zone");
INSERT INTO `rms_acl_acl`  VALUES ( "30","other","Holiday","index","1","","view holiday");
INSERT INTO `rms_acl_acl`  VALUES ( "31","other","Holiday","add","1","","add holiday");
INSERT INTO `rms_acl_acl`  VALUES ( "32","other","Holiday","edit","1","","edit holiday");
INSERT INTO `rms_acl_acl`  VALUES ( "33","other","Callecteralltype","index","1","","view collateralltype");
INSERT INTO `rms_acl_acl`  VALUES ( "34","other","Callecteralltype","add","1","","add Collateral type");
INSERT INTO `rms_acl_acl`  VALUES ( "35","other","Callecteralltype","edit","1","","edit collateral type");
INSERT INTO `rms_acl_acl`  VALUES ( "36","group","index","index","1","","view client");
INSERT INTO `rms_acl_acl`  VALUES ( "37","group","index","add","1","","add client");
INSERT INTO `rms_acl_acl`  VALUES ( "38","group","index","edit","1","","edit client");
INSERT INTO `rms_acl_acl`  VALUES ( "39","group","Callteral","index","1","","view client collater");
INSERT INTO `rms_acl_acl`  VALUES ( "40","group","Callteral","add","1","","add client collatera");
INSERT INTO `rms_acl_acl`  VALUES ( "41","group","Callteral","edit","1","","edit client collater");
INSERT INTO `rms_acl_acl`  VALUES ( "42","group","changecollteral","index","1","","view change colltera");
INSERT INTO `rms_acl_acl`  VALUES ( "43","group","changecollteral","add","1","","add change collteral");
INSERT INTO `rms_acl_acl`  VALUES ( "44","group","changecollteral","edit","1","","edit change colltera");
INSERT INTO `rms_acl_acl`  VALUES ( "45","group","Returncollteral","index","1","","view return collater");
INSERT INTO `rms_acl_acl`  VALUES ( "46","group","Returncollteral","add","1","","add Return collteral");
INSERT INTO `rms_acl_acl`  VALUES ( "47","group","Returncollteral","edit","1","","edit Return colltera");
INSERT INTO `rms_acl_acl`  VALUES ( "48","group","Clientblacklist","index","1","","view client blacklis");
INSERT INTO `rms_acl_acl`  VALUES ( "49","group","Clientblacklist","add","1","","add client blacklist");
INSERT INTO `rms_acl_acl`  VALUES ( "50","group","Clientblacklist","edit","1","","edit Client blacklis");
INSERT INTO `rms_acl_acl`  VALUES ( "51","group","index","view","1","","view client detail");
INSERT INTO `rms_acl_acl`  VALUES ( "52","loan","index","index","1","","view loan list");
INSERT INTO `rms_acl_acl`  VALUES ( "53","loan","index","add","1","","add loan IL");
INSERT INTO `rms_acl_acl`  VALUES ( "54","loan","index","edit","1","","edit loan IL");
INSERT INTO `rms_acl_acl`  VALUES ( "55","loan","index","view","1","","view detail loan IL");
INSERT INTO `rms_acl_acl`  VALUES ( "56","loan","GroupDisburse","index","1","","view droup disburse");
INSERT INTO `rms_acl_acl`  VALUES ( "57","GroupDisburse","index","add","1","","add group disburse");
INSERT INTO `rms_acl_acl`  VALUES ( "58","loan","GroupDisburse","edit","1","","edit group disburse");
INSERT INTO `rms_acl_acl`  VALUES ( "59","GroupDisburse","index","index","1","","view detail group di");
INSERT INTO `rms_acl_acl`  VALUES ( "60","loan","IlPayment","index","1","","view IL paymennt");
INSERT INTO `rms_acl_acl`  VALUES ( "61","loan","IlPayment","add","1","","add Il payment");
INSERT INTO `rms_acl_acl`  VALUES ( "62","loan","IlPayment","edit","1","","edit Il payment");
INSERT INTO `rms_acl_acl`  VALUES ( "63","laon","IlPayment","view","1","","view detail IL payme");
INSERT INTO `rms_acl_acl`  VALUES ( "64","loan","GroupPayment","index","1","","view group payment");
INSERT INTO `rms_acl_acl`  VALUES ( "65","loan","GroupPayment","add","1","","add group payment");
INSERT INTO `rms_acl_acl`  VALUES ( "66","loan","GroupPayment","edit","1","","edit group payment");
INSERT INTO `rms_acl_acl`  VALUES ( "67","loan","RepaymentSchedule","index","1","","view repayment sched");
INSERT INTO `rms_acl_acl`  VALUES ( "68","loan","RepaymentSchedule","add","1","","add repayment schedu");
INSERT INTO `rms_acl_acl`  VALUES ( "69","loan","RepaymentSchedule","edit","1","","edit repayment sched");
INSERT INTO `rms_acl_acl`  VALUES ( "70","loan","BadLoan","index","1","","view bad loan");
INSERT INTO `rms_acl_acl`  VALUES ( "71","loan","BadLoan","add","1","","add bad loan");
INSERT INTO `rms_acl_acl`  VALUES ( "72","loan","BadLoan","edit","1","","edit bad loan");
INSERT INTO `rms_acl_acl`  VALUES ( "73","loan","Transferco","index","1","","view transferco");
INSERT INTO `rms_acl_acl`  VALUES ( "74","loan","Transferco","add","1","","add transferco");
INSERT INTO `rms_acl_acl`  VALUES ( "75","loan","Transferco","edit","1","","edit transferco");
INSERT INTO `rms_acl_acl`  VALUES ( "76","loan","transferco-client","index","1","","view transferco-clie");
INSERT INTO `rms_acl_acl`  VALUES ( "77","loan","transferco-client","edit","1","","edit transferco-clie");
INSERT INTO `rms_acl_acl`  VALUES ( "78","loan","transferco-client","add","1","","add transferco-clien");
INSERT INTO `rms_acl_acl`  VALUES ( "79","loan","transferco-loand","index","1","","view transferco-loan");
INSERT INTO `rms_acl_acl`  VALUES ( "80","loan","transferco-loand","add","1","","add transferco-loand");
INSERT INTO `rms_acl_acl`  VALUES ( "81","loan","transferco-loand","edit","1","","edit transferco-loan");


--
-- Tabel structure for table `rms_acl_user_access`
--
DROP TABLE  IF EXISTS `rms_acl_user_access`;
CREATE TABLE `rms_acl_user_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acl_id` int(11) NOT NULL,
  `user_type_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  `user_id` int(11) DEFAULT NULL COMMENT 'user for access permission',
  PRIMARY KEY (`id`),
  KEY `user_type_id` (`user_type_id`),
  KEY `acl_id` (`acl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8;

INSERT INTO `rms_acl_user_access`  VALUES ( "7","5","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "8","6","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "9","7","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "10","8","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "11","9","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "12","10","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "13","11","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "14","12","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "15","13","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "16","14","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "17","15","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "18","16","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "19","17","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "23","21","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "24","22","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "25","23","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "26","24","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "27","10","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "28","11","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "29","12","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "30","13","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "31","14","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "32","15","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "33","19","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "34","20","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "35","21","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "36","22","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "37","23","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "38","24","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "39","19","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "40","20","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "41","21","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "42","25","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "43","26","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "44","27","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "45","28","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "46","29","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "47","25","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "48","26","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "49","27","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "50","28","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "51","29","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "52","25","4","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "53","26","4","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "54","27","4","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "55","28","5","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "56","25","5","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "57","29","4","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "58","30","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "59","31","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "60","32","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "61","33","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "62","33","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "63","32","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "64","31","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "65","30","2","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "66","22","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "67","23","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "68","31","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "69","24","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "70","33","3","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "71","32","4","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "72","30","4","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "73","37","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "74","38","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "75","18","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "76","18","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "77","18","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "78","18","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "79","18","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "80","18","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "81","19","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "82","19","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "111","1","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "112","4","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "114","3","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "115","2","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "116","81","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "117","80","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "118","79","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "119","78","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "120","77","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "121","76","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "122","75","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "123","74","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "124","73","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "125","72","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "126","71","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "127","70","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "128","69","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "129","68","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "130","67","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "131","66","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "132","64","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "133","63","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "134","65","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "135","62","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "136","61","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "137","60","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "138","59","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "139","58","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "140","57","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "141","55","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "142","56","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "143","54","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "144","53","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "145","52","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "146","51","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "147","50","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "148","49","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "149","48","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "150","47","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "151","46","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "152","45","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "153","44","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "154","43","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "155","42","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "156","41","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "157","40","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "158","39","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "159","36","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "160","35","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "161","34","1","1","");
INSERT INTO `rms_acl_user_access`  VALUES ( "162","20","1","1","");


--
-- Tabel structure for table `rms_acl_user_type`
--
DROP TABLE  IF EXISTS `rms_acl_user_type`;
CREATE TABLE `rms_acl_user_type` (
  `user_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` varchar(50) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`user_type_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_acl_user_type`  VALUES ( "1","Operation Manager","0","1");
INSERT INTO `rms_acl_user_type`  VALUES ( "2","Administrator","1","1");
INSERT INTO `rms_acl_user_type`  VALUES ( "3","Credit Officer","2","1");


--
-- Tabel structure for table `rms_hold`
--
DROP TABLE  IF EXISTS `rms_hold`;
CREATE TABLE `rms_hold` (
  `hold_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  PRIMARY KEY (`hold_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Tabel structure for table `rms_rate`
--
DROP TABLE  IF EXISTS `rms_rate`;
CREATE TABLE `rms_rate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rate_type` tinyint(4) DEFAULT NULL,
  `rate` float unsigned DEFAULT NULL,
  `modify_date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `rms_rate`  VALUES ( "1","1","4100","","");


--
-- Tabel structure for table `rms_setting`
--
DROP TABLE  IF EXISTS `rms_setting`;
CREATE TABLE `rms_setting` (
  `code` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyName` varchar(450) DEFAULT NULL,
  `keyValue` varchar(4500) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `access_type` int(11) NOT NULL DEFAULT '1' COMMENT '1=access all,2=foundation access,3=accounting access,4=no access',
  `status` tinyint(4) DEFAULT '1' COMMENT '1,use ,0 not use ,2 not access',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

INSERT INTO `rms_setting`  VALUES ( "0","label_animation","??????? ?????????? ??????? ??????? : ????????????? ??????????? ?????????????????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "1","sms-warnning-kh","???????????????????????????????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "2","system_name","????????????????? ???????????","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "3","client_company_name","Credit For Cambodian People","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "4","power_by","VSS Consultancy","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "6","branch-tel","Tel :(855) 10 78 55 44","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "7","branch_email","Email : info@vssservice.com","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "8","branch_add","??????? ??? ???????? ??? ??????? ????????? ?????? ???????","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "10","logo-path-name","images/loan-animation.gif","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "11","website","www.vssservice.com","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "12","branch-add-client","??????? ????????189(?) ?????????????????????????????????????","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "13","tel-client","Tel :? 092 515 555?? / 012 438 283","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "21","footer_branch","# 15,St 528 ,Boeung Kak I,Toul Kork ,Phnom Penh/# 47,St 173 ,Toul Svay Prey I,Chamkarmorn,Phnom Penh./#171-173,Pheah Ang Eng Street,Kampong Cham Town.","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "22","foot_phone","Phone:(855)23 998 233/Phone:(855)23 220 093/Phone:(855)42 942 024","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "23","f_email_website","Fax:(855)23 990n699/E-mail :info_wu@/Website western.edu.kh","1","1","1");
INSERT INTO `rms_setting`  VALUES ( "25","reciept_kh","???????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "29","exchange_ratetitle","?????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "30","exchange_reciept","?????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "31","brand_title","??????? ?????????? ??????? ???????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "34","comment","????????????????????????????????? ??????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "36","rpt-transfer-title-eng","Tel 010 78 55 44","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "38","brand_zone","?????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "39","brand_Staff","?????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "40","brand_client","Client","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "42","Report Agreement","Report Agreement","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "43","brand_adress","??????? ??? ???????? ??? ??????? ????????? ?????? ???????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "44","phone_brand","TEL :(855) 10 78 55 44","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "45","brand_holiday","?????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "46","brand_call","??????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "47","il_payment_title","????????? ???????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "48","il_payment","??????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "49","rpt_loan_release","?????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "50","rpt_loan_release_co","???????????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "51","rpt_loan_collect","????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "52","rpt_loan_outstanding","????????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "53","village","????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "54","brand_name","?????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "55","brand_client","???????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "56","brand_callecteral","???????????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "57","brand_callecteral_change","??????????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "58","brand_returncollteral","????????????????????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "59","brand_clientblacklist","???????????????????????","0","0","1");
INSERT INTO `rms_setting`  VALUES ( "60","rpt_bad_loan","?????????????????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "61","rpt_loan_late","?????????????????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "62","client_website","www.sokhamicrofinance.com","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "63","email_client","Email : info@sokhamicrofinance.com","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "64","rpt-transfer-title-kh","?????????????????????","1","0","1");
INSERT INTO `rms_setting`  VALUES ( "65","rpt-transfer-business-meaning-kh","????????????????????????? ?????????????????????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "66","rpt-transfer-business-meaning-eng","Loan,Exchange and Transfer Money","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "67","client_company_name_kh","??????? ?????????? ??????? ???????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "68","asdklfjasdf","??????????????????????????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "69","rpt-paymentschedule","??????????????????????????","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "70","claro","Theme","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "71","nihilo","Theme","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "72","soria","Theme","0","1","1");
INSERT INTO `rms_setting`  VALUES ( "73","tundra","Theme","0","1","1");


--
-- Tabel structure for table `rms_user_log`
--
DROP TABLE  IF EXISTS `rms_user_log`;
CREATE TABLE `rms_user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `log_date` datetime NOT NULL,
  `log_type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=193 DEFAULT CHARSET=utf8;

INSERT INTO `rms_user_log`  VALUES ( "1","1","2015-05-10 10:12:46","in");
INSERT INTO `rms_user_log`  VALUES ( "2","1","2015-05-10 10:19:26","in");
INSERT INTO `rms_user_log`  VALUES ( "3","1","2015-05-10 11:23:59","in");
INSERT INTO `rms_user_log`  VALUES ( "4","1","2015-05-10 11:41:17","in");
INSERT INTO `rms_user_log`  VALUES ( "5","1","2015-05-10 17:19:16","in");
INSERT INTO `rms_user_log`  VALUES ( "6","1","2015-05-10 22:50:24","in");
INSERT INTO `rms_user_log`  VALUES ( "7","1","2015-05-11 10:14:22","in");
INSERT INTO `rms_user_log`  VALUES ( "8","1","2015-05-11 10:52:58","in");
INSERT INTO `rms_user_log`  VALUES ( "9","1","2015-05-11 11:42:41","in");
INSERT INTO `rms_user_log`  VALUES ( "10","1","2015-05-11 11:42:56","in");
INSERT INTO `rms_user_log`  VALUES ( "11","1","2015-05-11 14:32:33","in");
INSERT INTO `rms_user_log`  VALUES ( "12","1","2015-05-11 15:38:11","in");
INSERT INTO `rms_user_log`  VALUES ( "13","1","2015-05-11 15:41:13","in");
INSERT INTO `rms_user_log`  VALUES ( "14","1","2015-05-11 16:27:47","in");
INSERT INTO `rms_user_log`  VALUES ( "15","1","2015-05-11 18:10:33","in");
INSERT INTO `rms_user_log`  VALUES ( "16","1","2015-05-12 08:37:09","in");
INSERT INTO `rms_user_log`  VALUES ( "17","1","2015-05-12 10:01:21","in");
INSERT INTO `rms_user_log`  VALUES ( "18","1","2015-05-12 11:54:45","in");
INSERT INTO `rms_user_log`  VALUES ( "19","1","2015-05-12 12:19:16","in");
INSERT INTO `rms_user_log`  VALUES ( "20","1","2015-05-12 15:27:11","in");
INSERT INTO `rms_user_log`  VALUES ( "21","1","2015-05-12 15:52:35","in");
INSERT INTO `rms_user_log`  VALUES ( "22","1","2015-05-13 09:24:01","in");
INSERT INTO `rms_user_log`  VALUES ( "23","1","2015-05-13 09:28:36","in");
INSERT INTO `rms_user_log`  VALUES ( "24","1","2015-05-13 10:13:15","in");
INSERT INTO `rms_user_log`  VALUES ( "25","1","2015-05-13 16:06:05","in");
INSERT INTO `rms_user_log`  VALUES ( "26","1","2015-05-13 20:21:15","in");
INSERT INTO `rms_user_log`  VALUES ( "27","1","2015-05-13 22:24:36","in");
INSERT INTO `rms_user_log`  VALUES ( "28","1","2015-05-13 22:24:46","in");
INSERT INTO `rms_user_log`  VALUES ( "29","1","2015-05-13 22:25:02","in");
INSERT INTO `rms_user_log`  VALUES ( "30","1","2015-05-13 22:59:04","in");
INSERT INTO `rms_user_log`  VALUES ( "31","1","2015-05-13 22:59:15","in");
INSERT INTO `rms_user_log`  VALUES ( "32","1","2015-05-13 22:59:32","in");
INSERT INTO `rms_user_log`  VALUES ( "33","1","2015-05-13 23:01:36","in");
INSERT INTO `rms_user_log`  VALUES ( "34","1","2015-05-13 23:02:24","in");
INSERT INTO `rms_user_log`  VALUES ( "35","1","2015-05-13 23:05:19","in");
INSERT INTO `rms_user_log`  VALUES ( "36","1","2015-05-13 23:05:43","in");
INSERT INTO `rms_user_log`  VALUES ( "37","1","2015-05-13 23:06:35","in");
INSERT INTO `rms_user_log`  VALUES ( "38","1","2015-05-13 23:27:22","in");
INSERT INTO `rms_user_log`  VALUES ( "39","1","2015-05-13 23:47:10","in");
INSERT INTO `rms_user_log`  VALUES ( "40","1","2015-05-13 23:47:33","in");
INSERT INTO `rms_user_log`  VALUES ( "41","1","2015-05-14 08:50:41","in");
INSERT INTO `rms_user_log`  VALUES ( "42","1","2015-05-14 16:23:36","in");
INSERT INTO `rms_user_log`  VALUES ( "43","1","2015-05-14 17:30:46","in");
INSERT INTO `rms_user_log`  VALUES ( "44","1","2015-05-15 15:08:09","in");
INSERT INTO `rms_user_log`  VALUES ( "45","1","2015-05-16 16:56:58","in");
INSERT INTO `rms_user_log`  VALUES ( "46","1","2015-05-17 20:34:41","in");
INSERT INTO `rms_user_log`  VALUES ( "47","1","2015-05-19 08:59:18","in");
INSERT INTO `rms_user_log`  VALUES ( "48","1","2015-05-21 10:08:54","in");
INSERT INTO `rms_user_log`  VALUES ( "49","1","2015-05-21 16:29:28","in");
INSERT INTO `rms_user_log`  VALUES ( "50","1","2015-05-22 10:04:02","in");
INSERT INTO `rms_user_log`  VALUES ( "51","1","2015-05-22 11:38:57","in");
INSERT INTO `rms_user_log`  VALUES ( "52","1","2015-05-22 11:58:41","in");
INSERT INTO `rms_user_log`  VALUES ( "53","1","2015-05-23 12:53:09","in");
INSERT INTO `rms_user_log`  VALUES ( "54","1","2015-05-25 08:01:21","in");
INSERT INTO `rms_user_log`  VALUES ( "55","1","2015-05-25 15:57:29","in");
INSERT INTO `rms_user_log`  VALUES ( "56","1","2015-05-25 20:14:08","in");
INSERT INTO `rms_user_log`  VALUES ( "57","1","2015-05-26 16:26:10","in");
INSERT INTO `rms_user_log`  VALUES ( "58","1","2015-05-27 10:06:01","in");
INSERT INTO `rms_user_log`  VALUES ( "59","1","2015-05-27 10:48:43","in");
INSERT INTO `rms_user_log`  VALUES ( "60","1","2015-05-28 18:25:21","in");
INSERT INTO `rms_user_log`  VALUES ( "61","1","2015-05-29 10:05:16","in");
INSERT INTO `rms_user_log`  VALUES ( "62","1","2015-05-29 12:44:31","in");
INSERT INTO `rms_user_log`  VALUES ( "63","1","2015-05-30 09:31:50","in");
INSERT INTO `rms_user_log`  VALUES ( "64","1","2015-05-30 09:51:01","in");
INSERT INTO `rms_user_log`  VALUES ( "65","1","2015-05-30 18:25:53","in");
INSERT INTO `rms_user_log`  VALUES ( "66","1","2015-05-29 20:27:32","in");
INSERT INTO `rms_user_log`  VALUES ( "67","1","2015-05-30 09:50:23","in");
INSERT INTO `rms_user_log`  VALUES ( "68","1","2015-05-30 22:31:59","in");
INSERT INTO `rms_user_log`  VALUES ( "69","1","2015-06-02 11:23:05","in");
INSERT INTO `rms_user_log`  VALUES ( "70","1","2015-06-02 13:20:52","in");
INSERT INTO `rms_user_log`  VALUES ( "71","1","2015-06-02 17:30:03","in");
INSERT INTO `rms_user_log`  VALUES ( "72","1","2015-06-03 10:19:45","in");
INSERT INTO `rms_user_log`  VALUES ( "73","1","2015-06-03 15:48:41","in");
INSERT INTO `rms_user_log`  VALUES ( "74","1","2015-06-03 16:10:58","in");
INSERT INTO `rms_user_log`  VALUES ( "75","1","2015-06-03 19:03:37","in");
INSERT INTO `rms_user_log`  VALUES ( "76","1","2015-06-04 13:39:46","in");
INSERT INTO `rms_user_log`  VALUES ( "77","1","2015-06-04 15:38:58","in");
INSERT INTO `rms_user_log`  VALUES ( "78","1","2015-06-04 16:59:22","in");
INSERT INTO `rms_user_log`  VALUES ( "79","1","2015-06-06 15:16:34","in");
INSERT INTO `rms_user_log`  VALUES ( "80","1","2015-06-06 15:22:38","in");
INSERT INTO `rms_user_log`  VALUES ( "81","1","2015-06-06 18:55:52","in");
INSERT INTO `rms_user_log`  VALUES ( "82","1","2015-06-09 15:27:46","in");
INSERT INTO `rms_user_log`  VALUES ( "83","1","2015-06-10 10:20:11","in");
INSERT INTO `rms_user_log`  VALUES ( "84","1","2015-06-10 10:55:20","in");
INSERT INTO `rms_user_log`  VALUES ( "85","1","2015-06-10 11:09:03","in");
INSERT INTO `rms_user_log`  VALUES ( "86","1","2015-06-10 16:26:25","in");
INSERT INTO `rms_user_log`  VALUES ( "87","1","2015-06-10 16:32:34","in");
INSERT INTO `rms_user_log`  VALUES ( "88","1","2015-06-11 14:48:07","in");
INSERT INTO `rms_user_log`  VALUES ( "89","1","2015-06-13 10:14:32","in");
INSERT INTO `rms_user_log`  VALUES ( "90","1","2015-06-13 10:47:48","in");
INSERT INTO `rms_user_log`  VALUES ( "91","1","2015-06-14 13:08:30","in");
INSERT INTO `rms_user_log`  VALUES ( "92","1","2015-06-14 19:49:47","in");
INSERT INTO `rms_user_log`  VALUES ( "93","1","2015-06-15 00:18:31","in");
INSERT INTO `rms_user_log`  VALUES ( "94","1","2015-06-15 19:22:09","in");
INSERT INTO `rms_user_log`  VALUES ( "95","1","2015-06-16 11:11:26","in");
INSERT INTO `rms_user_log`  VALUES ( "96","1","2015-06-16 14:07:31","in");
INSERT INTO `rms_user_log`  VALUES ( "97","1","2015-06-16 14:35:10","in");
INSERT INTO `rms_user_log`  VALUES ( "98","1","2015-06-16 15:24:12","in");
INSERT INTO `rms_user_log`  VALUES ( "99","1","2015-06-16 17:15:34","in");
INSERT INTO `rms_user_log`  VALUES ( "100","1","2015-06-17 10:33:47","in");
INSERT INTO `rms_user_log`  VALUES ( "101","1","2015-06-18 13:11:53","in");
INSERT INTO `rms_user_log`  VALUES ( "102","1","2015-06-19 20:03:49","in");
INSERT INTO `rms_user_log`  VALUES ( "103","1","2015-06-20 18:52:26","in");
INSERT INTO `rms_user_log`  VALUES ( "104","1","2015-06-21 00:48:40","in");
INSERT INTO `rms_user_log`  VALUES ( "105","1","2015-06-21 11:14:47","in");
INSERT INTO `rms_user_log`  VALUES ( "106","1","2015-06-21 19:32:51","in");
INSERT INTO `rms_user_log`  VALUES ( "107","1","2015-06-21 23:13:31","in");
INSERT INTO `rms_user_log`  VALUES ( "108","1","2015-06-21 23:15:40","in");
INSERT INTO `rms_user_log`  VALUES ( "109","1","2015-06-23 00:10:09","in");
INSERT INTO `rms_user_log`  VALUES ( "110","1","2015-06-23 00:10:58","in");
INSERT INTO `rms_user_log`  VALUES ( "111","1","2015-06-23 07:43:25","in");
INSERT INTO `rms_user_log`  VALUES ( "112","1","2015-06-23 10:14:44","in");
INSERT INTO `rms_user_log`  VALUES ( "113","1","2015-06-23 17:50:20","in");
INSERT INTO `rms_user_log`  VALUES ( "114","1","2015-06-23 17:52:59","in");
INSERT INTO `rms_user_log`  VALUES ( "115","1","2015-06-23 17:55:57","in");
INSERT INTO `rms_user_log`  VALUES ( "116","1","2015-06-23 18:18:59","in");
INSERT INTO `rms_user_log`  VALUES ( "117","1","2015-06-24 11:40:33","in");
INSERT INTO `rms_user_log`  VALUES ( "118","1","2015-06-24 15:12:00","in");
INSERT INTO `rms_user_log`  VALUES ( "119","1","2015-06-25 11:40:59","in");
INSERT INTO `rms_user_log`  VALUES ( "120","1","2015-06-25 16:49:40","in");
INSERT INTO `rms_user_log`  VALUES ( "121","1","2015-06-25 17:21:20","in");
INSERT INTO `rms_user_log`  VALUES ( "122","1","2015-06-25 17:32:42","in");
INSERT INTO `rms_user_log`  VALUES ( "123","1","2015-06-25 23:14:43","in");
INSERT INTO `rms_user_log`  VALUES ( "124","1","2015-06-26 10:34:08","in");
INSERT INTO `rms_user_log`  VALUES ( "125","1","2015-06-26 10:34:58","in");
INSERT INTO `rms_user_log`  VALUES ( "126","1","2015-06-26 09:05:49","in");
INSERT INTO `rms_user_log`  VALUES ( "127","1","2015-06-27 11:19:02","in");
INSERT INTO `rms_user_log`  VALUES ( "128","1","2015-06-28 18:59:31","in");
INSERT INTO `rms_user_log`  VALUES ( "129","1","2015-07-10 09:39:33","in");
INSERT INTO `rms_user_log`  VALUES ( "130","1","2015-07-11 16:30:01","in");
INSERT INTO `rms_user_log`  VALUES ( "131","1","2015-07-11 16:48:24","in");
INSERT INTO `rms_user_log`  VALUES ( "132","1","2015-07-11 16:55:14","in");
INSERT INTO `rms_user_log`  VALUES ( "133","1","2015-07-11 22:42:57","in");
INSERT INTO `rms_user_log`  VALUES ( "134","1","2015-07-12 18:41:43","in");
INSERT INTO `rms_user_log`  VALUES ( "135","1","2015-07-13 14:18:54","in");
INSERT INTO `rms_user_log`  VALUES ( "136","1","2015-07-13 20:29:13","in");
INSERT INTO `rms_user_log`  VALUES ( "137","1","2015-07-13 20:29:55","in");
INSERT INTO `rms_user_log`  VALUES ( "138","1","2015-07-13 20:30:36","in");
INSERT INTO `rms_user_log`  VALUES ( "139","1","2015-07-13 20:30:58","in");
INSERT INTO `rms_user_log`  VALUES ( "140","1","2015-07-13 20:31:11","in");
INSERT INTO `rms_user_log`  VALUES ( "141","1","2015-07-14 08:32:29","in");
INSERT INTO `rms_user_log`  VALUES ( "142","1","2015-07-17 16:34:30","in");
INSERT INTO `rms_user_log`  VALUES ( "143","1","2015-07-20 08:42:30","in");
INSERT INTO `rms_user_log`  VALUES ( "144","1","2015-07-21 09:44:34","in");
INSERT INTO `rms_user_log`  VALUES ( "145","1","2015-07-21 10:51:55","in");
INSERT INTO `rms_user_log`  VALUES ( "146","1","2015-07-21 19:55:33","in");
INSERT INTO `rms_user_log`  VALUES ( "147","1","2015-07-23 15:44:02","in");
INSERT INTO `rms_user_log`  VALUES ( "148","1","2015-07-23 16:16:46","in");
INSERT INTO `rms_user_log`  VALUES ( "149","1","2015-07-24 10:10:25","in");
INSERT INTO `rms_user_log`  VALUES ( "150","1","2015-07-24 20:46:41","in");
INSERT INTO `rms_user_log`  VALUES ( "151","1","2015-07-25 20:06:01","in");
INSERT INTO `rms_user_log`  VALUES ( "152","1","2015-07-26 00:42:42","in");
INSERT INTO `rms_user_log`  VALUES ( "153","1","2015-07-26 10:57:20","in");
INSERT INTO `rms_user_log`  VALUES ( "154","1","2015-07-27 08:36:38","in");
INSERT INTO `rms_user_log`  VALUES ( "155","1","2015-07-28 08:31:58","in");
INSERT INTO `rms_user_log`  VALUES ( "156","1","2015-07-29 21:08:16","in");
INSERT INTO `rms_user_log`  VALUES ( "157","1","2015-07-29 21:16:22","in");
INSERT INTO `rms_user_log`  VALUES ( "158","1","2015-07-30 08:17:29","in");
INSERT INTO `rms_user_log`  VALUES ( "159","1","2015-07-30 15:25:14","in");
INSERT INTO `rms_user_log`  VALUES ( "160","1","2015-07-30 15:34:49","in");
INSERT INTO `rms_user_log`  VALUES ( "161","1","2015-07-30 15:50:39","in");
INSERT INTO `rms_user_log`  VALUES ( "162","1","2015-07-30 21:38:34","in");
INSERT INTO `rms_user_log`  VALUES ( "163","1","2015-07-31 08:54:34","in");
INSERT INTO `rms_user_log`  VALUES ( "164","1","2015-07-31 09:01:02","in");
INSERT INTO `rms_user_log`  VALUES ( "165","1","2015-08-01 11:26:30","in");
INSERT INTO `rms_user_log`  VALUES ( "166","1","2015-08-02 20:19:31","in");
INSERT INTO `rms_user_log`  VALUES ( "167","1","2015-08-03 08:44:38","in");
INSERT INTO `rms_user_log`  VALUES ( "168","1","2015-08-03 09:28:34","in");
INSERT INTO `rms_user_log`  VALUES ( "169","1","2015-08-03 14:23:30","in");
INSERT INTO `rms_user_log`  VALUES ( "170","1","2015-08-04 08:20:59","in");
INSERT INTO `rms_user_log`  VALUES ( "171","1","2015-08-04 12:47:47","in");
INSERT INTO `rms_user_log`  VALUES ( "172","1","2015-08-05 08:17:15","in");
INSERT INTO `rms_user_log`  VALUES ( "173","1","2015-08-05 13:11:23","in");
INSERT INTO `rms_user_log`  VALUES ( "174","1","2015-08-07 08:12:04","in");
INSERT INTO `rms_user_log`  VALUES ( "175","1","2015-08-10 08:20:36","in");
INSERT INTO `rms_user_log`  VALUES ( "176","1","2015-08-10 08:46:34","in");
INSERT INTO `rms_user_log`  VALUES ( "177","1","2015-08-10 10:13:19","in");
INSERT INTO `rms_user_log`  VALUES ( "178","1","2015-08-10 10:14:34","in");
INSERT INTO `rms_user_log`  VALUES ( "179","1","2015-08-10 10:18:47","in");
INSERT INTO `rms_user_log`  VALUES ( "180","1","2015-08-10 16:43:51","in");
INSERT INTO `rms_user_log`  VALUES ( "181","1","2015-08-10 17:58:49","in");
INSERT INTO `rms_user_log`  VALUES ( "182","1","2015-08-11 08:18:51","in");
INSERT INTO `rms_user_log`  VALUES ( "183","1","2015-08-11 09:50:06","in");
INSERT INTO `rms_user_log`  VALUES ( "184","1","2015-08-11 16:08:53","in");
INSERT INTO `rms_user_log`  VALUES ( "185","1","2015-08-12 10:07:02","in");
INSERT INTO `rms_user_log`  VALUES ( "186","1","2015-08-12 12:54:18","in");
INSERT INTO `rms_user_log`  VALUES ( "187","1","2015-08-12 15:06:53","in");
INSERT INTO `rms_user_log`  VALUES ( "188","1","2015-08-13 07:58:07","in");
INSERT INTO `rms_user_log`  VALUES ( "189","1","2015-08-13 08:32:46","in");
INSERT INTO `rms_user_log`  VALUES ( "190","1","2015-08-13 12:16:30","in");
INSERT INTO `rms_user_log`  VALUES ( "191","1","2015-08-13 12:35:36","in");
INSERT INTO `rms_user_log`  VALUES ( "192","1","2015-08-13 13:15:42","in");


--
-- Tabel structure for table `rms_users`
--
DROP TABLE  IF EXISTS `rms_users`;
CREATE TABLE `rms_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `user_name` varchar(128) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_type` tinyint(1) DEFAULT '0' COMMENT '0: transfer; 1:admin',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `rms_users`  VALUES ( "1","?????","????","channy","5f4dcc3b5aa765d61d8327deb882cf99","1","1");
INSERT INTO `rms_users`  VALUES ( "2","??????","????","soeurn","5f4dcc3b5aa765d61d8327deb882cf99","2","1");
INSERT INTO `rms_users`  VALUES ( "3","dara","dara","dara","e10adc3949ba59abbe56e057f20f883e","1","1");


--
-- Tabel structure for table `v_badloan`
--
DROP TABLE  IF EXISTS `v_badloan`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_badloan` AS (select `b`.`id` AS `id`,`b`.`total_amount` AS `total_amount`,`b`.`intrest_amount` AS `interest_amount`,`b`.`date` AS `payof_date`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 26) and (`ln_view`.`key_code` = `b`.`tem`)) limit 1) AS `condition_term`,`l`.`member_id` AS `member_id`,`l`.`loan_number` AS `loan_number`,`l`.`group_id` AS `group_id`,`l`.`branch_id` AS `branch_id`,`l`.`client_id` AS `client_id`,`l`.`total_capital` AS `total_capital`,`l`.`interest_rate` AS `interest_rate`,`l`.`curr_type` AS `curr_type`,`l`.`total_duration` AS `total_duration`,`l`.`date_release` AS `date_release`,`l`.`date_line` AS `date_line`,`l`.`loan_type` AS `loantype`,`l`.`payment_nameen` AS `from_paymentmethod`,`l`.`client_number` AS `client_number`,`l`.`client_name` AS `client_name`,`l`.`branch_name` AS `branch_name`,`l`.`currency_type` AS `currency_type`,`l`.`Term Borrow` AS `termborrow`,`l`.`co_name` AS `co_name`,`l`.`loan_type` AS `loan_type` from (`v_default` `l` join `ln_badloan` `b`) where (`b`.`loan_number` = `l`.`loan_number`));



--
-- Tabel structure for table `v_default`
--
DROP TABLE  IF EXISTS `v_default`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_default` AS (select `m`.`member_id` AS `member_id`,`m`.`loan_number` AS `loan_number`,`m`.`group_id` AS `group_id`,sum(`m`.`admin_fee`) AS `admin_fee`,sum(`m`.`other_fee`) AS `other_fee`,`m`.`branch_id` AS `branch_id`,`m`.`client_id` AS `client_id`,sum(`m`.`total_capital`) AS `total_capital`,`m`.`interest_rate` AS `interest_rate`,`m`.`currency_type` AS `curr_type`,`lg`.`level` AS `loan_level`,`lg`.`pay_term` AS `pay_term_id`,`lg`.`total_duration` AS `total_duration`,`lg`.`date_release` AS `date_release`,`lg`.`date_line` AS `date_line`,`lg`.`co_id` AS `co_id`,`lg`.`loan_type` AS `loantype`,`lg`.`collect_typeterm` AS `collect_typeterm`,`m`.`pay_after` AS `pay_after`,(select `p`.`payment_nameen` from `ln_payment_method` `p` where (`p`.`id` = `lg`.`payment_method`)) AS `payment_nameen`,(select `c`.`client_number` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_number`,(select `c`.`phone` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_phone`,(select `c`.`name_kh` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_name`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `m`.`branch_id`) limit 1) AS `branch_name`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `m`.`currency_type`)) AS `currency_type`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`))) AS `Term Borrow`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `lg`.`co_id`) limit 1) AS `co_name`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`)) limit 1) AS `name_en`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 24) and (`ln_view`.`key_code` = `lg`.`for_loantype`)) limit 1) AS `loan_type` from (`ln_loan_group` `lg` join `ln_loan_member` `m`) where ((`lg`.`g_id` = `m`.`group_id`) and (`m`.`status` = 1) and (`lg`.`g_id` = `m`.`group_id`)) group by `m`.`group_id` order by `m`.`currency_type`);

INSERT INTO `v_default`  VALUES ( "12","PTL00001","7","400.00","0.00","8","34","40000.00","2.50","1","1","3","12","2015-08-10","2016-09-10","1","1","3","2","Flat Rate","PT000001","02020202","????","??????????","R","Month","??? ?????","Month","Personal Loan");
INSERT INTO `v_default`  VALUES ( "14","PTL00001R","12","0.00","0.00","8","34","40000.00","2.50","1","1","3","10","2015-08-11","2016-06-11","1","1","3","2","Flat Rate","PT000001","02020202","????","??????????","R","Month","??? ?????","Month","Other Loan");
INSERT INTO `v_default`  VALUES ( "4","PPL00004","3","12.00","0.00","1","33","1200.00","2.50","2","1","3","12","2015-08-10","2016-09-10","15","1","3","2","Decline","PP000026","020202020","??? ????","???????","$","Month","Long Dara","Month","Other Loan");
INSERT INTO `v_default`  VALUES ( "5","PPL00005","4","15.00","0.00","1","2","1500.00","2.50","2","1","3","12","2015-08-10","2016-09-10","1","1","3","2","Decline","PP000002","070 33 43 54","?????","???????","$","Month","??? ?????","Month","");
INSERT INTO `v_default`  VALUES ( "13","PPL00012","8","10.00","0.00","1","8","1000.00","2.50","2","1","3","12","2015-08-10","2016-09-10","2","1","3","2","Baloon","PP000007","0339399393","??? ????","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_default`  VALUES ( "1","PPL00001","1","22.00","0.00","1","30","2200.00","2.50","2","1","3","12","2015-08-04","2016-08-04","2","2","3","2","Decline","PP000023","","???","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_default`  VALUES ( "6","PPL00006","5","40.00","0.00","1","8","4000.00","2.50","2","1","3","12","2015-08-10","2016-08-10","2","2","3","2","Decline","PP000007","0339399393","??? ????","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_default`  VALUES ( "3","PPL00003","2","20.00","0.00","1","1","2000.00","2.50","2","1","3","12","2015-08-05","2016-09-05","6","1","3","2","Decline","PP000001","012 32 23 23","????","???????","$","Month","?????","Month","Other Loan");
INSERT INTO `v_default`  VALUES ( "9","PPL00009","6","40.00","0.00","1","8","4000.00","2.50","2","1","3","12","2015-08-10","2016-08-10","2","2","3","2","Decline","PP000007","0339399393","??? ????","???????","$","Month","?? ????","Month","Other Loan");


--
-- Tabel structure for table `v_getallcallateral`
--
DROP TABLE  IF EXISTS `v_getallcallateral`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getallcallateral` AS (select `d`.`id` AS `id`,`d`.`number_collecteral` AS `number_collecteral`,`d`.`is_return` AS `is_return`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `c`.`branch_id`) limit 1) AS `branch_name`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `c`.`co_id`) limit 1) AS `co_id`,`c`.`collecteral_code` AS `collecteral_code`,(select `ln_client`.`client_number` from `ln_client` where (`ln_client`.`client_id` = `c`.`client_id`) limit 1) AS `client_code`,`d`.`owner_name` AS `collecteral_type`,(select `ln_view`.`name_kh` from `ln_view` where ((`ln_view`.`type` = 21) and (`ln_view`.`key_code` = `d`.`owner_type`))) AS `collecteral_owner`,(select `ct`.`title_en` from `ln_callecteral_type` `ct` where (`ct`.`id` = `d`.`collecteral_type`)) AS `collecteral_title_en`,(select `ln_client`.`name_kh` from `ln_client` where (`ln_client`.`client_id` = `c`.`client_id`) limit 1) AS `name_kh`,(select `ln_client`.`name_en` from `ln_client` where (`ln_client`.`client_id` = `c`.`client_id`) limit 1) AS `client_name`,`c`.`client_id` AS `client_id`,`c`.`branch_id` AS `branch_id`,`c`.`join_with` AS `join_with`,`c`.`relative` AS `relative`,`c`.`date` AS `date`,`c`.`note` AS `note`,`c`.`status` AS `status` from (`ln_client_callecteral` `c` join `ln_client_callecteral_detail` `d`) where (`c`.`id` = `d`.`client_coll_id`));

INSERT INTO `v_getallcallateral`  VALUES ( "1","333333","0","???????","??? ?????","CL000001","PP000002","Samnang-?????","???????????","Real Estate Certification Mark","?????","Samnang","2","1","Navuth","???????","2015-07-30","","1");
INSERT INTO `v_getallcallateral`  VALUES ( "2","3333555","0","???????","??? ?????","CL000001","PP000002","Samnang-?????","???????????","Civil Status","?????","Samnang","2","1","Navuth","???????","2015-07-30","","1");
INSERT INTO `v_getallcallateral`  VALUES ( "3","233222","0","???????","?? ????","CL000002","PP000007","Meas Channy","?????????????","National Identity Card","??? ????","Long Dany","8","1","Sok dary","Lom chandary","2015-07-30","","1");
INSERT INTO `v_getallcallateral`  VALUES ( "4","2222","0","???????","?? ????","CL000002","PP000007","Long Dany-??? ????","???????????","Vehicle Credentials","??? ????","Long Dany","8","1","Sok dary","Lom chandary","2015-07-30","","1");
INSERT INTO `v_getallcallateral`  VALUES ( "5","322","1","???????","chea","CL000003","NL000","ganeral customer-?????????","???????????","Real Estate Certification Mark","?????????","ganeral customer","0","1","","","2015-07-30","","1");
INSERT INTO `v_getallcallateral`  VALUES ( "6","222","0","???????","?? ????","CL000004","PP000001","Dara-????","???????????","Real Estate Certification Mark","????","Dara","1","1","Nary","","2015-08-12","","1");
INSERT INTO `v_getallcallateral`  VALUES ( "7","3333","0","???????","?? ????","CL000004","PP000001","Dara-????","???????????","Vehicle Credentials","????","Dara","1","1","Nary","","2015-08-12","","1");


--
-- Tabel structure for table `v_getallclient`
--
DROP TABLE  IF EXISTS `v_getallclient`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getallclient` AS (select `ln_client`.`client_id` AS `client_id`,`ln_client`.`pro_id` AS `pro_id`,`ln_client`.`village_id` AS `village_id`,`ln_client`.`dis_id` AS `dis_id`,`ln_client`.`com_id` AS `com_id`,`ln_client`.`branch_id` AS `branch_id`,`ln_client`.`client_number` AS `client_number`,concat(`ln_client`.`name_kh`,',',`ln_client`.`name_en`) AS `client_name`,`ln_client`.`dob` AS `dob`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 5) and (`ln_view`.`key_code` = `ln_client`.`sit_status`))) AS `situation`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 23) and (`ln_view`.`key_code` = `ln_client`.`id_type`))) AS `doc_name`,`ln_client`.`nation_id` AS `id_number`,`ln_client`.`job` AS `job`,`ln_client`.`join_with` AS `join_with`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 23) and (`ln_view`.`key_code` = `ln_client`.`join_d_type`))) AS `joint_doc_type`,`ln_client`.`join_nation_id` AS `join_nation_id`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 11) and (`ln_client`.`sex` = `ln_view`.`key_code`)) limit 1) AS `sex`,`ln_client`.`phone` AS `phone`,`ln_client`.`house` AS `house`,`ln_client`.`street` AS `street`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `ln_client`.`branch_id`)) AS `branch_name`,(select `ln_village`.`village_name` from `ln_village` where (`ln_village`.`vill_id` = `ln_client`.`village_id`)) AS `village_name`,(select `c`.`commune_name` from `ln_commune` `c` where (`c`.`com_id` = `ln_client`.`com_id`) limit 1) AS `com_name`,(select `d`.`district_name` from `ln_district` `d` where (`d`.`dis_id` = `ln_client`.`dis_id`) limit 1) AS `dis_name`,(select `ln_province`.`province_en_name` from `ln_province` where (`ln_province`.`province_id` = `ln_client`.`pro_id`) limit 1) AS `pro_name`,`ln_client`.`spouse_name` AS `spouse_name`,`ln_client`.`create_date` AS `create_date`,(select concat(`rms_users`.`first_name`,' ',`rms_users`.`last_name`) from `rms_users` where (`rms_users`.`id` = `ln_client`.`user_id`)) AS `user_name`,`ln_client`.`status` AS `status` from `ln_client`);

INSERT INTO `v_getallclient`  VALUES ( "0","","","","","1","NL000","?????????,ganeral customer","","","","","","","","","","","","","???????","","","","","","2015-05-29","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "1","1","1","1","1","1","PP000001","????,Dara","","Single","National Identity","33","","Nary","","","M","012 32 23 23","","","???????","Krang Trolat","Tonle Bassak","Chamkarmon","Phnom Penh","","2015-05-29","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "2","1","1","1","1","1","PP000002","?????,Samnang","","Single","","1230300303","??????????","Navuth","National Identity","12303020202","M","070 33 43 54","16A","320","???????","Krang Trolat","Tonle Bassak","Chamkarmon","Phnom Penh","?? ??????","2015-05-30","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "5","1","1","1","1","7","KD000001","????,Sok Kha","","Married","","123444","Teacher","Nary","National Identity","422222","M","070 40 50 40","#30","120","??????","Krang Trolat","Tonle Bassak","Chamkarmon","Phnom Penh","Vuthy","2015-06-02","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "6","1","0","2","18","1","PP000004","??,A","","Single","","11234512","sale","B","National Identity","11234213","M","012234589","55","44","???????","","Chey Chomneas","Daun Penh","Phnom Penh","C","2015-06-06","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "7","1","2","1","1","1","PP000005","AA,BB","0000-00-00","Married","","322","222","","","","F","222","","333","???????","Dom nak om pel","Tonle Bassak","Chamkarmon","Phnom Penh","","2015-06-21","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "8","1","","","","1","PP000007","??? ????,Long Dany","2015-06-13","Single","","233","Teacher","Sok dary","National Identity","Sok Serrey","M","0339399393","23","23","???????","","","","Phnom Penh","Morn money","2015-06-21","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "9","0","0","0","0","1","000009","sok,sok","0000-00-00","Single","","","vireak","","","","M","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "10","0","0","0","0","1","000010","?????????,Chear Monorom","0000-00-00","Single","","","","","","","M","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "11","0","0","0","0","1","000011","sok choomnor,chear nomnor","0000-00-00","Married","","","","","","","M","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "12","0","0","0","0","1","000012","cheasok,cheasok","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "13","0","0","0","0","1","000013","???? ?????,mok channy","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "14","0","0","0","0","1","PP000012","testing,sok","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "15","0","0","0","0","1","PP000013","mean,okasdf","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "16","0","0","0","0","1","PP000014","sok chanrernq,sock chamrerng","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "17","0","0","0","0","1","PP000015","long,long","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "18","0","3","4","5","1","PP000016","chea,CHEA","0000-00-00","Single","","","","","","","M","","","","???????","Lvea Chek","Boeng Trabek","Toul Kork","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "19","0","0","0","0","1","PP000017","??????????,long dany","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "20","5","4","1","2","1","PP000018","sokqdo,fasdfs","0000-00-00","","","","","","","","M","","","","???????","Tro sok pherm","Boeng Keng Kang I","Chamkarmon","Kampong Chhnang","","2015-06-25","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "21","0","0","0","0","1","PP000019","mean chanda,mead","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-26","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "22","0","0","0","0","1","BB000001","means,sokd","0000-00-00","","","","","","","","","","","","???????","","","","","","2015-06-26","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "23","0","0","0","0","2","BB000001","sok,sok","0000-00-00","","","","","","","","","","","","???? ????????","","","","","","2015-06-26","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "24","0","7","2","6","2","BB000002","sov,sov","0000-00-00","Windowed","","","","","","","M","","","","???? ????????","Prey kabas","Tumnup Tuk","Daun Penh","","","2015-06-26","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "25","0","0","0","0","7","KD000002","???,meas","0000-00-00","Single","","","","","","","M","","","","??????","","","","","","2015-06-26","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "26","1","1","1","1","1","PP000021","Siniths,sokd","0000-00-00","Single","","","","","","","M","","","","???????","Krang Trolat","Tonle Bassak","Chamkarmon","Phnom Penh","","2015-07-27","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "27","0","0","0","0","5","CC000001","Sok ,Sov","0000-00-00","Single","","","","","","","M","","","","?????","","","","","","2015-08-01","","1");
INSERT INTO `v_getallclient`  VALUES ( "28","0","0","0","0","4","TK000001","sok ,wsov","0000-00-00","Single","","","","","","","M","","","","??????","","","","","","2015-08-01","","1");
INSERT INTO `v_getallclient`  VALUES ( "29","1","0","0","0","1","PP000022","sov,sa erk","0000-00-00","Single","","","","","","","M","","","","???????","","","","Phnom Penh","","2015-08-01","","1");
INSERT INTO `v_getallclient`  VALUES ( "30","3","0","0","0","1","PP000023","???,monor","0000-00-00","Single","","1233","Teacher","","","","M","","","","???????","","","","Banteay Meanchey","","2015-08-03","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "31","1","0","0","0","1","PP000024","Narith,Narith","0000-00-00","Single","","123","Teacher","","","","M","","","","???????","","","","Phnom Penh","","2015-08-03","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "32","1","0","0","0","1","PP000025","????,Dara","0000-00-00","Single","","1234","Teacher","","","","M","","","","???????","","","","Phnom Penh","","2015-08-05","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "33","1","2","1","1","1","PP000026","??? ????,Long Dara","2015-08-06","Single","","","Teacher","channy","National Identity","33333","M","020202020","10","21","???????","Dom nak om pel","Tonle Bassak","Chamkarmon","Phnom Penh","","2015-08-10","????? ????","1");
INSERT INTO `v_getallclient`  VALUES ( "34","1","0","2","0","8","PT000001","????,Virak","1990-04-22","Single","National Identity","123444","Teacher","","","","M","02020202","","","??????????","","","Daun Penh","Phnom Penh","","2015-08-10","????? ????","1");


--
-- Tabel structure for table `v_getchangcolleral`
--
DROP TABLE  IF EXISTS `v_getchangcolleral`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getchangcolleral` AS (select (select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `c`.`branch_id`)) AS `branch_name`,`c`.`client_id` AS `client_id`,`c`.`branch_id` AS `branch_id`,`c`.`date` AS `date`,`c`.`status` AS `statuss`,`c`.`note` AS `notes`,(select `cc`.`collecteral_code` from `ln_client_callecteral` `cc` where (`cc`.`id` = `cd`.`change_id`) limit 1) AS `collecteral_code`,(select `ct`.`title_en` from `ln_callecteral_type` `ct` where (`ct`.`id` = `cd`.`from_collateral_type`) limit 1) AS `collecteral_title_old`,(select `ct`.`title_en` from `ln_callecteral_type` `ct` where (`ct`.`id` = `cd`.`collateral_type`) limit 1) AS `collecteral_title_en`,(select `ln_view`.`name_kh` from `ln_view` where ((`ln_view`.`type` = 21) and (`ln_view`.`key_code` = `cd`.`owner_id`)) limit 1) AS `collecteral_owner`,(select concat(`ln_client`.`client_number`,' - ',`ln_client`.`name_kh`,' - ',`ln_client`.`name_en`) from `ln_client` where (`ln_client`.`client_id` = `c`.`client_id`) limit 1) AS `client_name`,`cd`.`id` AS `id`,`cd`.`change_id` AS `change_id`,`cd`.`client_coll_id` AS `client_coll_id`,`cd`.`from_id` AS `from_id`,`cd`.`from_collateral_type` AS `from_collateral_type`,`cd`.`from_owner_id` AS `from_owner_id`,`cd`.`from_owner_name` AS `from_owner_name`,`cd`.`from_number_collateral` AS `from_number_collateral`,`cd`.`from_note` AS `from_note`,`cd`.`to_id` AS `to_id`,`cd`.`collateral_type` AS `collateral_type`,`cd`.`owner_id` AS `owner_id`,`cd`.`toowner_name` AS `toowner_name`,`cd`.`number_collateral` AS `number_collateral`,`cd`.`note` AS `note`,`cd`.`status` AS `status`,`cd`.`is_changed` AS `is_changed` from (`ln_changecollteral` `c` join `ln_changecollteral_detail` `cd`) where ((`c`.`id` = `cd`.`change_id`) and (`cd`.`status` = 1)) order by `c`.`client_id`);

INSERT INTO `v_getchangcolleral`  VALUES ( "???????","1","1","2015-08-12","1","","CL000003","Real Estate Certification Mark","Real Estate Certification Mark","???????????","PP000001 - ???? - Dara","1","3","6","","1","1","Dara-????","222","","","1","1","Dara-????","2","","1","");
INSERT INTO `v_getchangcolleral`  VALUES ( "???????","1","1","2015-08-12","1","","CL000003","Vehicle Credentials","Real Estate Certification Mark","???????????","PP000001 - ???? - Dara","2","3","7","","8","1","Dara-????","3333","","","1","1","Dara-????","222","","1","");


--
-- Tabel structure for table `v_getclientblacklist`
--
DROP TABLE  IF EXISTS `v_getclientblacklist`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getclientblacklist` AS (select `b`.`id` AS `id`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `b`.`branch_id`) limit 1) AS `branch_name`,`b`.`branch_id` AS `branch_id`,`b`.`client_id` AS `client_id`,`b`.`date` AS `date`,`b`.`reason` AS `reason`,`b`.`status` AS `status`,`c`.`client_number` AS `client_number`,concat(`c`.`name_kh`,',',`c`.`name_en`) AS `client_name`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 11) and (`ln_view`.`key_code` = `c`.`sex`))) AS `sex`,`c`.`dob` AS `dob`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 5) and (`ln_view`.`key_code` = `c`.`sit_status`))) AS `situation`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 23) and (`ln_view`.`key_code` = `c`.`id_type`))) AS `doc_name`,`c`.`nation_id` AS `id_number`,(select `ln_village`.`village_name` from `ln_village` where (`ln_village`.`vill_id` = `c`.`village_id`) limit 1) AS `village_name`,(select `ln_commune`.`commune_name` from `ln_commune` where (`ln_commune`.`com_id` = `c`.`com_id`) limit 1) AS `commune_name`,(select `ln_district`.`district_name` from `ln_district` where (`ln_district`.`dis_id` = `c`.`dis_id`) limit 1) AS `district_name`,(select `ln_province`.`province_en_name` from `ln_province` where (`ln_province`.`province_id` = `c`.`pro_id`) limit 1) AS `province_name`,`c`.`street` AS `street`,`c`.`house` AS `house` from (`ln_client` `c` join `ln_client_blacklist` `b`) where (`c`.`client_id` = `b`.`client_id`));

INSERT INTO `v_getclientblacklist`  VALUES ( "1","???????","1","34","2015-08-13","this client is not fund","1","PT000001","????,Virak","M","1990-04-22","Single","National Identity","123444","","","Daun Penh","Phnom Penh","","");


--
-- Tabel structure for table `v_getcollect`
--
DROP TABLE  IF EXISTS `v_getcollect`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getcollect` AS (select (select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `lf`.`branch_id`)) AS `branch_name`,(select `m`.`client_id` from `ln_loan_member` `m` where (`m`.`member_id` = `lf`.`member_id`)) AS `client_id`,(select (select concat(`ln_client`.`name_kh`,' - ',`ln_client`.`name_en`) from `ln_client` where (`ln_client`.`client_id` = `m`.`client_id`)) from `ln_loan_member` `m` where (`m`.`member_id` = `lf`.`member_id`)) AS `client_name`,(select `m`.`loan_number` from `ln_loan_member` `m` where (`m`.`member_id` = `lf`.`member_id`)) AS `loan_number`,(select `m`.`currency_type` from `ln_loan_member` `m` where (`m`.`member_id` = `lf`.`member_id`)) AS `currency_type`,(select (select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `m`.`currency_type`)) from `ln_loan_member` `m` where (`m`.`member_id` = `lf`.`member_id`)) AS `currency_typeshow`,(select concat(`ln_co`.`co_khname`,' - ',`ln_co`.`co_firstname`,' ',`ln_co`.`co_lastname`) from `ln_co` where (`ln_co`.`co_id` = `lf`.`collect_by`)) AS `co_name`,`lf`.`id` AS `id`,`lf`.`member_id` AS `member_id`,`lf`.`total_principal` AS `total_principal`,`lf`.`principal_permonth` AS `principal_permonth`,`lf`.`total_interest` AS `total_interest`,`lf`.`total_payment` AS `total_payment`,`lf`.`amount_day` AS `amount_day`,`lf`.`status` AS `status`,`lf`.`is_completed` AS `is_completed`,`lf`.`is_approved` AS `is_approved`,`lf`.`date_payment` AS `date_payment`,`lf`.`branch_id` AS `branch_id`,`lf`.`collect_by` AS `collect_by`,`lf`.`payment_option` AS `payment_option` from `ln_loanmember_funddetail` `lf`);

INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","1","1","1200.00","100.00","31.00","131.00","31","1","0","0","2015-09-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","2","1","1100.00","100.00","28.42","128.42","31","1","0","0","2015-10-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","3","1","1000.00","100.00","25.00","125.00","30","1","0","0","2015-11-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","4","1","900.00","100.00","22.50","122.50","30","1","0","0","2015-12-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","5","1","800.00","100.00","20.67","120.67","31","1","0","0","2016-01-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","6","1","700.00","100.00","18.08","118.08","31","1","0","0","2016-02-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","7","1","600.00","100.00","14.50","114.50","29","1","0","0","2016-03-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","8","1","500.00","100.00","12.92","112.92","31","1","0","0","2016-04-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","9","1","400.00","100.00","10.00","110.00","30","1","0","0","2016-05-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","10","1","300.00","100.00","8.25","108.25","33","1","0","0","2016-06-06","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","11","1","200.00","100.00","4.67","104.67","28","1","0","0","2016-07-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","30","??? - monor","PPL00001","2","$","????? - Chear sok ","12","1","100.00","100.00","2.58","102.58","31","1","0","0","2016-08-04","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","13","2","1000.00","83.33","25.83","109.17","31","1","0","0","2015-09-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","14","2","916.67","83.33","23.68","107.01","31","1","0","0","2015-10-05","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","15","2","833.33","83.33","20.83","104.17","30","1","0","0","2015-11-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","16","2","750.00","83.33","18.75","102.08","30","1","0","0","2015-12-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","17","2","666.67","83.33","17.22","100.56","31","1","0","0","2016-01-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","18","2","583.33","83.33","15.07","98.40","31","1","0","0","2016-02-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","19","2","500.00","83.33","12.08","95.42","29","1","0","0","2016-03-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","20","2","416.67","83.33","10.76","94.10","31","1","0","0","2016-04-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","21","2","333.33","83.33","8.33","91.67","30","1","0","0","2016-05-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","22","2","250.00","83.33","6.88","90.21","33","1","0","0","2016-06-06","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","23","2","166.67","83.33","3.89","87.22","28","1","0","0","2016-07-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","31","Narith - Narith","PPL00002","2","$","?? ???? - dara chea","24","2","83.33","83.33","2.15","85.49","31","1","0","0","2016-08-04","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Narith ","25","3","2000.00","166.67","51.67","218.34","31","1","1","0","2015-09-05","1","6","1");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","26","3","1833.33","166.67","45.83","212.50","30","1","0","0","2015-10-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","27","3","1666.66","166.67","43.06","209.73","31","1","0","0","2015-11-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","28","3","1499.99","166.67","40.00","206.67","32","1","0","0","2015-12-07","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","29","3","1333.32","166.67","32.22","198.89","29","1","0","0","2016-01-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","30","3","1166.65","166.67","30.14","196.81","31","1","0","0","2016-02-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","31","3","999.98","166.67","25.83","192.50","31","1","0","0","2016-03-07","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","32","3","833.31","166.67","20.14","186.81","29","1","0","0","2016-04-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","33","3","666.64","166.67","16.67","183.34","30","1","0","0","2016-05-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","34","3","499.97","166.67","13.33","180.00","32","1","0","0","2016-06-06","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","35","3","333.30","166.67","8.05","174.72","29","1","0","0","2016-07-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","1","???? - Dara","PPL00003","2","$","????? - Chear sok ","36","3","166.63","166.63","4.30","170.93","31","1","0","0","2016-08-05","1","7","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","37","4","1200.00","100.00","31.00","131.00","31","1","0","0","2015-09-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","38","4","1100.00","100.00","29.33","129.33","32","1","0","0","2015-10-12","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","39","4","1000.00","100.00","24.17","124.17","29","1","0","0","2015-11-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","40","4","900.00","100.00","22.50","122.50","30","1","0","0","2015-12-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","41","4","800.00","100.00","21.33","121.33","32","1","0","0","2016-01-11","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","42","4","700.00","100.00","17.50","117.50","30","1","0","0","2016-02-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","43","4","600.00","100.00","14.50","114.50","29","1","0","0","2016-03-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","44","4","500.00","100.00","13.33","113.33","32","1","0","0","2016-04-11","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","45","4","400.00","100.00","9.67","109.67","29","1","0","0","2016-05-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","46","4","300.00","100.00","7.75","107.75","31","1","0","0","2016-06-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","47","4","200.00","100.00","5.17","105.17","31","1","0","0","2016-07-11","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","Long Dara - ?? ????? Long Dara","48","4","100.00","100.00","2.50","102.50","30","1","0","0","2016-08-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","49","5","1500.00","125.00","38.75","163.75","31","0","0","0","2015-09-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","50","5","1375.00","125.00","36.67","161.67","32","0","0","0","2015-10-12","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","51","5","1250.00","125.00","30.21","155.21","29","0","0","0","2015-11-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","52","5","1125.00","125.00","28.13","153.13","30","0","0","0","2015-12-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","53","5","1000.00","125.00","26.67","151.67","32","0","0","0","2016-01-11","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","54","5","875.00","125.00","21.88","146.88","30","0","0","0","2016-02-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","55","5","750.00","125.00","18.13","143.13","29","0","0","0","2016-03-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","56","5","625.00","125.00","16.67","141.67","32","0","0","0","2016-04-11","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","57","5","500.00","125.00","12.08","137.08","29","0","0","0","2016-05-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","58","5","375.00","125.00","9.69","134.69","31","0","0","0","2016-06-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","59","5","250.00","125.00","6.46","131.46","31","0","0","0","2016-07-11","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","2","????? - Samnang","PPL00005","2","$","??? ????? - sarons ","60","5","125.00","125.00","3.13","128.13","30","0","0","0","2016-08-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","61","6","2000.00","166.67","51.67","218.33","31","1","0","0","2015-09-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","62","6","1833.33","166.67","48.89","215.56","32","1","0","0","2015-10-12","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","63","6","1666.67","166.67","40.28","206.94","29","1","0","0","2015-11-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","64","6","1500.00","166.67","37.50","204.17","30","1","0","0","2015-12-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","65","6","1333.33","166.67","35.56","202.22","32","1","0","0","2016-01-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","66","6","1166.67","166.67","29.17","195.83","30","1","0","0","2016-02-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","67","6","1000.00","166.67","24.17","190.83","29","1","0","0","2016-03-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","68","6","833.33","166.67","22.22","188.89","32","1","0","0","2016-04-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","69","6","666.67","166.67","16.11","182.78","29","1","0","0","2016-05-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","70","6","500.00","166.67","12.92","179.58","31","1","0","0","2016-06-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","71","6","333.33","166.67","8.61","175.28","31","1","0","0","2016-07-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00006","2","$","?? ???? - dara chea","72","6","166.67","166.67","4.17","170.83","30","1","0","0","2016-08-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","73","7","1000.00","83.33","25.83","109.17","31","1","0","0","2015-09-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","74","7","916.67","83.33","24.44","107.78","32","1","0","0","2015-10-12","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","75","7","833.33","83.33","20.14","103.47","29","1","0","0","2015-11-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","76","7","750.00","83.33","18.75","102.08","30","1","0","0","2015-12-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","77","7","666.67","83.33","17.78","101.11","32","1","0","0","2016-01-11","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","78","7","583.33","83.33","14.58","97.92","30","1","0","0","2016-02-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","79","7","500.00","83.33","12.08","95.42","29","1","0","0","2016-03-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","80","7","416.67","83.33","11.11","94.44","32","1","0","0","2016-04-11","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","81","7","333.33","83.33","8.06","91.39","29","1","0","0","2016-05-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","82","7","250.00","83.33","6.46","89.79","31","1","0","0","2016-06-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","83","7","166.67","83.33","4.31","87.64","31","1","0","0","2016-07-11","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00007","2","$","Long Dara - ?? ????? Long Dara","84","7","83.33","83.33","2.08","85.42","30","1","0","0","2016-08-10","1","15","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","85","8","1000.00","83.33","25.83","109.17","31","1","0","0","2015-09-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","86","8","916.67","83.33","24.44","107.78","32","1","0","0","2015-10-12","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","87","8","833.33","83.33","20.14","103.47","29","1","0","0","2015-11-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","88","8","750.00","83.33","18.75","102.08","30","1","0","0","2015-12-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","89","8","666.67","83.33","17.78","101.11","32","1","0","0","2016-01-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","90","8","583.33","83.33","14.58","97.92","30","1","0","0","2016-02-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","91","8","500.00","83.33","12.08","95.42","29","1","0","0","2016-03-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","92","8","416.67","83.33","11.11","94.44","32","1","0","0","2016-04-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","93","8","333.33","83.33","8.06","91.39","29","1","0","0","2016-05-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","94","8","250.00","83.33","6.46","89.79","31","1","0","0","2016-06-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","95","8","166.67","83.33","4.31","87.64","31","1","0","0","2016-07-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00008","2","$","?? ???? - dara chea","96","8","83.33","83.33","2.08","85.42","30","1","0","0","2016-08-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","97","9","2000.00","166.67","51.67","218.33","31","1","0","0","2015-09-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","98","9","1833.33","166.67","48.89","215.56","32","1","0","0","2015-10-12","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","99","9","1666.67","166.67","40.28","206.94","29","1","0","0","2015-11-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","100","9","1500.00","166.67","37.50","204.17","30","1","0","0","2015-12-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","101","9","1333.33","166.67","35.56","202.22","32","1","0","0","2016-01-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","102","9","1166.67","166.67","29.17","195.83","30","1","0","0","2016-02-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","103","9","1000.00","166.67","24.17","190.83","29","1","0","0","2016-03-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","104","9","833.33","166.67","22.22","188.89","32","1","0","0","2016-04-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","105","9","666.67","166.67","16.11","182.78","29","1","0","0","2016-05-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","106","9","500.00","166.67","12.92","179.58","31","1","0","0","2016-06-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","107","9","333.33","166.67","8.61","175.28","31","1","0","0","2016-07-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00009","2","$","?? ???? - dara chea","108","9","166.67","166.67","4.17","170.83","30","1","0","0","2016-08-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","109","10","1000.00","83.33","25.83","109.17","31","1","0","0","2015-09-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","110","10","916.67","83.33","24.44","107.78","32","1","0","0","2015-10-12","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","111","10","833.33","83.33","20.14","103.47","29","1","0","0","2015-11-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","112","10","750.00","83.33","18.75","102.08","30","1","0","0","2015-12-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","113","10","666.67","83.33","17.78","101.11","32","1","0","0","2016-01-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","114","10","583.33","83.33","14.58","97.92","30","1","0","0","2016-02-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","115","10","500.00","83.33","12.08","95.42","29","1","0","0","2016-03-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","116","10","416.67","83.33","11.11","94.44","32","1","0","0","2016-04-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","117","10","333.33","83.33","8.06","91.39","29","1","0","0","2016-05-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","118","10","250.00","83.33","6.46","89.79","31","1","0","0","2016-06-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","119","10","166.67","83.33","4.31","87.64","31","1","0","0","2016-07-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","26","Siniths - sokd","PPL00010","2","$","?? ???? - dara chea","120","10","83.33","83.33","2.08","85.42","30","1","0","0","2016-08-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","121","11","1000.00","83.33","25.83","109.17","31","1","0","0","2015-09-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","122","11","916.67","83.33","24.44","107.78","32","1","0","0","2015-10-12","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","123","11","833.33","83.33","20.14","103.47","29","1","0","0","2015-11-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","124","11","750.00","83.33","18.75","102.08","30","1","0","0","2015-12-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","125","11","666.67","83.33","17.78","101.11","32","1","0","0","2016-01-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","126","11","583.33","83.33","14.58","97.92","30","1","0","0","2016-02-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","127","11","500.00","83.33","12.08","95.42","29","1","0","0","2016-03-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","128","11","416.67","83.33","11.11","94.44","32","1","0","0","2016-04-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","129","11","333.33","83.33","8.06","91.39","29","1","0","0","2016-05-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","130","11","250.00","83.33","6.46","89.79","31","1","0","0","2016-06-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","131","11","166.67","83.33","4.31","87.64","31","1","0","0","2016-07-11","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","29","sov - sa erk","PPL00011","2","$","?? ???? - dara chea","132","11","83.33","83.33","2.08","85.42","30","1","0","0","2016-08-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","133","4","1500.00","125.00","38.75","163.75","31","1","0","0","2015-09-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","134","4","1375.00","125.00","36.67","161.67","32","1","0","0","2015-10-12","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","135","4","1250.00","125.00","30.21","155.21","29","1","0","0","2015-11-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","136","4","1125.00","125.00","28.13","153.13","30","1","0","0","2015-12-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","137","4","1000.00","125.00","26.67","151.67","32","1","0","0","2016-01-11","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","138","4","875.00","125.00","21.88","146.88","30","1","0","0","2016-02-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","139","4","750.00","125.00","18.13","143.13","29","1","0","0","2016-03-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","140","4","625.00","125.00","16.67","141.67","32","1","0","0","2016-04-11","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","141","4","500.00","125.00","12.08","137.08","29","1","0","0","2016-05-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","142","4","375.00","125.00","9.69","134.69","31","1","0","0","2016-06-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","143","4","250.00","125.00","6.46","131.46","31","1","0","0","2016-07-11","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","33","??? ???? - Long Dara","PPL00004","2","$","??? ????? - sarons ","144","4","125.00","125.00","3.13","128.13","30","1","0","0","2016-08-10","1","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","145","12","40000.00","3400.00","1100.00","4500.00","31","1","0","0","2015-09-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","146","12","36600.00","3400.00","1100.00","4500.00","32","1","0","0","2015-10-12","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","147","12","33200.00","3400.00","1000.00","4400.00","29","1","0","0","2015-11-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","148","12","29800.00","3400.00","1100.00","4500.00","30","1","0","0","2015-12-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","149","12","26400.00","3400.00","1100.00","4500.00","32","1","0","0","2016-01-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","150","12","23000.00","3400.00","1100.00","4500.00","30","1","0","0","2016-02-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","151","12","19600.00","3400.00","1000.00","4400.00","29","1","0","0","2016-03-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","152","12","16200.00","3400.00","1100.00","4500.00","32","1","0","0","2016-04-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","153","12","12800.00","3400.00","1000.00","4400.00","29","1","0","0","2016-05-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","154","12","9400.00","3400.00","1100.00","4500.00","31","1","0","0","2016-06-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","155","12","6000.00","3400.00","1100.00","4500.00","31","1","0","0","2016-07-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001","1","R","??? ????? - sarons ","156","12","2600.00","2600.00","1100.00","3700.00","30","1","0","0","2016-08-10","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","157","13","1000.00","0.00","25.83","25.83","31","1","0","0","2015-09-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","158","13","1000.00","0.00","25.00","25.00","30","1","0","0","2015-10-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","159","13","1000.00","0.00","25.83","25.83","31","1","0","0","2015-11-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","160","13","1000.00","0.00","25.00","25.00","30","1","0","0","2015-12-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","161","13","1000.00","0.00","25.83","25.83","31","1","0","0","2016-01-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","162","13","1000.00","0.00","25.83","25.83","31","1","0","0","2016-02-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","163","13","1000.00","0.00","24.17","24.17","29","1","0","0","2016-03-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","164","13","1000.00","0.00","25.83","25.83","31","1","0","0","2016-04-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","165","13","1000.00","0.00","25.00","25.00","30","1","0","0","2016-05-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","166","13","1000.00","0.00","25.83","25.83","31","1","0","0","2016-06-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","167","13","1000.00","0.00","25.00","25.00","30","1","0","0","2016-07-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "???????","8","??? ???? - Long Dany","PPL00012","2","$","?? ???? - dara chea","168","13","1000.00","1000.00","25.83","1025.83","31","1","0","0","2016-08-10","1","2","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","169","14","40000.00","4000.00","1100.00","5100.00","31","1","0","0","2015-09-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","170","14","36000.00","4000.00","1100.00","5100.00","30","1","0","0","2015-10-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","171","14","32000.00","4000.00","1100.00","5100.00","31","1","0","0","2015-11-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","172","14","28000.00","4000.00","1100.00","5100.00","30","1","0","0","2015-12-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","173","14","24000.00","4000.00","1100.00","5100.00","31","1","0","0","2016-01-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","174","14","20000.00","4000.00","1100.00","5100.00","31","1","0","0","2016-02-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","175","14","16000.00","4000.00","1000.00","5000.00","29","1","0","0","2016-03-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","176","14","12000.00","4000.00","1100.00","5100.00","31","1","0","0","2016-04-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","177","14","8000.00","4000.00","1100.00","5100.00","30","1","0","0","2016-05-11","8","1","");
INSERT INTO `v_getcollect`  VALUES ( "??????????","34","???? - Virak","PTL00001R","1","R","??? ????? - sarons ","178","14","4000.00","4000.00","1100.00","5100.00","31","1","0","0","2016-06-11","8","1","");


--
-- Tabel structure for table `v_getcollectmoney`
--
DROP TABLE  IF EXISTS `v_getcollectmoney`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getcollectmoney` AS (select (select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `crm`.`branch_id`)) AS `branch_name`,(select `ln_client`.`client_id` from `ln_client` where (`ln_client`.`client_id` = `crm`.`group_id`)) AS `client_id`,(select concat(`ln_client`.`name_kh`,' - ',`ln_client`.`name_en`) from `ln_client` where (`ln_client`.`client_id` = `crm`.`group_id`)) AS `client_name`,(select `ln_client`.`client_number` from `ln_client` where (`ln_client`.`client_id` = `crm`.`group_id`)) AS `client_number`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `crm`.`currency_type`)) AS `currency_typeshow`,(select `c`.`co_khname` from `ln_co` `c` where (`c`.`co_id` = `crm`.`co_id`)) AS `co_name`,`crm`.`id` AS `id`,`crm`.`co_id` AS `co_id`,`crm`.`group_id` AS `group_id`,`crm`.`receiver_id` AS `receiver_id`,`crm`.`receipt_no` AS `receipt_no`,`crm`.`branch_id` AS `branch_id`,`crm`.`date_pay` AS `date_pay`,`crm`.`date_input` AS `date_input`,`crm`.`note` AS `note`,`crm`.`user_id` AS `user_id`,`crm`.`is_group` AS `is_group`,`crm`.`return_amount` AS `return_amount`,`crm`.`status` AS `status`,`crm`.`payment_option` AS `payment_option`,`crm`.`currency_type` AS `currency_type`,`crm`.`principal_amount` AS `principal_amount`,`crm`.`is_payoff` AS `is_payoff`,`d`.`loan_number` AS `loan_number`,`d`.`principal_permonth` AS `total_principal_permonth`,`d`.`total_payment` AS `total_payment`,`d`.`total_interest` AS `total_interest`,`d`.`total_recieve` AS `recieve_amount`,`d`.`penelize_amount` AS `penalize_amount`,`d`.`service_charge` AS `service_charge` from (`ln_client_receipt_money` `crm` join `ln_client_receipt_money_detail` `d`) where (`crm`.`id` = `d`.`crm_id`));

INSERT INTO `v_getcollectmoney`  VALUES ( "???????","1","???? - Dara","PP000001","$","?????","1","6","1","6","PM-00001","1","2015-08-05","2015-08-05","","1","0","0.000","1","1","2","1833.330","0","PPL00003","166.67","218.34","51.67","226.34","0.00","0.00");


--
-- Tabel structure for table `v_getexpectincome`
--
DROP TABLE  IF EXISTS `v_getexpectincome`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getexpectincome` AS (select `f`.`id` AS `id`,`f`.`principle_after` AS `principle_permonth`,`f`.`total_interest_after` AS `total_interest`,`f`.`status` AS `status`,`f`.`date_payment` AS `date_payment`,(select `b`.`branch_namekh` from `ln_branch` `b` where (`b`.`br_id` = `g`.`branch_id`)) AS `branch_name`,`g`.`date_release` AS `date_release`,`g`.`date_line` AS `date_line`,`g`.`total_duration` AS `total_duration`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `g`.`pay_term`))) AS `termborrow`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `m`.`currency_type`)) AS `currency_typeshow`,`m`.`currency_type` AS `currency_type`,`m`.`branch_id` AS `branch_id`,`m`.`loan_number` AS `loan_number`,`m`.`interest_rate` AS `interest_rate`,`m`.`total_capital` AS `total_capital`,`m`.`group_id` AS `group_id`,(select `c`.`client_number` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_number`,(select `c`.`name_kh` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_name` from ((`ln_loanmember_funddetail` `f` join `ln_loan_member` `m`) join `ln_loan_group` `g`) where ((`f`.`member_id` = `m`.`member_id`) and (`g`.`g_id` = `m`.`group_id`) and (`f`.`status` = 1)) order by `m`.`currency_type`,`m`.`branch_id`,`m`.`group_id`,`m`.`client_id`);

INSERT INTO `v_getexpectincome`  VALUES ( "149","3400.00","1100.00","1","2016-01-11","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "154","3400.00","1100.00","1","2016-06-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "148","3400.00","1100.00","1","2015-12-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "153","3400.00","1000.00","1","2016-05-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "147","3400.00","1000.00","1","2015-11-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "152","3400.00","1100.00","1","2016-04-11","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "146","3400.00","1100.00","1","2015-10-12","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "151","3400.00","1000.00","1","2016-03-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "156","2600.00","1100.00","1","2016-08-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "145","3400.00","1100.00","1","2015-09-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "150","3400.00","1100.00","1","2016-02-10","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "155","3400.00","1100.00","1","2016-07-11","??????????","2015-08-10","2016-09-10","12","Month","R","1","8","PTL00001","2.50","40000.00","7","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "176","4000.00","1100.00","1","2016-04-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "170","4000.00","1100.00","1","2015-10-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "175","4000.00","1000.00","1","2016-03-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "169","4000.00","1100.00","1","2015-09-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "174","4000.00","1100.00","1","2016-02-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "173","4000.00","1100.00","1","2016-01-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "178","4000.00","1100.00","1","2016-06-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "172","4000.00","1100.00","1","2015-12-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "177","4000.00","1100.00","1","2016-05-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "171","4000.00","1100.00","1","2015-11-11","??????????","2015-08-11","2016-06-11","10","Month","R","1","8","PTL00001R","2.50","40000.00","12","PT000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "4","100.00","22.50","1","2015-12-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "9","100.00","10.00","1","2016-05-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "3","100.00","25.00","1","2015-11-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "8","100.00","12.92","1","2016-04-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "2","100.00","28.42","1","2015-10-05","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "7","100.00","14.50","1","2016-03-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "12","100.00","2.58","1","2016-08-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "1","100.00","31.00","1","2015-09-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "6","100.00","18.08","1","2016-02-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "11","100.00","4.67","1","2016-07-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "5","100.00","20.67","1","2016-01-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "10","100.00","8.25","1","2016-06-06","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00001","2.50","1200.00","1","PP000023","???");
INSERT INTO `v_getexpectincome`  VALUES ( "20","83.33","10.76","1","2016-04-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "14","83.33","23.68","1","2015-10-05","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "19","83.33","12.08","1","2016-03-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "24","83.33","2.15","1","2016-08-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "13","83.33","25.83","1","2015-09-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "18","83.33","15.07","1","2016-02-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "23","83.33","3.89","1","2016-07-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "17","83.33","17.22","1","2016-01-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "22","83.33","6.88","1","2016-06-06","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "16","83.33","18.75","1","2015-12-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "21","83.33","8.33","1","2016-05-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "15","83.33","20.83","1","2015-11-04","???????","2015-08-04","2016-08-04","12","Month","$","2","1","PPL00002","2.50","1000.00","1","PP000024","Narith");
INSERT INTO `v_getexpectincome`  VALUES ( "36","166.63","4.30","1","2016-08-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "25","166.67","51.67","1","2015-09-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "30","166.67","30.14","1","2016-02-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "35","166.67","8.05","1","2016-07-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "29","166.67","32.22","1","2016-01-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "34","166.67","13.33","1","2016-06-06","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "28","166.67","40.00","1","2015-12-07","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "33","166.67","16.67","1","2016-05-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "27","166.67","43.06","1","2015-11-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "32","166.67","20.14","1","2016-04-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "26","166.67","45.83","1","2015-10-05","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "31","166.67","25.83","1","2016-03-07","???????","2015-08-05","2016-09-05","12","Month","$","2","1","PPL00003","2.50","2000.00","2","PP000001","????");
INSERT INTO `v_getexpectincome`  VALUES ( "144","125.00","3.13","1","2016-08-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "133","125.00","38.75","1","2015-09-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "41","100.00","21.33","1","2016-01-11","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "138","125.00","21.88","1","2016-02-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "46","100.00","7.75","1","2016-06-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "143","125.00","6.46","1","2016-07-11","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "40","100.00","22.50","1","2015-12-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "137","125.00","26.67","1","2016-01-11","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "45","100.00","9.67","1","2016-05-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "142","125.00","9.69","1","2016-06-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "39","100.00","24.17","1","2015-11-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "136","125.00","28.13","1","2015-12-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "44","100.00","13.33","1","2016-04-11","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "141","125.00","12.08","1","2016-05-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "38","100.00","29.33","1","2015-10-12","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "135","125.00","30.21","1","2015-11-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "43","100.00","14.50","1","2016-03-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "140","125.00","16.67","1","2016-04-11","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "48","100.00","2.50","1","2016-08-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "37","100.00","31.00","1","2015-09-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "134","125.00","36.67","1","2015-10-12","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "42","100.00","17.50","1","2016-02-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "139","125.00","18.13","1","2016-03-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "47","100.00","5.17","1","2016-07-11","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00004","2.50","1200.00","3","PP000026","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "64","166.67","37.50","1","2015-12-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "69","166.67","16.11","1","2016-05-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "63","166.67","40.28","1","2015-11-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "68","166.67","22.22","1","2016-04-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "62","166.67","48.89","1","2015-10-12","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "67","166.67","24.17","1","2016-03-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "72","166.67","4.17","1","2016-08-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "61","166.67","51.67","1","2015-09-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "66","166.67","29.17","1","2016-02-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "71","166.67","8.61","1","2016-07-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "65","166.67","35.56","1","2016-01-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "70","166.67","12.92","1","2016-06-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00006","2.50","2000.00","5","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "80","83.33","11.11","1","2016-04-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "74","83.33","24.44","1","2015-10-12","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "79","83.33","12.08","1","2016-03-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "84","83.33","2.08","1","2016-08-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "73","83.33","25.83","1","2015-09-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "78","83.33","14.58","1","2016-02-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "83","83.33","4.31","1","2016-07-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "77","83.33","17.78","1","2016-01-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "82","83.33","6.46","1","2016-06-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "76","83.33","18.75","1","2015-12-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "81","83.33","8.06","1","2016-05-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "75","83.33","20.14","1","2015-11-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00007","2.50","1000.00","5","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "96","83.33","2.08","1","2016-08-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "85","83.33","25.83","1","2015-09-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "90","83.33","14.58","1","2016-02-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "95","83.33","4.31","1","2016-07-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "89","83.33","17.78","1","2016-01-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "94","83.33","6.46","1","2016-06-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "88","83.33","18.75","1","2015-12-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "93","83.33","8.06","1","2016-05-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "87","83.33","20.14","1","2015-11-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "92","83.33","11.11","1","2016-04-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "86","83.33","24.44","1","2015-10-12","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "91","83.33","12.08","1","2016-03-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00008","2.50","1000.00","5","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "101","166.67","35.56","1","2016-01-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "106","166.67","12.92","1","2016-06-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "100","166.67","37.50","1","2015-12-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "105","166.67","16.11","1","2016-05-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "99","166.67","40.28","1","2015-11-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "104","166.67","22.22","1","2016-04-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "98","166.67","48.89","1","2015-10-12","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "103","166.67","24.17","1","2016-03-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "108","166.67","4.17","1","2016-08-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "97","166.67","51.67","1","2015-09-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "102","166.67","29.17","1","2016-02-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "107","166.67","8.61","1","2016-07-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00009","2.50","2000.00","6","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "112","83.33","18.75","1","2015-12-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "117","83.33","8.06","1","2016-05-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "111","83.33","20.14","1","2015-11-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "116","83.33","11.11","1","2016-04-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "110","83.33","24.44","1","2015-10-12","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "115","83.33","12.08","1","2016-03-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "120","83.33","2.08","1","2016-08-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "109","83.33","25.83","1","2015-09-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "114","83.33","14.58","1","2016-02-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "119","83.33","4.31","1","2016-07-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "113","83.33","17.78","1","2016-01-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "118","83.33","6.46","1","2016-06-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00010","2.50","1000.00","6","PP000021","Siniths");
INSERT INTO `v_getexpectincome`  VALUES ( "128","83.33","11.11","1","2016-04-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "122","83.33","24.44","1","2015-10-12","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "127","83.33","12.08","1","2016-03-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "132","83.33","2.08","1","2016-08-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "121","83.33","25.83","1","2015-09-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "126","83.33","14.58","1","2016-02-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "131","83.33","4.31","1","2016-07-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "125","83.33","17.78","1","2016-01-11","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "130","83.33","6.46","1","2016-06-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "124","83.33","18.75","1","2015-12-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "129","83.33","8.06","1","2016-05-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "123","83.33","20.14","1","2015-11-10","???????","2015-08-10","2016-08-10","12","Month","$","2","1","PPL00011","2.50","1000.00","6","PP000022","sov");
INSERT INTO `v_getexpectincome`  VALUES ( "160","0.00","25.00","1","2015-12-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "165","0.00","25.00","1","2016-05-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "159","0.00","25.83","1","2015-11-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "164","0.00","25.83","1","2016-04-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "158","0.00","25.00","1","2015-10-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "163","0.00","24.17","1","2016-03-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "168","1000.00","25.83","1","2016-08-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "157","0.00","25.83","1","2015-09-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "162","0.00","25.83","1","2016-02-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "167","0.00","25.00","1","2016-07-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "161","0.00","25.83","1","2016-01-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");
INSERT INTO `v_getexpectincome`  VALUES ( "166","0.00","25.83","1","2016-06-10","???????","2015-08-10","2016-09-10","12","Month","$","2","1","PPL00012","2.50","1000.00","8","PP000007","??? ????");


--
-- Tabel structure for table `v_getloancollects`
--
DROP TABLE  IF EXISTS `v_getloancollects`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getloancollects` AS (select `f`.`id` AS `id`,`f`.`member_id` AS `member_id`,`f`.`total_principal` AS `total_principal`,`f`.`principal_permonth` AS `principal_permonth`,`f`.`total_interest` AS `total_interest`,`f`.`total_payment` AS `total_payment`,`f`.`amount_day` AS `amount_day`,`f`.`date_payment` AS `date_payment`,`f`.`collect_by` AS `collect_by`,`f`.`branch_id` AS `branch_id`,(select `ln_loan_member`.`loan_number` from `ln_loan_member` where (`ln_loan_member`.`member_id` = `f`.`member_id`)) AS `loan_number`,(select `ln_loan_member`.`client_id` from `ln_loan_member` where (`ln_loan_member`.`member_id` = `f`.`member_id`)) AS `client_id`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `f`.`collect_by`)) AS `co_name`,(select `ln_co`.`co_id` from `ln_co` where (`ln_co`.`co_id` = `f`.`collect_by`)) AS `co_id`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `f`.`branch_id`)) AS `branch_kh`,(select concat(`ln_client`.`client_number`,' - ',`ln_client`.`name_kh`,'-',`ln_client`.`name_en`,'-','st:',`ln_client`.`street`,';No:',`ln_client`.`house`) from `ln_client` where (`ln_client`.`client_id` = (select `ln_loan_member`.`client_id` from `ln_loan_member` where (`ln_loan_member`.`member_id` = `f`.`member_id`) limit 1)) limit 1) AS `client_name`,(select `ln_client`.`phone` from `ln_client` where (`ln_client`.`client_id` = (select `ln_loan_member`.`client_id` from `ln_loan_member` where (`ln_loan_member`.`member_id` = `f`.`member_id`) limit 1)) limit 1) AS `phone_number` from `ln_loanmember_funddetail` `f` where ((`f`.`is_completed` = 0) and (`f`.`status` = 1)));

INSERT INTO `v_getloancollects`  VALUES ( "1","1","1200.00","100.00","31.00","131.00","31","2015-09-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "2","1","1100.00","100.00","28.42","128.42","31","2015-10-05","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "3","1","1000.00","100.00","25.00","125.00","30","2015-11-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "4","1","900.00","100.00","22.50","122.50","30","2015-12-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "5","1","800.00","100.00","20.67","120.67","31","2016-01-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "6","1","700.00","100.00","18.08","118.08","31","2016-02-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "7","1","600.00","100.00","14.50","114.50","29","2016-03-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "8","1","500.00","100.00","12.92","112.92","31","2016-04-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "9","1","400.00","100.00","10.00","110.00","30","2016-05-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "10","1","300.00","100.00","8.25","108.25","33","2016-06-06","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "11","1","200.00","100.00","4.67","104.67","28","2016-07-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "12","1","100.00","100.00","2.58","102.58","31","2016-08-04","7","1","PPL00001","30","?????","7","???????","PP000023 - ???-monor-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "13","2","1000.00","83.33","25.83","109.17","31","2015-09-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "14","2","916.67","83.33","23.68","107.01","31","2015-10-05","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "15","2","833.33","83.33","20.83","104.17","30","2015-11-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "16","2","750.00","83.33","18.75","102.08","30","2015-12-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "17","2","666.67","83.33","17.22","100.56","31","2016-01-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "18","2","583.33","83.33","15.07","98.40","31","2016-02-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "19","2","500.00","83.33","12.08","95.42","29","2016-03-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "20","2","416.67","83.33","10.76","94.10","31","2016-04-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "21","2","333.33","83.33","8.33","91.67","30","2016-05-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "22","2","250.00","83.33","6.88","90.21","33","2016-06-06","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "23","2","166.67","83.33","3.89","87.22","28","2016-07-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "24","2","83.33","83.33","2.15","85.49","31","2016-08-04","2","1","PPL00002","31","?? ????","2","???????","PP000024 - Narith-Narith-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "26","3","1833.33","166.67","45.83","212.50","30","2015-10-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "27","3","1666.66","166.67","43.06","209.73","31","2015-11-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "28","3","1499.99","166.67","40.00","206.67","32","2015-12-07","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "29","3","1333.32","166.67","32.22","198.89","29","2016-01-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "30","3","1166.65","166.67","30.14","196.81","31","2016-02-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "31","3","999.98","166.67","25.83","192.50","31","2016-03-07","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "32","3","833.31","166.67","20.14","186.81","29","2016-04-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "33","3","666.64","166.67","16.67","183.34","30","2016-05-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "34","3","499.97","166.67","13.33","180.00","32","2016-06-06","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "35","3","333.30","166.67","8.05","174.72","29","2016-07-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "36","3","166.63","166.63","4.30","170.93","31","2016-08-05","7","1","PPL00003","1","?????","7","???????","PP000001 - ????-Dara-st:;No:","012 32 23 23");
INSERT INTO `v_getloancollects`  VALUES ( "37","4","1200.00","100.00","31.00","131.00","31","2015-09-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "38","4","1100.00","100.00","29.33","129.33","32","2015-10-12","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "39","4","1000.00","100.00","24.17","124.17","29","2015-11-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "40","4","900.00","100.00","22.50","122.50","30","2015-12-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "41","4","800.00","100.00","21.33","121.33","32","2016-01-11","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "42","4","700.00","100.00","17.50","117.50","30","2016-02-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "43","4","600.00","100.00","14.50","114.50","29","2016-03-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "44","4","500.00","100.00","13.33","113.33","32","2016-04-11","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "45","4","400.00","100.00","9.67","109.67","29","2016-05-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "46","4","300.00","100.00","7.75","107.75","31","2016-06-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "47","4","200.00","100.00","5.17","105.17","31","2016-07-11","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "48","4","100.00","100.00","2.50","102.50","30","2016-08-10","15","1","PPL00004","33","Long Dara","15","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "61","6","2000.00","166.67","51.67","218.33","31","2015-09-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "62","6","1833.33","166.67","48.89","215.56","32","2015-10-12","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "63","6","1666.67","166.67","40.28","206.94","29","2015-11-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "64","6","1500.00","166.67","37.50","204.17","30","2015-12-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "65","6","1333.33","166.67","35.56","202.22","32","2016-01-11","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "66","6","1166.67","166.67","29.17","195.83","30","2016-02-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "67","6","1000.00","166.67","24.17","190.83","29","2016-03-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "68","6","833.33","166.67","22.22","188.89","32","2016-04-11","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "69","6","666.67","166.67","16.11","182.78","29","2016-05-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "70","6","500.00","166.67","12.92","179.58","31","2016-06-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "71","6","333.33","166.67","8.61","175.28","31","2016-07-11","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "72","6","166.67","166.67","4.17","170.83","30","2016-08-10","2","1","PPL00006","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "73","7","1000.00","83.33","25.83","109.17","31","2015-09-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "74","7","916.67","83.33","24.44","107.78","32","2015-10-12","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "75","7","833.33","83.33","20.14","103.47","29","2015-11-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "76","7","750.00","83.33","18.75","102.08","30","2015-12-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "77","7","666.67","83.33","17.78","101.11","32","2016-01-11","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "78","7","583.33","83.33","14.58","97.92","30","2016-02-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "79","7","500.00","83.33","12.08","95.42","29","2016-03-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "80","7","416.67","83.33","11.11","94.44","32","2016-04-11","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "81","7","333.33","83.33","8.06","91.39","29","2016-05-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "82","7","250.00","83.33","6.46","89.79","31","2016-06-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "83","7","166.67","83.33","4.31","87.64","31","2016-07-11","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "84","7","83.33","83.33","2.08","85.42","30","2016-08-10","15","1","PPL00007","26","Long Dara","15","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "85","8","1000.00","83.33","25.83","109.17","31","2015-09-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "86","8","916.67","83.33","24.44","107.78","32","2015-10-12","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "87","8","833.33","83.33","20.14","103.47","29","2015-11-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "88","8","750.00","83.33","18.75","102.08","30","2015-12-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "89","8","666.67","83.33","17.78","101.11","32","2016-01-11","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "90","8","583.33","83.33","14.58","97.92","30","2016-02-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "91","8","500.00","83.33","12.08","95.42","29","2016-03-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "92","8","416.67","83.33","11.11","94.44","32","2016-04-11","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "93","8","333.33","83.33","8.06","91.39","29","2016-05-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "94","8","250.00","83.33","6.46","89.79","31","2016-06-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "95","8","166.67","83.33","4.31","87.64","31","2016-07-11","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "96","8","83.33","83.33","2.08","85.42","30","2016-08-10","2","1","PPL00008","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "97","9","2000.00","166.67","51.67","218.33","31","2015-09-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "98","9","1833.33","166.67","48.89","215.56","32","2015-10-12","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "99","9","1666.67","166.67","40.28","206.94","29","2015-11-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "100","9","1500.00","166.67","37.50","204.17","30","2015-12-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "101","9","1333.33","166.67","35.56","202.22","32","2016-01-11","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "102","9","1166.67","166.67","29.17","195.83","30","2016-02-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "103","9","1000.00","166.67","24.17","190.83","29","2016-03-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "104","9","833.33","166.67","22.22","188.89","32","2016-04-11","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "105","9","666.67","166.67","16.11","182.78","29","2016-05-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "106","9","500.00","166.67","12.92","179.58","31","2016-06-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "107","9","333.33","166.67","8.61","175.28","31","2016-07-11","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "108","9","166.67","166.67","4.17","170.83","30","2016-08-10","2","1","PPL00009","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "109","10","1000.00","83.33","25.83","109.17","31","2015-09-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "110","10","916.67","83.33","24.44","107.78","32","2015-10-12","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "111","10","833.33","83.33","20.14","103.47","29","2015-11-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "112","10","750.00","83.33","18.75","102.08","30","2015-12-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "113","10","666.67","83.33","17.78","101.11","32","2016-01-11","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "114","10","583.33","83.33","14.58","97.92","30","2016-02-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "115","10","500.00","83.33","12.08","95.42","29","2016-03-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "116","10","416.67","83.33","11.11","94.44","32","2016-04-11","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "117","10","333.33","83.33","8.06","91.39","29","2016-05-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "118","10","250.00","83.33","6.46","89.79","31","2016-06-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "119","10","166.67","83.33","4.31","87.64","31","2016-07-11","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "120","10","83.33","83.33","2.08","85.42","30","2016-08-10","2","1","PPL00010","26","?? ????","2","???????","PP000021 - Siniths-sokd-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "121","11","1000.00","83.33","25.83","109.17","31","2015-09-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "122","11","916.67","83.33","24.44","107.78","32","2015-10-12","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "123","11","833.33","83.33","20.14","103.47","29","2015-11-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "124","11","750.00","83.33","18.75","102.08","30","2015-12-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "125","11","666.67","83.33","17.78","101.11","32","2016-01-11","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "126","11","583.33","83.33","14.58","97.92","30","2016-02-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "127","11","500.00","83.33","12.08","95.42","29","2016-03-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "128","11","416.67","83.33","11.11","94.44","32","2016-04-11","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "129","11","333.33","83.33","8.06","91.39","29","2016-05-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "130","11","250.00","83.33","6.46","89.79","31","2016-06-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "131","11","166.67","83.33","4.31","87.64","31","2016-07-11","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "132","11","83.33","83.33","2.08","85.42","30","2016-08-10","2","1","PPL00011","29","?? ????","2","???????","PP000022 - sov-sa erk-st:;No:","");
INSERT INTO `v_getloancollects`  VALUES ( "133","4","1500.00","125.00","38.75","163.75","31","2015-09-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "134","4","1375.00","125.00","36.67","161.67","32","2015-10-12","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "135","4","1250.00","125.00","30.21","155.21","29","2015-11-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "136","4","1125.00","125.00","28.13","153.13","30","2015-12-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "137","4","1000.00","125.00","26.67","151.67","32","2016-01-11","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "138","4","875.00","125.00","21.88","146.88","30","2016-02-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "139","4","750.00","125.00","18.13","143.13","29","2016-03-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "140","4","625.00","125.00","16.67","141.67","32","2016-04-11","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "141","4","500.00","125.00","12.08","137.08","29","2016-05-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "142","4","375.00","125.00","9.69","134.69","31","2016-06-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "143","4","250.00","125.00","6.46","131.46","31","2016-07-11","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "144","4","125.00","125.00","3.13","128.13","30","2016-08-10","1","1","PPL00004","33","??? ?????","1","???????","PP000026 - ??? ????-Long Dara-st:21;No:10","020202020");
INSERT INTO `v_getloancollects`  VALUES ( "145","12","40000.00","3400.00","1100.00","4500.00","31","2015-09-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "146","12","36600.00","3400.00","1100.00","4500.00","32","2015-10-12","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "147","12","33200.00","3400.00","1000.00","4400.00","29","2015-11-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "148","12","29800.00","3400.00","1100.00","4500.00","30","2015-12-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "149","12","26400.00","3400.00","1100.00","4500.00","32","2016-01-11","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "150","12","23000.00","3400.00","1100.00","4500.00","30","2016-02-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "151","12","19600.00","3400.00","1000.00","4400.00","29","2016-03-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "152","12","16200.00","3400.00","1100.00","4500.00","32","2016-04-11","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "153","12","12800.00","3400.00","1000.00","4400.00","29","2016-05-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "154","12","9400.00","3400.00","1100.00","4500.00","31","2016-06-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "155","12","6000.00","3400.00","1100.00","4500.00","31","2016-07-11","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "156","12","2600.00","2600.00","1100.00","3700.00","30","2016-08-10","1","8","PTL00001","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "157","13","1000.00","0.00","25.83","25.83","31","2015-09-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "158","13","1000.00","0.00","25.00","25.00","30","2015-10-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "159","13","1000.00","0.00","25.83","25.83","31","2015-11-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "160","13","1000.00","0.00","25.00","25.00","30","2015-12-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "161","13","1000.00","0.00","25.83","25.83","31","2016-01-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "162","13","1000.00","0.00","25.83","25.83","31","2016-02-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "163","13","1000.00","0.00","24.17","24.17","29","2016-03-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "164","13","1000.00","0.00","25.83","25.83","31","2016-04-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "165","13","1000.00","0.00","25.00","25.00","30","2016-05-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "166","13","1000.00","0.00","25.83","25.83","31","2016-06-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "167","13","1000.00","0.00","25.00","25.00","30","2016-07-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "168","13","1000.00","1000.00","25.83","1025.83","31","2016-08-10","2","1","PPL00012","8","?? ????","2","???????","PP000007 - ??? ????-Long Dany-st:23;No:23","0339399393");
INSERT INTO `v_getloancollects`  VALUES ( "169","14","40000.00","4000.00","1100.00","5100.00","31","2015-09-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "170","14","36000.00","4000.00","1100.00","5100.00","30","2015-10-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "171","14","32000.00","4000.00","1100.00","5100.00","31","2015-11-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "172","14","28000.00","4000.00","1100.00","5100.00","30","2015-12-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "173","14","24000.00","4000.00","1100.00","5100.00","31","2016-01-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "174","14","20000.00","4000.00","1100.00","5100.00","31","2016-02-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "175","14","16000.00","4000.00","1000.00","5000.00","29","2016-03-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "176","14","12000.00","4000.00","1100.00","5100.00","31","2016-04-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "177","14","8000.00","4000.00","1100.00","5100.00","30","2016-05-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");
INSERT INTO `v_getloancollects`  VALUES ( "178","14","4000.00","4000.00","1100.00","5100.00","31","2016-06-11","1","8","PTL00001R","34","??? ?????","1","??????????","PT000001 - ????-Virak-st:;No:","02020202");


--
-- Tabel structure for table `v_getloanlates`
--
DROP TABLE  IF EXISTS `v_getloanlates`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getloanlates` AS (select `mf`.`id` AS `id`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `mf`.`member_id`)) AS `name_kh`,`mf`.`total_principal` AS `total_principal`,`mf`.`principal_permonth` AS `principal_permonth`,`mf`.`total_interest` AS `total_interest`,`mf`.`total_payment` AS `total_payment`,(select `b`.`branch_namekh` from `ln_branch` `b` where (`b`.`br_id` = `mf`.`branch_id`)) AS `branch_name`,`m`.`currency_type` AS `currency_type`,`m`.`branch_id` AS `branch_id`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `m`.`currency_type`)) AS `currency_typeshow`,`mf`.`date_payment` AS `date_payment`,`mf`.`amount_day` AS `amount_day`,`mf`.`is_approved` AS `is_approved` from (`ln_loanmember_funddetail` `mf` join `ln_loan_member` `m`) where ((`mf`.`member_id` = `m`.`member_id`) and (`mf`.`is_completed` = 0) and (`mf`.`status` = 1)));

INSERT INTO `v_getloanlates`  VALUES ( "1","??? ?????","1200.00","100.00","31.00","131.00","???????","2","1","$","2015-09-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "2","??? ?????","1100.00","100.00","28.42","128.42","???????","2","1","$","2015-10-05","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "3","??? ?????","1000.00","100.00","25.00","125.00","???????","2","1","$","2015-11-04","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "4","??? ?????","900.00","100.00","22.50","122.50","???????","2","1","$","2015-12-04","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "5","??? ?????","800.00","100.00","20.67","120.67","???????","2","1","$","2016-01-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "6","??? ?????","700.00","100.00","18.08","118.08","???????","2","1","$","2016-02-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "7","??? ?????","600.00","100.00","14.50","114.50","???????","2","1","$","2016-03-04","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "8","??? ?????","500.00","100.00","12.92","112.92","???????","2","1","$","2016-04-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "9","??? ?????","400.00","100.00","10.00","110.00","???????","2","1","$","2016-05-04","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "10","??? ?????","300.00","100.00","8.25","108.25","???????","2","1","$","2016-06-06","33","0");
INSERT INTO `v_getloanlates`  VALUES ( "11","??? ?????","200.00","100.00","4.67","104.67","???????","2","1","$","2016-07-04","28","0");
INSERT INTO `v_getloanlates`  VALUES ( "12","??? ?????","100.00","100.00","2.58","102.58","???????","2","1","$","2016-08-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "13","?? ????","1000.00","83.33","25.83","109.17","???????","2","1","$","2015-09-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "14","?? ????","916.67","83.33","23.68","107.01","???????","2","1","$","2015-10-05","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "15","?? ????","833.33","83.33","20.83","104.17","???????","2","1","$","2015-11-04","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "16","?? ????","750.00","83.33","18.75","102.08","???????","2","1","$","2015-12-04","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "17","?? ????","666.67","83.33","17.22","100.56","???????","2","1","$","2016-01-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "18","?? ????","583.33","83.33","15.07","98.40","???????","2","1","$","2016-02-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "19","?? ????","500.00","83.33","12.08","95.42","???????","2","1","$","2016-03-04","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "20","?? ????","416.67","83.33","10.76","94.10","???????","2","1","$","2016-04-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "21","?? ????","333.33","83.33","8.33","91.67","???????","2","1","$","2016-05-04","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "22","?? ????","250.00","83.33","6.88","90.21","???????","2","1","$","2016-06-06","33","0");
INSERT INTO `v_getloanlates`  VALUES ( "23","?? ????","166.67","83.33","3.89","87.22","???????","2","1","$","2016-07-04","28","0");
INSERT INTO `v_getloanlates`  VALUES ( "24","?? ????","83.33","83.33","2.15","85.49","???????","2","1","$","2016-08-04","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "26","","1833.33","166.67","45.83","212.50","???????","2","1","$","2015-10-05","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "27","","1666.66","166.67","43.06","209.73","???????","2","1","$","2015-11-05","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "28","","1499.99","166.67","40.00","206.67","???????","2","1","$","2015-12-07","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "29","","1333.32","166.67","32.22","198.89","???????","2","1","$","2016-01-05","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "30","","1166.65","166.67","30.14","196.81","???????","2","1","$","2016-02-05","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "31","","999.98","166.67","25.83","192.50","???????","2","1","$","2016-03-07","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "32","","833.31","166.67","20.14","186.81","???????","2","1","$","2016-04-05","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "33","","666.64","166.67","16.67","183.34","???????","2","1","$","2016-05-05","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "34","","499.97","166.67","13.33","180.00","???????","2","1","$","2016-06-06","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "35","","333.30","166.67","8.05","174.72","???????","2","1","$","2016-07-05","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "36","","166.63","166.63","4.30","170.93","???????","2","1","$","2016-08-05","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "37","","1200.00","100.00","31.00","131.00","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "38","","1100.00","100.00","29.33","129.33","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "39","","1000.00","100.00","24.17","124.17","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "40","","900.00","100.00","22.50","122.50","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "41","","800.00","100.00","21.33","121.33","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "42","","700.00","100.00","17.50","117.50","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "43","","600.00","100.00","14.50","114.50","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "44","","500.00","100.00","13.33","113.33","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "45","","400.00","100.00","9.67","109.67","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "46","","300.00","100.00","7.75","107.75","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "47","","200.00","100.00","5.17","105.17","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "48","","100.00","100.00","2.50","102.50","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "61","?????","2000.00","166.67","51.67","218.33","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "62","?????","1833.33","166.67","48.89","215.56","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "63","?????","1666.67","166.67","40.28","206.94","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "64","?????","1500.00","166.67","37.50","204.17","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "65","?????","1333.33","166.67","35.56","202.22","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "66","?????","1166.67","166.67","29.17","195.83","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "67","?????","1000.00","166.67","24.17","190.83","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "68","?????","833.33","166.67","22.22","188.89","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "69","?????","666.67","166.67","16.11","182.78","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "70","?????","500.00","166.67","12.92","179.58","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "71","?????","333.33","166.67","8.61","175.28","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "72","?????","166.67","166.67","4.17","170.83","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "73","?????","1000.00","83.33","25.83","109.17","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "74","?????","916.67","83.33","24.44","107.78","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "75","?????","833.33","83.33","20.14","103.47","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "76","?????","750.00","83.33","18.75","102.08","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "77","?????","666.67","83.33","17.78","101.11","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "78","?????","583.33","83.33","14.58","97.92","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "79","?????","500.00","83.33","12.08","95.42","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "80","?????","416.67","83.33","11.11","94.44","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "81","?????","333.33","83.33","8.06","91.39","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "82","?????","250.00","83.33","6.46","89.79","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "83","?????","166.67","83.33","4.31","87.64","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "84","?????","83.33","83.33","2.08","85.42","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "85","??????","1000.00","83.33","25.83","109.17","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "86","??????","916.67","83.33","24.44","107.78","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "87","??????","833.33","83.33","20.14","103.47","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "88","??????","750.00","83.33","18.75","102.08","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "89","??????","666.67","83.33","17.78","101.11","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "90","??????","583.33","83.33","14.58","97.92","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "91","??????","500.00","83.33","12.08","95.42","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "92","??????","416.67","83.33","11.11","94.44","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "93","??????","333.33","83.33","8.06","91.39","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "94","??????","250.00","83.33","6.46","89.79","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "95","??????","166.67","83.33","4.31","87.64","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "96","??????","83.33","83.33","2.08","85.42","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "97","?? ????SS","2000.00","166.67","51.67","218.33","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "98","?? ????SS","1833.33","166.67","48.89","215.56","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "99","?? ????SS","1666.67","166.67","40.28","206.94","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "100","?? ????SS","1500.00","166.67","37.50","204.17","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "101","?? ????SS","1333.33","166.67","35.56","202.22","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "102","?? ????SS","1166.67","166.67","29.17","195.83","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "103","?? ????SS","1000.00","166.67","24.17","190.83","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "104","?? ????SS","833.33","166.67","22.22","188.89","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "105","?? ????SS","666.67","166.67","16.11","182.78","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "106","?? ????SS","500.00","166.67","12.92","179.58","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "107","?? ????SS","333.33","166.67","8.61","175.28","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "108","?? ????SS","166.67","166.67","4.17","170.83","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "109","","1000.00","83.33","25.83","109.17","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "110","","916.67","83.33","24.44","107.78","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "111","","833.33","83.33","20.14","103.47","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "112","","750.00","83.33","18.75","102.08","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "113","","666.67","83.33","17.78","101.11","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "114","","583.33","83.33","14.58","97.92","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "115","","500.00","83.33","12.08","95.42","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "116","","416.67","83.33","11.11","94.44","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "117","","333.33","83.33","8.06","91.39","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "118","","250.00","83.33","6.46","89.79","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "119","","166.67","83.33","4.31","87.64","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "120","","83.33","83.33","2.08","85.42","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "121","dokv","1000.00","83.33","25.83","109.17","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "122","dokv","916.67","83.33","24.44","107.78","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "123","dokv","833.33","83.33","20.14","103.47","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "124","dokv","750.00","83.33","18.75","102.08","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "125","dokv","666.67","83.33","17.78","101.11","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "126","dokv","583.33","83.33","14.58","97.92","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "127","dokv","500.00","83.33","12.08","95.42","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "128","dokv","416.67","83.33","11.11","94.44","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "129","dokv","333.33","83.33","8.06","91.39","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "130","dokv","250.00","83.33","6.46","89.79","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "131","dokv","166.67","83.33","4.31","87.64","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "132","dokv","83.33","83.33","2.08","85.42","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "133","","1500.00","125.00","38.75","163.75","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "134","","1375.00","125.00","36.67","161.67","???????","2","1","$","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "135","","1250.00","125.00","30.21","155.21","???????","2","1","$","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "136","","1125.00","125.00","28.13","153.13","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "137","","1000.00","125.00","26.67","151.67","???????","2","1","$","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "138","","875.00","125.00","21.88","146.88","???????","2","1","$","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "139","","750.00","125.00","18.13","143.13","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "140","","625.00","125.00","16.67","141.67","???????","2","1","$","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "141","","500.00","125.00","12.08","137.08","???????","2","1","$","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "142","","375.00","125.00","9.69","134.69","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "143","","250.00","125.00","6.46","131.46","???????","2","1","$","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "144","","125.00","125.00","3.13","128.13","???????","2","1","$","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "145","asdfsa","40000.00","3400.00","1100.00","4500.00","??????????","1","8","R","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "146","asdfsa","36600.00","3400.00","1100.00","4500.00","??????????","1","8","R","2015-10-12","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "147","asdfsa","33200.00","3400.00","1000.00","4400.00","??????????","1","8","R","2015-11-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "148","asdfsa","29800.00","3400.00","1100.00","4500.00","??????????","1","8","R","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "149","asdfsa","26400.00","3400.00","1100.00","4500.00","??????????","1","8","R","2016-01-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "150","asdfsa","23000.00","3400.00","1100.00","4500.00","??????????","1","8","R","2016-02-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "151","asdfsa","19600.00","3400.00","1000.00","4400.00","??????????","1","8","R","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "152","asdfsa","16200.00","3400.00","1100.00","4500.00","??????????","1","8","R","2016-04-11","32","0");
INSERT INTO `v_getloanlates`  VALUES ( "153","asdfsa","12800.00","3400.00","1000.00","4400.00","??????????","1","8","R","2016-05-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "154","asdfsa","9400.00","3400.00","1100.00","4500.00","??????????","1","8","R","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "155","asdfsa","6000.00","3400.00","1100.00","4500.00","??????????","1","8","R","2016-07-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "156","asdfsa","2600.00","2600.00","1100.00","3700.00","??????????","1","8","R","2016-08-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "157","vikt","1000.00","0.00","25.83","25.83","???????","2","1","$","2015-09-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "158","vikt","1000.00","0.00","25.00","25.00","???????","2","1","$","2015-10-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "159","vikt","1000.00","0.00","25.83","25.83","???????","2","1","$","2015-11-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "160","vikt","1000.00","0.00","25.00","25.00","???????","2","1","$","2015-12-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "161","vikt","1000.00","0.00","25.83","25.83","???????","2","1","$","2016-01-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "162","vikt","1000.00","0.00","25.83","25.83","???????","2","1","$","2016-02-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "163","vikt","1000.00","0.00","24.17","24.17","???????","2","1","$","2016-03-10","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "164","vikt","1000.00","0.00","25.83","25.83","???????","2","1","$","2016-04-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "165","vikt","1000.00","0.00","25.00","25.00","???????","2","1","$","2016-05-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "166","vikt","1000.00","0.00","25.83","25.83","???????","2","1","$","2016-06-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "167","vikt","1000.00","0.00","25.00","25.00","???????","2","1","$","2016-07-10","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "168","vikt","1000.00","1000.00","25.83","1025.83","???????","2","1","$","2016-08-10","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "169","chea","40000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2015-09-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "170","chea","36000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2015-10-11","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "171","chea","32000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2015-11-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "172","chea","28000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2015-12-11","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "173","chea","24000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2016-01-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "174","chea","20000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2016-02-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "175","chea","16000.00","4000.00","1000.00","5000.00","??????????","1","8","R","2016-03-11","29","0");
INSERT INTO `v_getloanlates`  VALUES ( "176","chea","12000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2016-04-11","31","0");
INSERT INTO `v_getloanlates`  VALUES ( "177","chea","8000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2016-05-11","30","0");
INSERT INTO `v_getloanlates`  VALUES ( "178","chea","4000.00","4000.00","1100.00","5100.00","??????????","1","8","R","2016-06-11","31","0");


--
-- Tabel structure for table `v_getloanpayoff`
--
DROP TABLE  IF EXISTS `v_getloanpayoff`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getloanpayoff` AS (select `rm`.`id` AS `id`,`rm`.`status` AS `status_type`,`rm`.`principal_permonth` AS `principal_permonth`,`rm`.`total_interest` AS `total_interest`,`rm`.`total_payment` AS `total_payment`,`rm`.`total_recieve` AS `total_recieve`,`rm`.`service_charge` AS `service_charge`,`rm`.`penelize_amount` AS `penelize_amount`,`rm`.`date_payment` AS `date_payment`,`l`.`member_id` AS `member_id`,`l`.`loan_number` AS `loan_number`,`l`.`group_id` AS `group_id`,`l`.`branch_id` AS `branch_id`,`l`.`client_id` AS `client_id`,`l`.`total_capital` AS `total_capital`,`l`.`interest_rate` AS `interest_rate`,`l`.`curr_type` AS `curr_type`,`l`.`total_duration` AS `total_duration`,`l`.`date_release` AS `date_release`,`l`.`date_line` AS `date_line`,`l`.`loan_type` AS `loantype`,`l`.`payment_nameen` AS `from_paymentmethod`,`l`.`client_number` AS `client_number`,`l`.`client_name` AS `client_name`,`l`.`branch_name` AS `branch_name`,`l`.`currency_type` AS `currency_type`,`l`.`Term Borrow` AS `termborrow`,`l`.`co_name` AS `co_name`,`l`.`loan_type` AS `loan_type`,`l`.`loan_level` AS `loan_level` from (`v_default` `l` join `ln_client_receipt_money_detail` `rm`) where ((`l`.`loan_number` = `rm`.`loan_number`) and (`rm`.`status` = 4)));



--
-- Tabel structure for table `v_getnplloan`
--
DROP TABLE  IF EXISTS `v_getnplloan`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getnplloan` AS (select `v`.`member_id` AS `member_id`,`v`.`loan_number` AS `loan_number`,`v`.`group_id` AS `group_id`,`v`.`admin_fee` AS `admin_fee`,`v`.`other_fee` AS `other_fee`,`v`.`branch_id` AS `branch_id`,`v`.`client_id` AS `client_id`,`v`.`total_capital` AS `total_capital`,`v`.`interest_rate` AS `interest_rate`,`v`.`curr_type` AS `curr_type`,`v`.`loan_level` AS `loan_level`,`v`.`pay_term_id` AS `pay_term_id`,`v`.`total_duration` AS `total_duration`,`v`.`date_release` AS `date_release`,`v`.`date_line` AS `date_line`,`v`.`co_id` AS `co_id`,`v`.`loantype` AS `loantype`,`v`.`payment_nameen` AS `payment_nameen`,`v`.`client_number` AS `client_number`,`v`.`client_phone` AS `client_phone`,`v`.`client_name` AS `client_name`,`v`.`branch_name` AS `branch_name`,`v`.`currency_type` AS `currency_type`,`v`.`Term Borrow` AS `Term Borrow`,`v`.`co_name` AS `co_name`,`v`.`name_en` AS `name_en`,`v`.`loan_type` AS `loan_type`,(select sum(`cd`.`principal_permonth`) from `ln_client_receipt_money_detail` `cd` where (`cd`.`loan_number` = `v`.`loan_number`)) AS `total_principal_collect` from `v_default` `v`);

INSERT INTO `v_getnplloan`  VALUES ( "12","PTL00001","7","400.00","0.00","8","34","40000.00","2.50","1","1","3","12","2015-08-10","2016-09-10","1","1","Flat Rate","PT000001","02020202","????","??????????","R","Month","??? ?????","Month","Personal Loan","");
INSERT INTO `v_getnplloan`  VALUES ( "14","PTL00001R","12","0.00","0.00","8","34","40000.00","2.50","1","1","3","10","2015-08-11","2016-06-11","1","1","Flat Rate","PT000001","02020202","????","??????????","R","Month","??? ?????","Month","Other Loan","");
INSERT INTO `v_getnplloan`  VALUES ( "4","PPL00004","3","12.00","0.00","1","33","1200.00","2.50","2","1","3","12","2015-08-10","2016-09-10","15","1","Decline","PP000026","020202020","??? ????","???????","$","Month","Long Dara","Month","Other Loan","");
INSERT INTO `v_getnplloan`  VALUES ( "5","PPL00005","4","15.00","0.00","1","2","1500.00","2.50","2","1","3","12","2015-08-10","2016-09-10","1","1","Decline","PP000002","070 33 43 54","?????","???????","$","Month","??? ?????","Month","","");
INSERT INTO `v_getnplloan`  VALUES ( "13","PPL00012","8","10.00","0.00","1","8","1000.00","2.50","2","1","3","12","2015-08-10","2016-09-10","2","1","Baloon","PP000007","0339399393","??? ????","???????","$","Month","?? ????","Month","Other Loan","");
INSERT INTO `v_getnplloan`  VALUES ( "1","PPL00001","1","22.00","0.00","1","30","2200.00","2.50","2","1","3","12","2015-08-04","2016-08-04","2","2","Decline","PP000023","","???","???????","$","Month","?? ????","Month","Other Loan","");
INSERT INTO `v_getnplloan`  VALUES ( "6","PPL00006","5","40.00","0.00","1","8","4000.00","2.50","2","1","3","12","2015-08-10","2016-08-10","2","2","Decline","PP000007","0339399393","??? ????","???????","$","Month","?? ????","Month","Other Loan","");
INSERT INTO `v_getnplloan`  VALUES ( "3","PPL00003","2","20.00","0.00","1","1","2000.00","2.50","2","1","3","12","2015-08-05","2016-09-05","6","1","Decline","PP000001","012 32 23 23","????","???????","$","Month","?????","Month","Other Loan","166.67");
INSERT INTO `v_getnplloan`  VALUES ( "9","PPL00009","6","40.00","0.00","1","8","4000.00","2.50","2","1","3","12","2015-08-10","2016-08-10","2","2","Decline","PP000007","0339399393","??? ????","???????","$","Month","?? ????","Month","Other Loan","");


--
-- Tabel structure for table `v_getreturncalleral`
--
DROP TABLE  IF EXISTS `v_getreturncalleral`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_getreturncalleral` AS (select `r`.`id` AS `id`,`r`.`branch_id` AS `branch_id`,`r`.`client_id` AS `client_id`,`r`.`giver_name` AS `giver_name`,`r`.`receiver_name` AS `receiver_name`,`r`.`date` AS `date`,`r`.`note` AS `note`,`r`.`status` AS `status`,`r`.`user_id` AS `user_id`,`r`.`change_id` AS `change_id`,(select `b`.`branch_namekh` from `ln_branch` `b` where (`b`.`br_id` = `r`.`branch_id`) limit 1) AS `branch_name`,(select `v`.`name_kh` from `ln_view` `v` where ((`v`.`type` = 21) and (`v`.`key_code` = `cd`.`owner_type`))) AS `re_owner_type`,(select `ct`.`title_en` from `ln_callecteral_type` `ct` where (`ct`.`id` = `cd`.`collect_type`) limit 1) AS `collecteral_type`,(select `c`.`client_number` from `ln_client` `c` where (`c`.`client_id` = `r`.`client_id`) limit 1) AS `client_code`,`cd`.`return_id` AS `return_id`,`cd`.`collect_type` AS `collect_type`,`cd`.`owner_type` AS `owner_type`,`cd`.`owner_name` AS `owner_name`,`cd`.`number_collteral` AS `number_collteral` from (`ln_return_collteral` `r` join `ln_return_collteral_detail` `cd`) where (`r`.`id` = `cd`.`return_id`));

INSERT INTO `v_getreturncalleral`  VALUES ( "3","1","0","channy","ganeral customer-?????????","2015-08-13","return back to client","1","1","","???????","???????????","Real Estate Certification Mark","NL000","3","1","1","ganeral customer-?????????","322");


--
-- Tabel structure for table `v_gettransferloan`
--
DROP TABLE  IF EXISTS `v_gettransferloan`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_gettransferloan` AS (select `tf`.`id` AS `id`,`tf`.`date` AS `date`,`tf`.`note` AS `note`,`tf`.`status` AS `status`,`tf`.`type` AS `type`,`tf`.`loan_id` AS `loan_number`,`tf`.`branch_id` AS `branch_id`,`tf`.`client_id` AS `client_id`,`tf`.`from` AS `from`,`tf`.`to` AS `to`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `tf`.`branch_id`) limit 1) AS `branch_name`,(select `c`.`client_number` from `ln_client` `c` where (`c`.`client_id` = `tf`.`client_id`) limit 1) AS `client_number`,(select `c`.`name_kh` from `ln_client` `c` where (`c`.`client_id` = `tf`.`client_id`) limit 1) AS `client_name`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `tf`.`from`) limit 1) AS `from_coname`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `tf`.`to`) limit 1) AS `to_coname` from `ln_tranfser_co` `tf` order by `tf`.`id` desc);

INSERT INTO `v_gettransferloan`  VALUES ( "3","2015-08-10","transfer loan  PPL00007 to chomroen","1","3","7","8","26","2","15","??????????","PP000021","Siniths","?? ????","Long Dara");
INSERT INTO `v_gettransferloan`  VALUES ( "2","2015-08-07","client to co","1","2","","1","2","","9","???????","PP000002","?????","","?? ????SS");
INSERT INTO `v_gettransferloan`  VALUES ( "1","2015-08-07","co to co , saron to dara","1","1","","2","","1","2","???? ????????","","","??? ?????","?? ????");


--
-- Tabel structure for table `v_loangroupmember`
--
DROP TABLE  IF EXISTS `v_loangroupmember`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_loangroupmember` AS (select `m`.`member_id` AS `member_id`,`m`.`loan_number` AS `loan_number`,`m`.`group_id` AS `group_id`,`m`.`admin_fee` AS `admin_fee`,`m`.`other_fee` AS `other_fee`,`m`.`branch_id` AS `branch_id`,`m`.`client_id` AS `client_id`,`m`.`total_capital` AS `total_capital`,`m`.`interest_rate` AS `interest_rate`,`m`.`currency_type` AS `curr_type`,`lg`.`pay_term` AS `pay_term_id`,`lg`.`total_duration` AS `total_duration`,`lg`.`date_release` AS `date_release`,`lg`.`date_line` AS `date_line`,`lg`.`co_id` AS `co_id`,`lg`.`loan_type` AS `loantype`,(select `c`.`client_number` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_number`,(select `c`.`name_en` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_name`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `m`.`branch_id`) limit 1) AS `branch_name`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `m`.`currency_type`)) AS `currency_type`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`))) AS `Term Borrow`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `lg`.`co_id`) limit 1) AS `co_name`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`)) limit 1) AS `name_en`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 24) and (`ln_view`.`key_code` = `lg`.`for_loantype`)) limit 1) AS `loan_type` from (`ln_loan_group` `lg` join `ln_loan_member` `m`) where ((`lg`.`g_id` = `m`.`group_id`) and (`lg`.`status` = 1) and (`lg`.`g_id` = `m`.`group_id`)));

INSERT INTO `v_loangroupmember`  VALUES ( "1","PPL00001","1","12.00","0.00","1","30","1200.00","2.50","2","3","12","2015-08-04","2016-08-04","2","2","PP000023","monor","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "2","PPL00002","1","10.00","0.00","1","31","1000.00","2.50","2","3","12","2015-08-04","2016-08-04","2","2","PP000024","Narith","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "3","PPL00003","2","20.00","0.00","1","1","2000.00","2.50","2","3","12","2015-08-05","2016-09-05","6","1","PP000001","Dara","???????","$","Month","?????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "4","PPL00004","3","12.00","0.00","1","33","1200.00","2.50","2","3","12","2015-08-10","2016-09-10","15","1","PP000026","Long Dara","???????","$","Month","Long Dara","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "5","PPL00005","4","15.00","0.00","1","2","1500.00","2.50","2","3","12","2015-08-10","2016-09-10","1","1","PP000002","Samnang","???????","$","Month","??? ?????","Month","");
INSERT INTO `v_loangroupmember`  VALUES ( "6","PPL00006","5","20.00","0.00","1","8","2000.00","2.50","2","3","12","2015-08-10","2016-08-10","2","2","PP000007","Long Dany","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "7","PPL00007","5","10.00","0.00","1","26","1000.00","2.50","2","3","12","2015-08-10","2016-08-10","2","2","PP000021","sokd","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "8","PPL00008","5","10.00","0.00","1","29","1000.00","2.50","2","3","12","2015-08-10","2016-08-10","2","2","PP000022","sa erk","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "9","PPL00009","6","20.00","0.00","1","8","2000.00","2.50","2","3","12","2015-08-10","2016-08-10","2","2","PP000007","Long Dany","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "10","PPL00010","6","10.00","0.00","1","26","1000.00","2.50","2","3","12","2015-08-10","2016-08-10","2","2","PP000021","sokd","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "11","PPL00011","6","10.00","0.00","1","29","1000.00","2.50","2","3","12","2015-08-10","2016-08-10","2","2","PP000022","sa erk","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "12","PTL00001","7","400.00","0.00","8","34","40000.00","2.50","1","3","12","2015-08-10","2016-09-10","1","1","PT000001","Virak","??????????","R","Month","??? ?????","Month","Personal Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "13","PPL00012","8","10.00","0.00","1","8","1000.00","2.50","2","3","12","2015-08-10","2016-09-10","2","1","PP000007","Long Dany","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loangroupmember`  VALUES ( "14","PTL00001R","12","0.00","0.00","8","34","40000.00","2.50","1","3","10","2015-08-11","2016-06-11","1","1","PT000001","Virak","??????????","R","Month","??? ?????","Month","Other Loan");


--
-- Tabel structure for table `v_loanoutstanding`
--
DROP TABLE  IF EXISTS `v_loanoutstanding`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_loanoutstanding` AS (select `g`.`member_id` AS `member_id`,`g`.`loan_number` AS `loan_number`,sum(`g`.`total_capital`) AS `total_capital`,`g`.`interest_rate` AS `interest_rate`,`g`.`currency_type` AS `curr_type`,`g`.`client_id` AS `client_id`,(select `ln_branch`.`br_id` from `ln_branch` where (`ln_branch`.`br_id` = `g`.`branch_id`) limit 1) AS `br_id`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `g`.`branch_id`) limit 1) AS `branch_name`,(select `ln_client`.`client_number` from `ln_client` where (`ln_client`.`client_id` = `g`.`client_id`) limit 1) AS `client_number`,(select `ln_client`.`name_kh` from `ln_client` where (`ln_client`.`client_id` = `g`.`client_id`) limit 1) AS `client_kh`,(select `ln_client`.`name_en` from `ln_client` where (`ln_client`.`client_id` = `g`.`client_id`) limit 1) AS `client_en`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `g`.`currency_type`)) AS `currency_type`,(select sum(`cd`.`principal_permonth`) from `ln_client_receipt_money_detail` `cd` where (`cd`.`loan_number` = `g`.`loan_number`)) AS `total_payment`,`lg`.`date_release` AS `date_release`,`lg`.`date_line` AS `date_line`,`lg`.`co_id` AS `co_id`,`lg`.`total_duration` AS `total_duration`,`lg`.`loan_type` AS `loantype`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 24) and (`ln_view`.`key_code` = `lg`.`for_loantype`)) limit 1) AS `loan_type`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`))) AS `pay_term`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `lg`.`co_id`)) AS `co_name`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`))) AS `name_en` from (`ln_loan_group` `lg` join `ln_loan_member` `g`) where ((`lg`.`g_id` = `g`.`group_id`) and (`g`.`status` = 1) and (`g`.`is_completed` = 0) and (`g`.`is_reschedule` <> 1)) group by `g`.`group_id`);

INSERT INTO `v_loanoutstanding`  VALUES ( "1","PPL00001","2200.00","2.50","2","30","1","???????","PP000023","???","monor","$","","2015-08-04","2016-08-04","2","12","2","Other Loan","Month","?? ????","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "3","PPL00003","2000.00","2.50","2","1","1","???????","PP000001","????","Dara","$","166.67","2015-08-05","2016-09-05","6","12","1","Other Loan","Month","?????","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "4","PPL00004","1200.00","2.50","2","33","1","???????","PP000026","??? ????","Long Dara","$","","2015-08-10","2016-09-10","15","12","1","Other Loan","Month","Long Dara","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "5","PPL00005","1500.00","2.50","2","2","1","???????","PP000002","?????","Samnang","$","","2015-08-10","2016-09-10","1","12","1","","Month","??? ?????","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "6","PPL00006","4000.00","2.50","2","8","1","???????","PP000007","??? ????","Long Dany","$","","2015-08-10","2016-08-10","2","12","2","Other Loan","Month","?? ????","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "9","PPL00009","4000.00","2.50","2","8","1","???????","PP000007","??? ????","Long Dany","$","","2015-08-10","2016-08-10","2","12","2","Other Loan","Month","?? ????","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "13","PPL00012","1000.00","2.50","2","8","1","???????","PP000007","??? ????","Long Dany","$","","2015-08-10","2016-09-10","2","12","1","Other Loan","Month","?? ????","Month");
INSERT INTO `v_loanoutstanding`  VALUES ( "14","PTL00001R","40000.00","2.50","1","34","8","??????????","PT000001","????","Virak","R","","2015-08-11","2016-06-11","1","10","1","Other Loan","Month","??? ?????","Month");


--
-- Tabel structure for table `v_loanreleased`
--
DROP TABLE  IF EXISTS `v_loanreleased`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_loanreleased` AS select `m`.`member_id` AS `member_id`,`m`.`loan_number` AS `loan_number`,`m`.`group_id` AS `group_id`,sum(`m`.`admin_fee`) AS `admin_fee`,sum(`m`.`other_fee`) AS `other_fee`,`m`.`branch_id` AS `branch_id`,`m`.`client_id` AS `client_id`,sum(`m`.`total_capital`) AS `total_capital`,`m`.`interest_rate` AS `interest_rate`,`lg`.`level` AS `loan_level`,`m`.`currency_type` AS `curr_type`,`lg`.`pay_term` AS `pay_term_id`,`lg`.`total_duration` AS `total_duration`,`lg`.`date_release` AS `date_release`,`lg`.`date_line` AS `date_line`,`lg`.`co_id` AS `co_id`,`lg`.`loan_type` AS `loantype`,(select `p`.`payment_nameen` from `ln_payment_method` `p` where (`p`.`id` = `lg`.`payment_method`)) AS `payment_name`,(select `c`.`client_number` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_number`,(select `c`.`name_en` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_name`,(select `c`.`name_kh` from `ln_client` `c` where (`c`.`client_id` = `m`.`client_id`) limit 1) AS `client_khname`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `m`.`branch_id`) limit 1) AS `branch_name`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `m`.`currency_type`)) AS `currency_type`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`))) AS `Term Borrow`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = `lg`.`co_id`) limit 1) AS `co_name`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`)) limit 1) AS `name_en`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 24) and (`ln_view`.`key_code` = `lg`.`for_loantype`)) limit 1) AS `loan_type` from (`ln_loan_group` `lg` join `ln_loan_member` `m`) where ((`lg`.`g_id` = `m`.`group_id`) and (`m`.`status` = 1) and (`lg`.`is_reschedule` = 0) and (`lg`.`g_id` = `m`.`group_id`)) group by `m`.`group_id` order by `lg`.`branch_id`,`m`.`currency_type`;

INSERT INTO `v_loanreleased`  VALUES ( "9","PPL00009","6","40.00","0.00","1","8","4000.00","2.50","1","2","3","12","2015-08-10","2016-08-10","2","2","Decline","PP000007","Long Dany","??? ????","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loanreleased`  VALUES ( "4","PPL00004","3","12.00","0.00","1","33","1200.00","2.50","1","2","3","12","2015-08-10","2016-09-10","15","1","Decline","PP000026","Long Dara","??? ????","???????","$","Month","Long Dara","Month","Other Loan");
INSERT INTO `v_loanreleased`  VALUES ( "13","PPL00012","8","10.00","0.00","1","8","1000.00","2.50","1","2","3","12","2015-08-10","2016-09-10","2","1","Baloon","PP000007","Long Dany","??? ????","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loanreleased`  VALUES ( "5","PPL00005","4","15.00","0.00","1","2","1500.00","2.50","1","2","3","12","2015-08-10","2016-09-10","1","1","Decline","PP000002","Samnang","?????","???????","$","Month","??? ?????","Month","");
INSERT INTO `v_loanreleased`  VALUES ( "1","PPL00001","1","22.00","0.00","1","30","2200.00","2.50","1","2","3","12","2015-08-04","2016-08-04","2","2","Decline","PP000023","monor","???","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loanreleased`  VALUES ( "6","PPL00006","5","40.00","0.00","1","8","4000.00","2.50","1","2","3","12","2015-08-10","2016-08-10","2","2","Decline","PP000007","Long Dany","??? ????","???????","$","Month","?? ????","Month","Other Loan");
INSERT INTO `v_loanreleased`  VALUES ( "3","PPL00003","2","20.00","0.00","1","1","2000.00","2.50","1","2","3","12","2015-08-05","2016-09-05","6","1","Decline","PP000001","Dara","????","???????","$","Month","?????","Month","Other Loan");


--
-- Tabel structure for table `v_newloancolect`
--
DROP TABLE  IF EXISTS `v_newloancolect`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_newloancolect` AS (select `f`.`id` AS `id`,`f`.`member_id` AS `member_id`,`f`.`total_principal` AS `total_principal`,sum(`f`.`principal_permonth`) AS `principal_permonth`,sum(`f`.`principle_after`) AS `principle_after`,sum(`f`.`total_interest`) AS `total_interest`,sum(`f`.`total_interest_after`) AS `total_interest_after`,sum(`f`.`total_payment`) AS `total_payment`,sum(`f`.`penelize`) AS `penelize`,sum(`f`.`service_charge`) AS `service_charge`,`f`.`amount_day` AS `amount_day`,`f`.`status` AS `status`,`f`.`is_completed` AS `is_completed`,`f`.`is_approved` AS `is_approved`,`f`.`date_payment` AS `date_payment`,`f`.`branch_id` AS `branch_id`,`f`.`collect_by` AS `collect_by`,`f`.`payment_option` AS `payment_option`,sum(`lm`.`total_capital`) AS `total_capital`,`lm`.`loan_number` AS `loan_number`,`lm`.`pay_after` AS `pay_after`,`lm`.`interest_rate` AS `interest_rate`,`lm`.`currency_type` AS `currency_type`,(select `lg`.`date_release` from `ln_loan_group` `lg` where (`lg`.`g_id` = `lm`.`group_id`)) AS `date_release`,(select `lg`.`date_line` from `ln_loan_group` `lg` where (`lg`.`g_id` = `lm`.`group_id`)) AS `date_line`,(select `lb`.`branch_namekh` from `ln_branch` `lb` where (`lb`.`br_id` = `f`.`branch_id`)) AS `branch_kh`,(select `c`.`phone` from `ln_client` `c` where (`c`.`client_id` = `lm`.`client_id`)) AS `phone_number`,(select `c`.`name_kh` from `ln_client` `c` where (`c`.`client_id` = `lm`.`client_id`)) AS `client_name`,(select `co`.`co_khname` from `ln_co` `co` where (`co`.`co_id` = (select `ln_loan_group`.`co_id` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `lm`.`group_id`)))) AS `co_name`,(select `crm`.`date_input` from (`ln_client_receipt_money` `crm` join `ln_client_receipt_money_detail` `crmd`) where ((`crm`.`loan_number` = `lm`.`loan_number`) and (`crm`.`id` = `crmd`.`crm_id`) and (`crmd`.`lfd_id` = `f`.`id`)) order by `crm`.`date_input` desc limit 1) AS `last_pay_date`,`lm`.`collect_typeterm` AS `collect_typeterm` from (`ln_loanmember_funddetail` `f` join `ln_loan_member` `lm`) where ((`f`.`is_completed` = 0) and (`lm`.`status` = 1) and (`f`.`member_id` = `lm`.`member_id`)) group by `lm`.`group_id` order by `lm`.`member_id`);

INSERT INTO `v_newloancolect`  VALUES ( "1","1","1200.00","2199.96","2199.96","364.06","364.06","2564.09","0.00","0.00","31","1","0","0","2015-09-04","1","7","","26400.00","PPL00001","2","2.50","2","2015-08-04","2016-08-04","???????","","???","?? ????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "26","3","1833.33","1833.33","1833.33","279.57","279.57","2112.90","0.00","0.00","30","1","0","0","2015-10-05","1","7","","22000.00","PPL00003","2","2.50","2","2015-08-05","2016-09-05","???????","012 32 23 23","????","?????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "37","4","1200.00","2700.00","2700.00","447.22","447.22","3147.22","0.00","0.00","31","1","0","0","2015-09-10","1","15","","28800.00","PPL00004","2","2.50","2","2015-08-10","2016-09-10","???????","020202020","??? ????","Long Dara","","3");
INSERT INTO `v_newloancolect`  VALUES ( "49","5","1500.00","1500.00","1500.00","248.47","248.47","1748.47","0.00","0.00","31","0","0","0","2015-09-10","1","1","","18000.00","PPL00005","2","2.50","2","2015-08-10","2016-09-10","???????","070 33 43 54","?????","??? ?????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "61","6","2000.00","3999.96","3999.96","662.51","662.51","4662.50","0.00","0.00","31","1","0","0","2015-09-10","1","2","","48000.00","PPL00006","2","2.50","2","2015-08-10","2016-08-10","???????","0339399393","??? ????","?? ????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "97","9","2000.00","3999.96","3999.96","662.51","662.51","4662.50","0.00","0.00","31","1","0","0","2015-09-10","1","2","","48000.00","PPL00009","2","2.50","2","2015-08-10","2016-08-10","???????","0339399393","??? ????","?? ????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "145","12","40000.00","40000.00","40000.00","12900.00","12900.00","52900.00","0.00","0.00","31","1","0","0","2015-09-10","8","1","","480000.00","PTL00001","2","2.50","1","2015-08-10","2016-09-10","??????????","02020202","????","??? ?????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "157","13","1000.00","1000.00","1000.00","304.98","304.98","1304.98","0.00","0.00","31","1","0","0","2015-09-10","1","2","","12000.00","PPL00012","2","2.50","2","2015-08-10","2016-09-10","???????","0339399393","??? ????","?? ????","","3");
INSERT INTO `v_newloancolect`  VALUES ( "169","14","40000.00","40000.00","40000.00","10900.00","10900.00","50900.00","0.00","0.00","31","1","0","0","2015-09-11","8","1","","400000.00","PTL00001R","2","2.50","1","2015-08-11","2016-06-11","??????????","02020202","????","??? ?????","","3");


--
-- Tabel structure for table `v_released_co`
--
DROP TABLE  IF EXISTS `v_released_co`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_released_co` AS (select `g`.`member_id` AS `member_id`,`g`.`loan_number` AS `loan_number`,`lg`.`branch_id` AS `branch_id`,`lg`.`pay_term` AS `pay_term_id`,`lg`.`date_line` AS `date_line`,`lg`.`loan_type` AS `for_loan_type`,sum(`g`.`total_capital`) AS `total_capital`,sum(`g`.`admin_fee`) AS `admin_fee`,sum(`g`.`other_fee`) AS `other_fee`,`g`.`interest_rate` AS `interest_rate`,`g`.`currency_type` AS `curr_type`,(select `p`.`payment_nameen` from `ln_payment_method` `p` where (`p`.`id` = `lg`.`payment_method`)) AS `payment_name`,(select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `lg`.`branch_id`) limit 1) AS `branch_name`,(select `ln_client`.`client_id` from `ln_client` where (`ln_client`.`client_id` = `g`.`client_id`) limit 1) AS `client_id`,(select `ln_client`.`client_number` from `ln_client` where (`ln_client`.`client_id` = `g`.`client_id`) limit 1) AS `client_number`,(select `ln_client`.`name_en` from `ln_client` where (`ln_client`.`client_id` = `g`.`client_id`) limit 1) AS `client_name`,(select `ln_currency`.`symbol` from `ln_currency` where (`ln_currency`.`id` = `g`.`currency_type`)) AS `currency_type`,(select `ln_loan_group`.`total_duration` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1) AS `total_duration`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = (select `ln_loan_group`.`pay_term` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1)))) AS `pay_term`,(select `ln_loan_group`.`date_release` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1) AS `date_release`,(select `ln_co`.`co_code` from `ln_co` where (`ln_co`.`co_id` = (select `ln_loan_group`.`co_id` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1))) AS `co_code`,(select `ln_co`.`co_khname` from `ln_co` where (`ln_co`.`co_id` = (select `ln_loan_group`.`co_id` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1))) AS `co_name`,(select `ln_co`.`co_firstname` from `ln_co` where (`ln_co`.`co_id` = (select `ln_loan_group`.`co_id` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1))) AS `co_name_en`,(select `ln_co`.`sex` from `ln_co` where (`ln_co`.`co_id` = (select `ln_loan_group`.`co_id` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1))) AS `sex`,(select `ln_loan_group`.`co_id` from `ln_loan_group` where (`ln_loan_group`.`g_id` = `g`.`group_id`) limit 1) AS `co_id`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 14) and (`ln_view`.`key_code` = `lg`.`pay_term`))) AS `name_en`,(select `ln_view`.`name_en` from `ln_view` where ((`ln_view`.`type` = 24) and (`ln_view`.`key_code` = `lg`.`for_loantype`)) limit 1) AS `loan_type` from (`ln_loan_group` `lg` join `ln_loan_member` `g`) where ((`lg`.`g_id` = `g`.`group_id`) and (`g`.`status` = 1) and (`lg`.`is_reschedule` = 0)) group by `g`.`group_id`);

INSERT INTO `v_released_co`  VALUES ( "1","PPL00001","1","3","2016-08-04","2","2200.00","22.00","0.00","2.50","2","Decline","???????","30","PP000023","monor","$","12","Month","2015-08-04","C002","?? ????","dara","2","2","Month","Other Loan");
INSERT INTO `v_released_co`  VALUES ( "3","PPL00003","1","3","2016-09-05","1","2000.00","20.00","0.00","2.50","2","Decline","???????","1","PP000001","Dara","$","12","Month","2015-08-05","C004","?????","Narith","1","6","Month","Other Loan");
INSERT INTO `v_released_co`  VALUES ( "4","PPL00004","1","3","2016-09-10","1","1200.00","12.00","0.00","2.50","2","Decline","???????","33","PP000026","Long Dara","$","12","Month","2015-08-10","","Long Dara","?? ?????","1","15","Month","Other Loan");
INSERT INTO `v_released_co`  VALUES ( "5","PPL00005","1","3","2016-09-10","1","1500.00","15.00","0.00","2.50","2","Decline","???????","2","PP000002","Samnang","$","12","Month","2015-08-10","C001","??? ?????","sarons","1","1","Month","");
INSERT INTO `v_released_co`  VALUES ( "6","PPL00006","1","3","2016-08-10","2","4000.00","40.00","0.00","2.50","2","Decline","???????","8","PP000007","Long Dany","$","12","Month","2015-08-10","C002","?? ????","dara","2","2","Month","Other Loan");
INSERT INTO `v_released_co`  VALUES ( "9","PPL00009","1","3","2016-08-10","2","4000.00","40.00","0.00","2.50","2","Decline","???????","8","PP000007","Long Dany","$","12","Month","2015-08-10","C002","?? ????","dara","2","2","Month","Other Loan");
INSERT INTO `v_released_co`  VALUES ( "13","PPL00012","1","3","2016-09-10","1","1000.00","10.00","0.00","2.50","2","Baloon","???????","8","PP000007","Long Dany","$","12","Month","2015-08-10","C002","?? ????","dara","2","2","Month","Other Loan");


--
-- Tabel structure for table `v_rescheduleloan`
--
DROP TABLE  IF EXISTS `v_rescheduleloan`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rescheduleloan` AS (select `r`.`id` AS `id`,`r`.`reschedule_date` AS `reschedule_date`,`r`.`re_amount` AS `re_amount`,`r`.`re_interest_rate` AS `re_interest_rate`,`r`.`re_loan_number` AS `re_loan_number`,`r`.`maturity` AS `maturity`,(select `p`.`payment_nameen` from `ln_payment_method` `p` where (`p`.`id` = `r`.`re_payment_method`)) AS `re_payment_method`,`l`.`member_id` AS `member_id`,`l`.`loan_number` AS `loan_number`,`l`.`group_id` AS `group_id`,`l`.`branch_id` AS `branch_id`,`l`.`client_id` AS `client_id`,`l`.`total_capital` AS `total_capital`,`l`.`interest_rate` AS `interest_rate`,`l`.`curr_type` AS `curr_type`,`l`.`total_duration` AS `total_duration`,`l`.`date_release` AS `date_release`,`l`.`date_line` AS `date_line`,`l`.`loan_type` AS `loantype`,`l`.`payment_nameen` AS `from_paymentmethod`,`l`.`client_number` AS `client_number`,`l`.`client_name` AS `client_name`,`l`.`branch_name` AS `branch_name`,`l`.`currency_type` AS `currency_type`,`l`.`Term Borrow` AS `Term Borrow`,`l`.`co_name` AS `co_name`,`l`.`loan_type` AS `loan_type` from (`ln_reschedule` `r` join `v_default` `l`) where (`l`.`loan_number` = `r`.`loan_number`));

INSERT INTO `v_rescheduleloan`  VALUES ( "2","2015-08-11","40000.00","2.5","PTL00001R","2016-06-11","Flat Rate","12","PTL00001","7","8","34","40000.00","2.50","1","12","2015-08-10","2016-09-10","Personal Loan","Flat Rate","PT000001","????","??????????","R","Month","??? ?????","Personal Loan");


--
-- Tabel structure for table `v_xchange`
--
DROP TABLE  IF EXISTS `v_xchange`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_xchange` AS (select (select `ln_branch`.`branch_namekh` from `ln_branch` where (`ln_branch`.`br_id` = `ln_xchange`.`branch_id`) limit 1) AS `branch_name`,(select `ln_client`.`name_kh` from `ln_client` where (`ln_client`.`client_id` = `ln_xchange`.`client_id`) limit 1) AS `client_name`,`ln_xchange`.`id` AS `id`,`ln_xchange`.`client_id` AS `client_id`,`ln_xchange`.`branch_id` AS `branch_id`,`ln_xchange`.`changedAmount` AS `changedAmount`,`ln_xchange`.`fromAmount` AS `fromAmount`,`ln_xchange`.`rate` AS `rate`,`ln_xchange`.`recieptNo` AS `recieptNo`,`ln_xchange`.`recievedAmount` AS `recievedAmount`,`ln_xchange`.`status_in` AS `status_in`,`ln_xchange`.`statusDate` AS `statusDate`,`ln_xchange`.`toAmount` AS `toAmount`,`ln_xchange`.`toAmountType` AS `toAmountType`,`ln_xchange`.`fromAmountType` AS `fromAmountType`,`ln_xchange`.`from_to` AS `from_to`,`ln_xchange`.`recievedType` AS `recievedType`,`ln_xchange`.`userid` AS `userid`,`ln_xchange`.`specail_customer` AS `specail_customer`,`ln_xchange`.`status` AS `status` from `ln_xchange`);

INSERT INTO `v_xchange`  VALUES ( "","","1","","","0","200","32.9","W15-05-22/301a843","200","in","2015-07-12 22:40:05","6580","B","$","Dollar - Bath","$","1","0","1");
INSERT INTO `v_xchange`  VALUES ( "","","2","","","0","10","3990","W15-05-29/44e00c8","10","in","2015-05-29 20:48:34","39900","R","$","Dollar - Riel","$","1","0","1");
INSERT INTO `v_xchange`  VALUES ( "","","3","","","100","100","3990","W15-05-29/1644556","200","in","2015-05-29 22:25:33","399000","R","$","Dollar - Riel","$","1","0","1");
INSERT INTO `v_xchange`  VALUES ( "","","4","","","5","10","3990","W15-05-29/5685f43","15","in","2015-05-29 22:30:10","39900","R","$","Dollar - Riel","$","1","0","1");
INSERT INTO `v_xchange`  VALUES ( "","","5","","","0","100","3990","W15-06-23/2233558","100","in","2015-06-23 18:25:00","399000","R","$","Dollar - Riel","$","1","0","1");
INSERT INTO `v_xchange`  VALUES ( "","","6","","","0","1000","32.9","W15-07-10/34559f7","1000","in","2015-07-10 17:04:25","32900","B","$","Dollar - Bath","$","1","0","1");
INSERT INTO `v_xchange`  VALUES ( "","","7","","","0","1000","3990","W15-08-10/003d155","1000","in","2015-08-10 17:35:38","3990000","R","$","Dollar - Riel","$","1","0","1");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
